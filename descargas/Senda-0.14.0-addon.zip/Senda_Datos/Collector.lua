-- Senda_Datos: datos de misiones para el addon Senda.
-- Licencia GNU GPL v2 (ver LICENSE-GPL2.txt y LEEME.txt).
-- Junta los datos de cada zona en la tabla global SendaDatos, que Senda lee
-- al cargar y después libera.

local _, ns = ...

SendaDatos = { zones = {}, names = {} }

ns.DB = {
    RegisterZone = function(_, zone) table.insert(SendaDatos.zones, zone) end,
    RegisterNames = function(_, names) table.insert(SendaDatos.names, names) end,
}
