-- ARCHIVO GENERADO por tools/export_tc.py. No editar a mano: se sobrescribe.
-- Datos derivados de TrinityCore (C) 2008+ TrinityCore, licencia GNU GPL v2.
-- Ver LEEME.txt y LICENSE-GPL2.txt en la carpeta Senda_Datos.
-- Zona: Tótem del Trueno (mapID 1080, continente 1220, área 0)
-- 19 misiones, 0 PNJ, 0 objetos.

local _, ns = ...

ns.DB:RegisterZone({
    mapID = 1080,
    name = "Tótem del Trueno",
    quests = {
        [39387] = { name = "Los cielos de Altamontaña", level = -1, minLevel = 98, start = {}, finish = { npcs = { 93826, 108434 } }, prev = { 39322 }, objectives = { { type = "monster", id = 98773, count = 1 }, { type = "monster", id = 98773, count = 1 }, { type = "monster", id = 99225, count = 1 } }, poi = { finish = { 44.6, 50.7 }, obj = { { 2, 45.4, 50.4, 1.5 } } } },
        [39456] = { name = "Aliados Inesperados", level = -1, minLevel = 98, start = {}, finish = { npcs = { 93826, 108434 } }, prev = { 40229 }, objectives = { { type = "monster", id = 99619, count = 1 }, { type = "monster", id = 99619, count = 1 }, { type = "monster", id = 99624, count = 1 } }, poi = { finish = { 44.6, 50.7 }, obj = { { 2, 45.4, 51.2, 1.5 }, { 1, 34.9, 44.1, 1.5 }, { 0, 34.9, 44.1, 1.5 } } } },
        [39983] = { name = "La guerra de Huln: La llegada", level = -1, minLevel = 98, start = {}, finish = { npcs = { 97891 } }, prev = { 40520 }, objectives = { { type = "monster", id = 98825, count = 1 }, { type = "monster", id = 97796, count = 25, also = { 97803, 97808, 98020, 98022, 98757, 109386 } } }, poi = { obj = { { 31, 51.5, 54.9, 1.5 } } } },
        [39988] = { name = "La guerra de Huln: Tempestira", level = -1, minLevel = 98, start = {}, finish = { npcs = { 97892 } }, prev = { 40112 }, objectives = {}, poi = { obj = { { 31, 51.5, 54.9, 1.5 } } } },
        [39990] = { name = "La guerra de Huln: Refuerzos", level = -1, minLevel = 98, start = {}, finish = { npcs = { 97892 } }, prev = { 39988 }, objectives = { { type = "monster", id = 97940, count = 25 } }, poi = { obj = { { 31, 51.5, 54.9, 1.5 } } } },
        [39992] = { name = "La guerra de Huln: Los Nathrezim", level = -1, minLevel = 98, start = {}, finish = { npcs = { 98825 } }, prev = { 39991, 40388 }, objectives = { { type = "monster", id = 97956, count = 1 } }, poi = { obj = { { 31, 51.5, 54.9, 1.5 } } } },
        [40112] = { name = "La guerra de Huln: El preferido de Malorne", level = -1, minLevel = 98, start = {}, finish = { npcs = { 98794 } }, prev = { 39983 }, objectives = {}, poi = { obj = { { 31, 51.5, 54.9, 1.5 } } } },
        [40204] = { name = "La evolución del pasado", level = 108, minLevel = 108, start = {}, finish = { npcs = { 98948 } }, objectives = { { type = "item", id = 130100, count = 5 } }, poi = { obj = { { 0, 79.8, 65.9, 43.1 } } } },
        [40388] = { name = "La guerra de Huln: Cantosombrío", level = -1, minLevel = 98, start = {}, finish = { npcs = { 97903 } }, prev = { 39990 }, objectives = {}, poi = { obj = { { 31, 51.5, 54.9, 1.5 } } } },
        [41193] = { name = "Enterrando", level = 110, minLevel = 110, start = {}, finish = { npcs = { 103485 } }, prev = { 41192 }, objectives = { { type = "item", id = 134095, count = 600 }, { type = "monster", id = 103556, count = 1 }, { type = "monster", id = 103731, count = 1 } }, poi = { obj = { { 1, 64.6, 49.9, 1.5 } } } },
        [42233] = { name = "Tribus de Altamontaña", level = 110, minLevel = 110, start = {}, finish = { npcs = { 106902 } }, objectives = {}, poi = { finish = { 38.0, 46.1 } } },
        [42590] = { name = "La reunión de Moozy", level = -1, minLevel = 98, start = {}, finish = { npcs = { 96084 } }, objectives = { { type = "monster", id = 107726, count = 1 }, { type = "monster", id = 96084, count = 1 } }, poi = { finish = { 45.9, 54.9 }, obj = { { 1, 45.9, 54.9, 1.5 }, { 0, 53.3, 20.6, 1.5 } } } },
        [42622] = { name = "Tambores ceremoniales", level = -1, minLevel = 98, start = {}, finish = { npcs = { 108017 } }, objectives = { { type = "item", id = 138198, count = 4 }, { type = "item", id = 138197, count = 4 }, { type = "item", id = 138199, count = 4 } }, poi = { finish = { 44.6, 55.9 }, obj = { { 2, 46.6, 35.5, 46.1 }, { 1, 46.8, 41.6, 40.9 }, { 0, 50.4, 41.3, 42.8 } } } },
        [45572] = { name = "Defensa impenetrable", level = -1, minLevel = 110, start = {}, finish = {}, prev = { 45840 }, objectives = { { type = "monster", id = 117533, count = 3 }, { type = "monster", id = 117266, count = 2 }, { type = "monster", id = 117473, count = 1 }, { type = "monster", id = 117332, count = 10, also = { 117250, 117333, 117334, 117335, 117337, 117338, 117339, 117421, 120097, 120098, 120099, 120100, 120101, 120102 } }, { type = "monster", id = 117429, count = 10, also = { 117251, 117286, 119640 } }, { type = "monster", id = 117454, count = 3 } }, poi = { finish = { 70.4, 75.2 }, obj = { { 2, 15.4, 56.4, 1.5 }, { 2, 17.3, 68.6, 1.5 }, { 0, 23.1, 48.8, 31.6 } } } },
        [45840] = { name = "Asalto en Altamontaña", level = -1, minLevel = 110, start = {}, finish = {}, objectives = { { type = "monster", id = 121406, count = 4 } }, poi = { finish = { 24.9, 22.5 } } },
        [46182] = { name = "Batalla por Altamontaña", level = -1, minLevel = 110, start = {}, finish = {}, prev = { 45572 }, objectives = { { type = "monster", id = 119676, count = 1 }, { type = "monster", id = 119579, count = 1 } }, poi = { finish = { 24.9, 22.5 }, obj = { { 0, 70.4, 75.2, 1.5 } } } },
        [46689] = { name = "Pellejoanciano tocado por fuego fatuo", level = 110, minLevel = 110, start = {}, finish = {}, prev = { 46685, 46686, 46687, 46688 }, objectives = { { type = "item", id = 147438, count = 1 } }, poi = { obj = { { 0, 36.1, 80.7, 1.5 } } } },
        [46743] = { name = "Suministros desde Altamontaña", level = 110, minLevel = 110, start = {}, finish = {}, objectives = {}, poi = { finish = { 38.0, 46.1 } } },
        [46796] = { name = "Dechado de Altamontaña", level = 110, minLevel = 110, start = {}, finish = {}, objectives = {}, poi = { finish = { 38.0, 46.1 } } },
    },
    npcs = {
    },
    objects = {
    },
    items = {
        [130100] = { npcs = {}, objects = {} },
        [134095] = { npcs = {}, objects = {} },
        [138197] = { npcs = {}, objects = {} },
        [138198] = { npcs = {}, objects = {} },
        [138199] = { npcs = {}, objects = {} },
        [147438] = { npcs = {}, objects = {} },
    },
})
