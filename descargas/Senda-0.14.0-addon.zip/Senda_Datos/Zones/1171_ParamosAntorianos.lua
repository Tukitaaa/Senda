-- ARCHIVO GENERADO por tools/export_tc.py. No editar a mano: se sobrescribe.
-- Datos derivados de TrinityCore (C) 2008+ TrinityCore, licencia GNU GPL v2.
-- Ver LEEME.txt y LICENSE-GPL2.txt en la carpeta Senda_Datos.
-- Zona: Páramos Antorianos (mapID 1171, continente 1669, área 8899)
-- 19 misiones, 0 PNJ, 0 objetos.

local _, ns = ...

ns.DB:RegisterZone({
    mapID = 1171,
    name = "Páramos Antorianos",
    quests = {
        [47473] = { name = "Evaluar a la oposición", level = 110, minLevel = 110, start = {}, finish = {}, objectives = {} },
        [48199] = { name = "El corazón ardiente", level = 110, minLevel = 110, start = {}, finish = {}, objectives = { { type = "monster", id = 126949, count = 1 } } },
        [48200] = { name = "Asegurar una posición", level = 110, minLevel = 110, start = {}, finish = {}, objectives = { { type = "monster", id = 126388, count = 1 } } },
        [48201] = { name = "Reforzar el Asidero de la Luz", level = 110, minLevel = 110, start = {}, finish = {}, objectives = { { type = "monster", id = 127063, count = 1 } } },
        [48202] = { name = "Refuerza la Guarida Oculta", level = 110, minLevel = 110, start = {}, finish = {}, objectives = { { type = "monster", id = 127064, count = 1 } } },
        [48203] = { name = "El Trono Ardiente", level = 110, minLevel = 110, start = {}, finish = {}, objectives = { { type = "monster", id = 120483, count = 1 } } },
        [48448] = { name = "Desbarata la máquina de guerra de la Legión", level = -1, minLevel = 110, start = {}, finish = {}, objectives = {} },
        [48600] = { name = "Cortar la ventaja", level = -1, minLevel = 110, start = {}, finish = {}, objectives = {} },
        [48601] = { name = "Destrucción del fuego vil", level = -1, minLevel = 110, start = {}, finish = {}, objectives = {} },
        [48636] = { name = "Recursos para la campaña antoriana", level = -1, minLevel = 110, start = {}, finish = {}, objectives = {} },
        [48799] = { name = "Combustible de un mundo condenado", level = 110, minLevel = 110, start = {}, finish = {}, objectives = { { type = "item", id = 153014, count = 50 } } },
        [48912] = { name = "Suministros para la campaña antoriana", level = -1, minLevel = 110, start = {}, finish = {}, objectives = {} },
        [48929] = { name = "Evaluar a la oposición", level = 110, minLevel = 110, start = {}, finish = {}, objectives = {} },
        [48973] = { name = "Dechado del Dominio argusiano", level = 110, minLevel = 110, start = {}, finish = {}, objectives = {} },
        [48974] = { name = "Dechado del Ejército de la Luz.", level = 110, minLevel = 110, start = {}, finish = {}, objectives = {} },
        [48976] = { name = "Suministros del Dominio argusiano", level = 110, minLevel = 110, start = {}, finish = {}, objectives = {} },
        [48977] = { name = "Suministros del Ejército de la Luz", level = 110, minLevel = 110, start = {}, finish = {}, objectives = {} },
        [49007] = { name = "¡Comandante en la cubierta!", level = 110, minLevel = 110, start = {}, finish = {}, objectives = { { type = "monster", id = 127943, count = 1 } } },
        [49014] = { name = "El Trono Ardiente", level = 110, minLevel = 110, start = {}, finish = {}, objectives = { { type = "monster", id = 120483, count = 1 } } },
    },
    npcs = {
    },
    objects = {
    },
    items = {
        [153014] = { npcs = {}, objects = {} },
    },
})
