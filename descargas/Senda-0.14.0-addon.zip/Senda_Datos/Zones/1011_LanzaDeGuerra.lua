-- ARCHIVO GENERADO por tools/export_tc.py. No editar a mano: se sobrescribe.
-- Datos derivados de TrinityCore (C) 2008+ TrinityCore, licencia GNU GPL v2.
-- Ver LEEME.txt y LICENSE-GPL2.txt en la carpeta Senda_Datos.
-- Zona: Lanza de Guerra (mapID 1011, continente 1116, área 0)
-- 18 misiones, 0 PNJ, 0 objetos.

local _, ns = ...

ns.DB:RegisterZone({
    mapID = 1011,
    name = "Lanza de Guerra",
    quests = {
        [36197] = { name = "A la orden", level = 100, minLevel = 100, races = 33555378, start = { npcs = { 84473 } }, finish = { npcs = { 84473 } }, objectives = { { type = "monster", id = 84659, count = 1 }, { type = "monster", id = 84474, count = 1 }, { type = "monster", id = 84661, count = 1 } }, poi = { obj = { { 0, 69.1, 97.8, 1.5 } } } },
        [36198] = { name = "Descubriendo los fragmentos de artefacto", level = 100, minLevel = 100, races = 33555378, start = { npcs = { 88448, 94864 } }, finish = { npcs = { 83995 } }, objectives = {}, poi = { finish = { 62.1, 99.3 } } },
        [36226] = { name = "Explora Ashran", level = 100, minLevel = 100, races = 33555378, start = { npcs = { 84660 } }, finish = { npcs = { 84660 } }, objectives = {}, poi = { finish = { 69.1, 97.8 } } },
        [36706] = { name = "Llegada a Ashran", level = 90, minLevel = 90, races = 33555378, start = { npcs = { 78466 } }, finish = { npcs = { 86315 } }, objectives = { { type = "monster", id = 79407, count = 1 } }, poi = { finish = { 45.6, 34.6 } } },
        [36707] = { name = "Una bienvenida de Lanza de Guerra", level = 90, minLevel = 90, races = 33555378, start = { npcs = { 86315 } }, finish = { npcs = { 86312 } }, prev = { 36706 }, objectives = {}, poi = { finish = { 44.2, 45.5 } } },
        [36708] = { name = "Inspirando a Ashran", level = 90, minLevel = 90, races = 33555378, start = { npcs = { 86312 } }, finish = { npcs = { 86312 } }, prev = { 36707 }, objectives = { { type = "monster", id = 86307, count = 1 }, { type = "monster", id = 86036, count = 1 }, { type = "monster", id = 86318, count = 1 } }, poi = { finish = { 44.2, 45.5 }, obj = { { 0, 53.8, 61.1, 1.5 }, { 0, 58.9, 52.1, 1.5 }, { 0, 44.9, 43.2, 1.5 } } } },
        [36709] = { name = "La bella ardiente", level = 90, minLevel = 90, races = 33555378, start = { npcs = { 86312 } }, finish = { npcs = { 81765 } }, prev = { 36708 }, objectives = {}, poi = { finish = { 62.2, 23.0 } } },
        [36741] = { name = "Vieja poción de acción libre", level = 100, minLevel = 100, races = 18875469, start = {}, finish = { npcs = { 85749 } }, objectives = { { type = "item", id = 117011, count = 10 } }, poi = { obj = { { 0, 97.1, 90.2, 1.7 } } } },
        [36742] = { name = "Vieja poción de acción libre", level = 100, minLevel = 100, races = 33555378, start = {}, finish = { npcs = { 86366 } }, objectives = { { type = "item", id = 117011, count = 10 } }, poi = { obj = { { 0, 97.1, 90.2, 1.7 } } } },
        [37259] = { name = "Un desafío digno: Teron'gor", level = 100, minLevel = 100, start = {}, finish = { npcs = { 88161 } }, objectives = { { type = "monster", id = 79117, count = 1 } }, poi = { finish = { 65.3, 59.4 } } },
        [37260] = { name = "Un desafío digno: Gug'rokk", level = 100, minLevel = 100, start = {}, finish = { npcs = { 88161 } }, objectives = { { type = "monster", id = 79115, count = 1 } }, poi = { finish = { 65.3, 59.4 } } },
        [37261] = { name = "Un desafío digno: Señora del Cielo Tovra", level = 100, minLevel = 100, start = {}, finish = { npcs = { 88161 } }, objectives = { { type = "monster", id = 79120, count = 1 } }, poi = { finish = { 65.3, 59.4 } } },
        [37262] = { name = "Un desafío digno: Skulloc, Hijo de Gruul", level = 100, minLevel = 100, start = {}, finish = { npcs = { 88161 } }, objectives = { { type = "monster", id = 79116, count = 1 } }, poi = { finish = { 65.3, 59.4 } } },
        [37263] = { name = "Un desafío digno: Ner'zhul", level = 100, minLevel = 100, start = { npcs = { 88161 } }, finish = { npcs = { 88161 } }, objectives = { { type = "monster", id = 79118, count = 1 } }, poi = { finish = { 65.3, 59.4 } } },
        [37264] = { name = "Un desafío digno: Gran Sabia Viryx", level = 100, minLevel = 100, start = {}, finish = { npcs = { 88161 } }, objectives = { { type = "monster", id = 78925, count = 1 } }, poi = { finish = { 65.3, 59.4 } } },
        [37265] = { name = "A Worthy Challenge: Yalnu", level = 100, minLevel = 100, start = {}, finish = { npcs = { 88161 } }, objectives = { { type = "monster", id = 79121, count = 1 } }, poi = { finish = { 65.3, 59.4 } } },
        [37266] = { name = "Un desafío digno: Señora de la guerra Zaela", level = 100, minLevel = 100, start = {}, finish = { npcs = { 88161 } }, objectives = { { type = "monster", id = 79122, count = 1 } }, poi = { finish = { 65.3, 59.4 } } },
        [37290] = { name = "Mejoras en Ashran", level = 100, minLevel = 92, races = 33555378, start = { npcs = { 78466 } }, finish = { npcs = { 85840 } }, objectives = {}, poi = { finish = { 42.7, 36.9 } } },
    },
    npcs = {
    },
    objects = {
    },
    items = {
        [117011] = { npcs = {}, objects = {} },
    },
})
