-- ARCHIVO GENERADO por tools/export_tc.py. No editar a mano: se sobrescribe.
-- Datos derivados de TrinityCore (C) 2008+ TrinityCore, licencia GNU GPL v2.
-- Ver LEEME.txt y LICENSE-GPL2.txt en la carpeta Senda_Datos.
-- Zona: Isla de Quel'Danas (mapID 499, continente 0, área 0)
-- 38 misiones, 0 PNJ, 0 objetos.

local _, ns = ...

ns.DB:RegisterZone({
    mapID = 499,
    name = "Isla de Quel'Danas",
    quests = {
        [11481] = { name = "Crisis en La Fuente del Sol", level = 70, minLevel = 70, start = { npcs = { 18537 } }, finish = { npcs = { 24967 } }, objectives = {}, poi = { finish = { 47.4, 30.7 } } },
        [11482] = { name = "El deber llama", level = 70, minLevel = 70, start = { npcs = { 18594 } }, finish = { npcs = { 24967 } }, objectives = {}, poi = { finish = { 47.4, 30.7 } } },
        [11492] = { name = "Duro de matar", level = 70, minLevel = 70, start = {}, finish = { npcs = { 24813 } }, prev = { 11490, 29683 }, objectives = { { type = "item", id = 34157, count = 1 } }, poi = { finish = { 47.4, 30.7 } } },
        [11496] = { name = "The Sanctum Wards", level = 70, minLevel = 70, start = {}, finish = { npcs = { 24967 } }, objectives = {}, poi = { finish = { 47.5, 30.5 }, obj = { { 30, 49.5, 36.8, 5.7 }, { 26, 42.9, 39.6, 17.1 } } } },
        [11520] = { name = "Descubriendo tus raíces", level = 70, minLevel = 70, start = {}, finish = { npcs = { 24975 } }, objectives = { { type = "item", id = 34254, count = 5 } }, poi = { finish = { 51.5, 32.5 } } },
        [11521] = { name = "Redescubriendo tus raíces", level = 70, minLevel = 70, start = { npcs = { 24975 } }, finish = { npcs = { 24975 } }, objectives = { { type = "item", id = 34254, count = 5 } }, poi = { finish = { 51.5, 32.5 } } },
        [11523] = { name = "¡Armad los resguardos!", level = 70, minLevel = 70, start = { npcs = { 24967 } }, finish = { npcs = { 24967 } }, objectives = {}, poi = { finish = { 47.5, 30.5 }, obj = { { 30, 49.5, 36.8, 5.7 }, { 26, 42.9, 39.6, 17.1 } } } },
        [11524] = { name = "Comportamiento errático", level = 70, minLevel = 70, start = {}, finish = { npcs = { 24965 } }, objectives = { { type = "monster", id = 24991, count = 5 }, { type = "item", id = 34368, count = 1 } }, poi = { finish = { 47.1, 30.7 }, obj = { { 0, 47.6, 35.2, 1.5 } } } },
        [11525] = { name = "Más transformaciones", level = 70, minLevel = 70, start = { npcs = { 24965 } }, finish = { npcs = { 24965 } }, objectives = { { type = "monster", id = 24991, count = 5 }, { type = "item", id = 34368, count = 1 } }, poi = { finish = { 47.1, 30.7 }, obj = { { 0, 47.6, 35.2, 1.5 } } } },
        [11532] = { name = "Distracción en La Cicatriz Muerta", level = 70, minLevel = 70, start = {}, finish = { npcs = { 25057 } }, objectives = { { type = "monster", id = 25031, count = 2 }, { type = "monster", id = 25033, count = 3 }, { type = "monster", id = 25030, count = 12 } }, poi = { finish = { 47.5, 35.1 }, obj = { { 0, 53.6, 75.9, 15.1 }, { 0, 52.6, 81.4, 3.1 }, { 0, 53.2, 67.4, 3.6 } } } },
        [11533] = { name = "Los ataques aéreos deben continuar", level = 70, minLevel = 70, start = { npcs = { 25057 } }, finish = { npcs = { 25057 } }, objectives = { { type = "monster", id = 25031, count = 2 }, { type = "monster", id = 25033, count = 3 }, { type = "monster", id = 25030, count = 12 } }, poi = { finish = { 47.5, 35.1 }, obj = { { 0, 53.6, 75.9, 15.1 }, { 0, 52.6, 81.4, 3.1 }, { 0, 53.2, 67.4, 3.6 } } } },
        [11535] = { name = "Preparándose", level = 70, minLevel = 70, start = {}, finish = { npcs = { 25046 } }, objectives = { { type = "item", id = 34479, count = 3 } }, poi = { finish = { 50.6, 40.7 }, obj = { { 27, 61.3, 66.9, 6.0 }, { 27, 62.0, 51.0, 11.6 }, { 0, 61.1, 70.4, 7.9 }, { 0, 62.8, 51.0, 8.0 } } } },
        [11536] = { name = "No te pares ahora", level = 70, minLevel = 70, start = { npcs = { 25046 } }, finish = { npcs = { 25046 } }, objectives = { { type = "item", id = 34479, count = 3 } }, poi = { finish = { 50.6, 40.7 }, obj = { { 27, 61.3, 66.9, 6.0 }, { 27, 62.0, 51.0, 11.6 }, { 0, 61.1, 70.4, 7.9 }, { 0, 62.8, 51.0, 8.0 } } } },
        [11537] = { name = "La batalla debe continuar", level = 70, minLevel = 70, start = { npcs = { 25061 } }, finish = { npcs = { 25061 } }, objectives = { { type = "monster", id = 25065, count = 1 }, { type = "monster", id = 25068, count = 6, also = { 24999, 25001, 25002, 25008 } }, { type = "item", id = 34414, count = 1 } }, poi = { finish = { 47.6, 35.1 }, obj = { { 0, 49.0, 42.5, 6.2 }, { 0, 48.5, 44.4, 1.5 } } } },
        [11538] = { name = "The Battle for the Sun's Reach Armory", level = 70, minLevel = 70, start = {}, finish = { npcs = { 25061 } }, objectives = { { type = "monster", id = 25065, count = 1 }, { type = "monster", id = 25068, count = 6, also = { 24999, 25001, 25002, 25008 } }, { type = "item", id = 34414, count = 1 } }, poi = { finish = { 47.6, 35.1 }, obj = { { 0, 49.0, 42.5, 6.2 }, { 0, 48.5, 44.4, 1.5 } } } },
        [11539] = { name = "Tomar el puerto", level = 70, minLevel = 70, start = {}, finish = { npcs = { 25069 } }, objectives = { { type = "monster", id = 24978, count = 6 }, { type = "monster", id = 24976, count = 6 }, { type = "monster", id = 24979, count = 3 } }, poi = { finish = { 49.3, 40.4 }, obj = { { 0, 51.4, 33.3, 4.3 }, { 0, 40.0, 39.4, 4.5 }, { 0, 50.8, 33.9, 3.8 }, { 0, 41.4, 37.5, 4.9 }, { 0, 51.5, 33.9, 2.7 }, { 0, 42.3, 39.2, 6.1 } } } },
        [11540] = { name = "Aplasta a los Hojalba", level = 70, minLevel = 70, start = { npcs = { 25069 } }, finish = { npcs = { 25069 } }, objectives = { { type = "monster", id = 24978, count = 6 }, { type = "monster", id = 24976, count = 6 }, { type = "monster", id = 24979, count = 3 } }, poi = { finish = { 49.3, 40.4 }, obj = { { 0, 51.4, 33.3, 4.3 }, { 0, 40.0, 39.4, 4.5 }, { 0, 50.8, 33.9, 3.8 }, { 0, 41.4, 37.5, 4.9 }, { 0, 51.5, 33.9, 2.7 }, { 0, 42.3, 39.2, 6.1 } } } },
        [11541] = { name = "Perturbar la Costa Branquia Verde", level = 70, minLevel = 70, start = { npcs = { 25088 } }, finish = { npcs = { 25088 } }, objectives = { { type = "monster", id = 25086, count = 10 } }, poi = { finish = { 53.8, 34.3 }, obj = { { 27, 64.4, 42.6, 4.3 }, { 27, 61.0, 55.3, 1.9 }, { 27, 60.4, 65.5, 1.9 }, { 27, 59.7, 73.6, 1.5 }, { 27, 60.2, 50.4, 1.7 }, { 27, 58.5, 79.9, 2.5 }, { 0, 62.9, 51.3, 7.3 }, { 0, 60.9, 76.6, 2.5 }, { 0, 62.1, 67.3, 4.8 } } } },
        [11542] = { name = "Interceptar a los refuerzos", level = 70, minLevel = 70, start = {}, finish = { npcs = { 25108 } }, objectives = { { type = "monster", id = 25090, count = 1 }, { type = "monster", id = 25091, count = 1 }, { type = "monster", id = 25092, count = 1 }, { type = "monster", id = 25087, count = 6 } }, poi = { finish = { 50.6, 39.0 }, obj = { { 0, 50.7, 10.4, 1.6 }, { 0, 55.6, 12.6, 1.5 }, { 0, 52.7, 15.3, 1.5 }, { 0, 55.5, 12.3, 1.8 }, { 0, 50.8, 10.3, 1.6 }, { 0, 52.6, 15.2, 2.0 } } } },
        [11543] = { name = "Mantén al enemigo a raya", level = 70, minLevel = 70, start = { npcs = { 25108 } }, finish = { npcs = { 25108 } }, objectives = { { type = "monster", id = 25090, count = 1 }, { type = "monster", id = 25091, count = 1 }, { type = "monster", id = 25092, count = 1 }, { type = "monster", id = 25087, count = 6 } }, poi = { finish = { 50.6, 39.0 }, obj = { { 0, 50.7, 10.4, 1.6 }, { 0, 55.6, 12.6, 1.5 }, { 0, 52.7, 15.3, 1.5 }, { 0, 55.5, 12.3, 1.8 }, { 0, 50.8, 10.3, 1.6 }, { 0, 52.6, 15.2, 2.0 } } } },
        [11544] = { name = "Armamentos de Ata'mal", level = 70, minLevel = 70, start = { npcs = { 25046 } }, finish = { npcs = { 25046 } }, objectives = { { type = "item", id = 34501, count = 5 } }, poi = { finish = { 50.6, 40.7 } } },
        [11545] = { name = "A Charitable Donation", level = 70, minLevel = 70, start = {}, finish = { npcs = { 25112 } }, objectives = {}, poi = { finish = { 48.8, 37.2 } } },
        [11546] = { name = "Abierto al negocio", level = 70, minLevel = 70, start = { npcs = { 24975 } }, finish = { npcs = { 24975 } }, objectives = { { type = "item", id = 34502, count = 5 } }, poi = { finish = { 51.5, 32.5 }, obj = { { 0, 39.8, 37.6, 15.9 }, { 0, 48.0, 42.9, 3.6 } } } },
        [11547] = { name = "Conoce tus líneas Ley", level = 70, minLevel = 70, start = { npcs = { 25133 } }, finish = { npcs = { 25133 } }, objectives = { { type = "monster", id = 25156, count = 1 }, { type = "monster", id = 25154, count = 1 }, { type = "monster", id = 25157, count = 1 }, { type = "item", id = 34533, count = 1 } }, poi = { finish = { 47.5, 35.4 }, obj = { { 0, 42.1, 35.7, 1.5 }, { 0, 61.2, 62.5, 1.5 }, { 0, 48.5, 44.4, 1.5 } } } },
        [11548] = { name = "Tu incesante apoyo", level = 70, minLevel = 70, start = { npcs = { 25112 } }, finish = { npcs = { 25112 } }, objectives = {}, poi = { finish = { 48.8, 37.2 } } },
        [11549] = { name = "Un benefactor magnánimo", level = 70, minLevel = 70, start = { npcs = { 25163 } }, finish = { npcs = { 25163 } }, objectives = {}, poi = { finish = { 51.2, 33.1 } } },
        [11550] = { name = "Adelante, Falsario...", level = 70, minLevel = 70, start = {}, finish = { npcs = { 25169 } }, objectives = {}, poi = { finish = { 50.1, 28.2 } } },
        [11551] = { name = "Agamath, the First Gate", level = 70, minLevel = 70, start = {}, finish = { npcs = { 25169 } }, objectives = {}, poi = { finish = { 50.1, 28.2 } } },
        [11552] = { name = "Rohendor, the Second Gate", level = 70, minLevel = 70, start = {}, finish = { npcs = { 25169 } }, objectives = {}, poi = { finish = { 50.1, 28.2 } } },
        [11553] = { name = "Archonisus, the Final Gate", level = 70, minLevel = 70, start = {}, finish = { npcs = { 25169 } }, objectives = {}, poi = { finish = { 50.1, 28.2 } } },
        [11554] = { name = "Un amigo en primera línea", level = 70, minLevel = 70, start = { npcs = { 25032 } }, finish = { npcs = { 25032 } }, objectives = {}, poi = { finish = { 47.2, 30.8 } } },
        [11555] = { name = "Honrado por tus aliados", level = 70, minLevel = 70, start = { npcs = { 25032 } }, finish = { npcs = { 25032 } }, objectives = {}, poi = { finish = { 47.2, 30.8 } } },
        [11556] = { name = "Venerado en el campo de batalla", level = 70, minLevel = 70, start = { npcs = { 25032 } }, finish = { npcs = { 25032 } }, objectives = {}, poi = { finish = { 47.2, 30.8 } } },
        [11557] = { name = "Exaltado entre todos los combatientes", level = 70, minLevel = 70, start = { npcs = { 25032 } }, finish = { npcs = { 25032 } }, objectives = {}, poi = { finish = { 47.2, 30.8 } } },
        [24522] = { name = "Viaje a La Fuente del Sol", level = 80, minLevel = 80, races = 18875469, start = { npcs = { 36624 } }, finish = { npcs = { 37527 } }, prev = { 24480 }, objectives = { { type = "item", id = 49870, count = 1 } }, poi = { finish = { 44.5, 45.5 } } },
        [24535] = { name = "Thalorien Buscalba", level = 80, minLevel = 80, races = 18875469, start = { npcs = { 37527 } }, finish = { npcs = { 37527 } }, prev = { 24522 }, objectives = { { type = "monster", id = 37601, count = 1 } }, poi = { finish = { 44.5, 45.5 }, obj = { { 0, 52.9, 79.0, 1.5 } } } },
        [24562] = { name = "Viaje a La Fuente del Sol", level = 80, minLevel = 80, races = 33555378, start = { npcs = { 36642 } }, finish = { npcs = { 37527 } }, prev = { 24561 }, objectives = { { type = "item", id = 49870, count = 1 } }, poi = { finish = { 44.5, 45.5 } } },
        [24563] = { name = "Thalorien Buscalba", level = 80, minLevel = 80, races = 33555378, start = { npcs = { 37527 } }, finish = { npcs = { 37527 } }, prev = { 24562 }, objectives = { { type = "monster", id = 37601, count = 1 } }, poi = { finish = { 44.5, 45.5 }, obj = { { 0, 53.1, 79.8, 1.5 } } } },
    },
    npcs = {
    },
    objects = {
    },
    items = {
        [34157] = { npcs = {}, objects = {} },
        [34254] = { npcs = {}, objects = {} },
        [34368] = { npcs = {}, objects = {} },
        [34414] = { npcs = {}, objects = {} },
        [34479] = { npcs = {}, objects = {} },
        [34501] = { npcs = {}, objects = {} },
        [34502] = { npcs = {}, objects = {} },
        [34533] = { npcs = {}, objects = {} },
        [49870] = { npcs = {}, objects = {} },
    },
})
