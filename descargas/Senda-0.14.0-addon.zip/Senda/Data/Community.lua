-- Senda (c) 2026 Tzors. Datos aportados por jugadores de Senda, con su permiso.
-- Datos aportados por la comunidad. Generado por tools/merge_learned.py a
-- partir de los archivos Senda.lua que envían los jugadores. No editar a mano.
local _, ns = ...
ns.community = nil
