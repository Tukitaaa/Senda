-- Senda (c) 2026 Tzors. Todos los derechos reservados. Ver LICENSE.txt.
-- Pines en el mapa del mundo (API de mapa anterior a 8.0, cliente 7.3.5).
--
-- Dos partes separadas:
--   Collect(mapID)  -> lista de pines (pura lógica, testeable fuera del juego)
--   Render()        -> pinta esa lista sobre WorldMapButton
--
-- Coordenadas de la base de datos: 0-100 relativas a la zona (mapID =
-- WorldMapArea.ID, el mismo que devuelve GetCurrentMapAreaID()).

local _, ns = ...
local L = ns.L

local MP = ns:NewModule("MapPins")
ns.MapPins = MP

-- Tipos de pin y su aspecto
MP.styles = {
    -- circle = fondo negro redondo con borde dorado, como los "!" del mapa del juego
    available    = { texture = "Interface\\GossipFrame\\AvailableQuestIcon", size = 20, layer = 30, circle = true },
    lowlevel     = { texture = "Interface\\GossipFrame\\AvailableQuestIcon", size = 17, layer = 20, circle = true, desaturate = true },
    turnin       = { texture = "Interface\\GossipFrame\\ActiveQuestIcon",    size = 20, layer = 40, circle = true },
    turnin_wait  = { texture = "Interface\\GossipFrame\\ActiveQuestIcon",    size = 17, layer = 25, circle = true, desaturate = true },
    area         = { texture = "Interface\\CHARACTERFRAME\\TempPortraitAlphaMask", size = 0, layer = 5,
                     color = { 1.0, 0.82, 0.0, 0.22 } },
    objective    = { texture = "Interface\\CHARACTERFRAME\\TempPortraitAlphaMask", size = 8, layer = 10,
                     color = { 1.0, 0.82, 0.0, 0.9 } },
}

-- Iconos de objetivo (Textures/obj_*.tga, propios de Senda), según qué hay que hacer.
-- Se desactivan con /senda iconos (vuelven los puntos amarillos). Cada uno
-- tiene un borde fino (obj_*_ring) que se tiñe con el color de su misión.
MP.objectiveIcons = {
    kill   = { texture = "Interface\\AddOns\\Senda\\Textures\\obj_kill", ring = "Interface\\AddOns\\Senda\\Textures\\obj_kill_ring",   size = 18, layer = 10 },  -- matar
    loot   = { texture = "Interface\\AddOns\\Senda\\Textures\\obj_loot", ring = "Interface\\AddOns\\Senda\\Textures\\obj_loot_ring",   size = 18, layer = 10 },  -- despojar
    gather = { texture = "Interface\\AddOns\\Senda\\Textures\\obj_gather", ring = "Interface\\AddOns\\Senda\\Textures\\obj_gather_ring", size = 18, layer = 10 },  -- recoger del suelo
    use    = { texture = "Interface\\AddOns\\Senda\\Textures\\obj_use", ring = "Interface\\AddOns\\Senda\\Textures\\obj_use_ring",    size = 18, layer = 10 },  -- usar / interactuar
}

-- "!" y "?" propios de Senda, uno por color de dificultad (Textures/avail_* y turnin_*).
local DIFF_RANK = { gray = 1, green = 2, yellow = 3, orange = 4, red = 5 }
MP.signStyles = {}
for _, color in ipairs({ "gray", "green", "yellow", "orange", "red" }) do
    local base = "Interface\\AddOns\\Senda\\Textures\\"
    MP.signStyles["available:" .. color]   = { texture = base .. "avail_" .. color,  size = 17, layer = 30 }
    MP.signStyles["lowlevel:" .. color]    = { texture = base .. "avail_" .. color,  size = 15, layer = 20 }
    MP.signStyles["turnin:" .. color]      = { texture = base .. "turnin_" .. color, size = 17, layer = 40 }
    MP.signStyles["turnin_wait:" .. color] = { texture = base .. "turnin_" .. color, size = 15, layer = 25, alpha = 0.55 }
end

--- Color de dificultad que representa a un pin con varias misiones: el más alto.
function MP:PinDifficulty(pin)
    local best, rank = "yellow", 0
    for _, q in ipairs(pin.quests or {}) do
        local d = ns.Availability:Difficulty(q)
        if DIFF_RANK[d] > rank then best, rank = d, DIFF_RANK[d] end
    end
    return best
end

-- Colores para distinguir misiones que comparten el mismo icono en un mapa.
MP.questColors = {
    { 1.00, 0.25, 0.25 }, -- rojo
    { 0.30, 0.60, 1.00 }, -- azul
    { 0.30, 0.95, 0.35 }, -- verde
    { 1.00, 0.35, 1.00 }, -- magenta
    { 0.25, 1.00, 1.00 }, -- cian
    { 1.00, 0.60, 0.10 }, -- naranja
    { 0.65, 0.35, 1.00 }, -- violeta
    { 1.00, 1.00, 0.30 }, -- amarillo
    { 1.00, 1.00, 1.00 }, -- blanco
    { 1.00, 0.60, 0.75 }, -- rosa
    { 0.65, 1.00, 0.20 }, -- lima
    { 0.20, 0.75, 0.65 }, -- turquesa
}

--- Da un color a cada misión con objetivos en ESTE mapa, solo si al menos dos
--- misiones comparten el mismo tipo de icono. Así los colores se reparten entre
--- las misiones de la zona que miras, sin gastar colores en otras zonas.
function MP:AssignColors(pins)
    local byIcon, quests, seen, shared = {}, {}, {}, false
    for _, pin in ipairs(pins) do
        if pin.kind == "objective" and pin.icon then
            local set = byIcon[pin.icon] or {}
            byIcon[pin.icon] = set
            for _, q in ipairs(pin.quests) do
                if not set[q] then
                    set[q] = true
                    set.n = (set.n or 0) + 1
                    if set.n > 1 then shared = true end
                end
                if not seen[q] then
                    seen[q] = true
                    quests[#quests + 1] = q
                end
            end
        end
    end
    if not shared then return {} end
    -- Orden estable: el del registro de misiones del jugador.
    local QS = ns.QuestState
    table.sort(quests, function(a, b)
        local la, lb = QS.active[a], QS.active[b]
        la, lb = la and la.logIndex or 999, lb and lb.logIndex or 999
        if la ~= lb then return la < lb end
        return a < b
    end)
    local colors = {}
    for i, q in ipairs(quests) do
        colors[q] = self.questColors[(i - 1) % #self.questColors + 1]
    end
    for _, pin in ipairs(pins) do
        if pin.kind == "objective" and pin.icon then
            pin.color = colors[pin.quests[1]]
            pin.colors = colors
        end
    end
    return colors
end

---------------------------------------------------------------------------
-- Recolección
---------------------------------------------------------------------------

local function spawnsOn(entity, mapID)
    return entity and entity.spawns and entity.spawns[mapID]
end

-- Añade un pin por cada aparición de la entidad en el mapa, agrupando por
-- posición para que varias misiones en el mismo PNJ compartan un pin.
local function addEntityPins(out, index, kind, entityKind, entityID, mapID, questID, limit, icon)
    local entity = ns.DB:GetEntity(entityKind, entityID)
    local spawns = spawnsOn(entity, mapID)
    if not spawns then return end
    local n = limit and math.min(#spawns, limit) or #spawns
    for i = 1, n do
        local s = spawns[i]
        local key = kind .. ":" .. entityKind .. ":" .. entityID .. ":" .. s[1] .. ":" .. s[2]
        local pin = index[key]
        if not pin then
            pin = { kind = kind, x = s[1] / 100, y = s[2] / 100,
                    entityKind = entityKind, entityID = entityID, quests = {}, icon = icon }
            index[key] = pin
            out[#out + 1] = pin
        end
        local qs = pin.quests
        if qs[#qs] ~= questID then qs[#qs + 1] = questID end
    end
end

-- Pin en una posición del mapa sin PNJ concreto (áreas de quest_poi).
local function addPoiPin(out, index, kind, x, y, questID, radius)
    local key = kind .. ":poi:" .. x .. ":" .. y
    local pin = index[key]
    if not pin then
        pin = { kind = kind, x = x / 100, y = y / 100, entityKind = "poi", entityID = 0,
                radius = radius, quests = {} }
        index[key] = pin
        out[#out + 1] = pin
    end
    local qs = pin.quests
    if qs[#qs] ~= questID then qs[#qs + 1] = questID end
end

local function entityOnMap(refs, mapID)
    if not refs then return false end
    for _, id in ipairs(refs.npcs or {}) do
        if spawnsOn(ns.DB:GetNpc(id), mapID) then return true end
    end
    for _, id in ipairs(refs.objects or {}) do
        if spawnsOn(ns.DB:GetObject(id), mapID) then return true end
    end
    return false
end

local function addStarterOrEnder(out, index, kind, refs, mapID, questID)
    if not refs then return end
    for _, id in ipairs(refs.npcs or {}) do addEntityPins(out, index, kind, "npc", id, mapID, questID) end
    for _, id in ipairs(refs.objects or {}) do addEntityPins(out, index, kind, "object", id, mapID, questID) end
end

-- Objetivos de una misión activa que aún no están cumplidos.
-- Pin de objetivo en una posición concreta (agrupa misiones en el mismo sitio).
local function addPinAt(out, index, kind, entityKind, entityID, x, y, questID, icon)
    local key = kind .. ":" .. entityKind .. ":" .. entityID .. ":" .. x .. ":" .. y
    local pin = index[key]
    if not pin then
        pin = { kind = kind, x = x / 100, y = y / 100, entityKind = entityKind, entityID = entityID,
                quests = {}, icon = icon }
        index[key] = pin
        out[#out + 1] = pin
    end
    local qs = pin.quests
    if qs[#qs] ~= questID then qs[#qs + 1] = questID end
end

--- Elige como mucho `max` puntos repartidos por la zona (muestreo del punto
--- más lejano): así se ve dónde están los bichos sin llenar el mapa de iconos.
function MP.Spread(cands, max)
    if #cands <= max then return cands end
    local cx, cy = 0, 0
    for _, c in ipairs(cands) do cx, cy = cx + c[3], cy + c[4] end
    cx, cy = cx / #cands, cy / #cands
    local first, bestD = 1, math.huge
    for i, c in ipairs(cands) do
        local d = (c[3] - cx) ^ 2 + (c[4] - cy) ^ 2
        if d < bestD then first, bestD = i, d end
    end
    local chosen, minD = { cands[first] }, {}
    for i, c in ipairs(cands) do minD[i] = (c[3] - cands[first][3]) ^ 2 + (c[4] - cands[first][4]) ^ 2 end
    while #chosen < max do
        local pick, far = nil, -1
        for i, d in ipairs(minD) do
            if d > far then pick, far = i, d end
        end
        if not pick or far <= 0 then break end
        local p = cands[pick]
        chosen[#chosen + 1] = p
        for i, c in ipairs(cands) do
            local d = (c[3] - p[3]) ^ 2 + (c[4] - p[4]) ^ 2
            if d < minD[i] then minD[i] = d end
        end
    end
    return chosen
end

--- Pines de los objetivos sin terminar. Devuelve qué objetivos (por índice)
--- ya tienen algún pin en este mapa, para no dibujarles además un área.
local function addObjectivePins(out, index, q, questID, state, mapID, maxIcons)
    local covered = {}
    for i, obj in ipairs(q.objectives or {}) do
        local live = state.objectives and state.objectives[i]
        if not (live and live.finished) then
            local cands, perMap = {}, {}
            local function collect(entityKind, entityID, icon)
                local entity = ns.DB:GetEntity(entityKind, entityID)
                for m, list in pairs(entity and entity.spawns or {}) do
                    perMap[m] = (perMap[m] or 0) + #list
                end
                local spawns = spawnsOn(entity, mapID)
                for _, sp in ipairs(spawns or {}) do
                    cands[#cands + 1] = { entityKind, entityID, sp[1], sp[2], icon }
                end
            end
            if obj.type == "monster" then
                collect("npc", obj.id, "kill")
                for _, npcID in ipairs(obj.also or {}) do collect("npc", npcID, "kill") end
            elseif obj.type == "object" then
                collect("object", obj.id, "use")
            elseif obj.type == "item" then
                local item = ns.DB:GetItem(obj.id)
                if item then
                    for _, npcID in ipairs(item.npcs or {}) do collect("npc", npcID, "loot") end
                    for _, goID in ipairs(item.objects or {}) do collect("object", goID, "gather") end
                end
            end
            -- ¿Este mapa es la zona "de verdad" del objetivo? Si en otro mapa hay
            -- más bichos/objetos (p. ej. miras el Bosque del Ocaso y los bichos son
            -- de Elwynn, en el borde), se muestran menos iconos.
            -- (Solo si casi todos están pegados al borde: un submapa como Villanorte
            -- dentro de Elwynn sigue mostrando todos.)
            local here, limit = perMap[mapID] or 0, maxIcons
            local edge = 0
            for _, c in ipairs(cands) do
                if c[3] < 12 or c[3] > 88 or c[4] < 12 or c[4] > 88 then edge = edge + 1 end
            end
            if #cands > 0 and edge >= #cands * 0.8 then
                for m, n in pairs(perMap) do
                    if m ~= mapID and n > here then limit = math.min(maxIcons, ns.settings.maxForeignIcons or 4) break end
                end
            end
            for _, c in ipairs(MP.Spread(cands, limit)) do
                addPinAt(out, index, "objective", c[1], c[2], c[3], c[4], questID, c[5])
            end
            if #cands > 0 then covered[i] = true end
        end
    end
    return covered
end

--- Icono para la zona de un objetivo sin bichos/objetos ubicados.
function MP.AreaIcon(obj)
    local t = obj and obj.type
    if t == "monster" then return "kill" end
    if t == "object" then return "use" end
    return "loot"
end

--- Calcula todos los pines a mostrar en un mapa. No toca la interfaz.
function MP:Collect(mapID)
    local out, index = {}, {}
    local S = ns.settings
    local DB, AV, QS = ns.DB, ns.Availability, ns.QuestState

    -- Disponibles: recorremos solo quien empieza misiones (índice inverso).
    if S.showAvailable then
        for _, entityKind in ipairs({ "npc", "object" }) do
            for entityID, questIDs in pairs(DB.startsAt[entityKind]) do
                if spawnsOn(DB:GetEntity(entityKind, entityID), mapID) then
                    for _, questID in ipairs(questIDs) do
                        if AV:IsAvailable(questID) then
                            local low = AV:IsLowLevel(questID)
                            if not low or S.showLowLevel then
                                addEntityPins(out, index, low and "lowlevel" or "available",
                                    entityKind, entityID, mapID, questID)
                            end
                        end
                    end
                end
            end
        end
        -- Dadores deducidos por cadena que solo tienen un área del mapa
        for _, questID in ipairs(DB.startPois[mapID] or {}) do
            local q = DB:GetQuest(questID)
            if AV:IsAvailable(questID) then
                local low = AV:IsLowLevel(questID)
                if not low or S.showLowLevel then
                    local p = q.startPoi[mapID]
                    addPoiPin(out, index, low and "lowlevel" or "available", p[1], p[2], questID)
                end
            end
        end
    end

    -- Activas: entregas y objetivos.
    for questID, state in pairs(QS.active) do
        local q = DB:GetQuest(questID)
        if q then
            local poi = q.pois and q.pois[mapID]
            -- El "?" sale solo cuando ya puedes entregarla (o siempre, con /senda pendientes).
            if S.showTurnIn and (state.complete or S.showTurnInWait) then
                local kind = state.complete and "turnin" or "turnin_wait"
                addStarterOrEnder(out, index, kind, q.finish, mapID, questID)
                if poi and poi.finish and not entityOnMap(q.finish, mapID) then
                    addPoiPin(out, index, kind, poi.finish[1], poi.finish[2], questID)
                end
            end
            if S.showObjectives and not state.complete then
                local covered = addObjectivePins(out, index, q, questID, state, mapID, S.maxObjectiveIcons)
                -- Áreas aproximadas solo para objetivos que no tienen ningún bicho/objeto ubicado.
                for _, a in ipairs(poi and poi.obj or {}) do
                    local live = state.objectives and state.objectives[a[1] + 1]
                    if not (live and live.finished) and not covered[a[1] + 1] then
                        if S.objectiveIcons then
                            -- Con iconos: un solo icono en el centro de la zona, en vez del círculo.
                            local obj = q.objectives and q.objectives[a[1] + 1]
                            local icon = MP.AreaIcon(obj)
                            addPinAt(out, index, "objective", "poi", 0, a[2], a[3], questID, icon)
                            index["objective:poi:0:" .. a[2] .. ":" .. a[3]].area = true
                        else
                            addPoiPin(out, index, "area", a[2], a[3], questID, a[4])
                        end
                    end
                end
            end
        end
    end

    -- Los pines con más prioridad se dibujan encima.
    table.sort(out, function(a, b)
        return MP.styles[a.kind].layer < MP.styles[b.kind].layer
    end)
    self:AssignColors(out)
    return out
end

---------------------------------------------------------------------------
-- Pintado
---------------------------------------------------------------------------

local pool, used = {}, 0
local canvas -- WorldMapButton

local function tooltipFrame()
    if WorldMapTooltip and WorldMapFrame:IsShown() then return WorldMapTooltip end
    return GameTooltip
end

--- Estilo con el que se dibuja un pin (también lo usa el minimapa).
function MP:StyleFor(pin)
    local style = self.styles[pin.kind]
    if ns.settings.objectiveIcons then
        if pin.kind == "objective" and pin.icon then
            style = self.objectiveIcons[pin.icon] or style
        elseif pin.kind == "available" or pin.kind == "lowlevel" or pin.kind == "turnin" or pin.kind == "turnin_wait" then
            style = self.signStyles[pin.kind .. ":" .. self:PinDifficulty(pin)] or style
        end
    end
    return style
end

local function pinOnEnter(self)
    local pin = self.data
    if not pin then return end
    local tt = tooltipFrame()
    tt:SetOwner(self, "ANCHOR_RIGHT")
    if pin.entityKind == "poi" then
        tt:AddLine((pin.kind == "area" or pin.area) and L.QUEST_AREA or L.QUEST_PLACE, 1, 1, 1)
    else
        local entity = ns.DB:GetEntity(pin.entityKind, pin.entityID)
        tt:AddLine(entity and entity.name or ("#" .. pin.entityID), 1, 1, 1)
    end
    for _, questID in ipairs(pin.quests) do
        local q = ns.DB:GetQuest(questID)
        local name = q and q.name or ("#" .. questID)
        local label
        if pin.kind == "available" or pin.kind == "lowlevel" then
            label = L.AVAILABLE
        elseif pin.kind == "turnin" then
            label = L.TURN_IN
        elseif pin.kind == "turnin_wait" then
            label = L.TURN_IN_NOT_READY
        else
            label = L.OBJECTIVE
        end
        local lvl = (q and q.level and q.level > 0) and (" [" .. q.level .. "]") or ""
        local c = pin.colors and pin.colors[questID]
        if c then
            tt:AddDoubleLine(name .. lvl, label, c[1], c[2], c[3], 0.7, 0.7, 0.7)
        else
            tt:AddDoubleLine(name .. lvl, label, 1, 0.82, 0, 0.7, 0.7, 0.7)
        end
        if pin.kind == "objective" then
            local state = ns.QuestState:GetActive(questID)
            for _, o in ipairs(state and state.objectives or {}) do
                if not o.finished and o.text then tt:AddLine("  " .. o.text, 0.8, 0.8, 0.8) end
            end
        end
    end
    tt:AddLine(L.ARROW_CLICK, 0.5, 0.8, 1)
    if ns.settings.debug then
        tt:AddLine(string.format("%s %d  (%.1f, %.1f)", pin.entityKind, pin.entityID, pin.x * 100, pin.y * 100), 0.5, 0.5, 0.5)
    end
    tt:Show()
end

local function pinOnLeave()
    tooltipFrame():Hide()
end

-- Clic derecho en un "!" -> ocultar esas misiones (se deshace con /senda ignorar limpiar).
local function pinOnClick(self, button)
    local pin = self.data
    if button ~= "RightButton" or not pin then return end
    if pin.kind ~= "available" and pin.kind ~= "lowlevel" then return end
    for _, questID in ipairs(pin.quests) do
        ns.charSettings.ignored[questID] = true
        local q = ns.DB:GetQuest(questID)
        ns:Print("oculta:", q and q.name or questID)
    end
    ns:RequestRefresh()
end

MP.PinOnEnter, MP.PinOnLeave, MP.PinOnClick = pinOnEnter, pinOnLeave, pinOnClick

local function acquirePin()
    used = used + 1
    local f = pool[used]
    if not f then
        f = CreateFrame("Button", nil, canvas)
        local mask = "Interface\\CHARACTERFRAME\\TempPortraitAlphaMask"
        f.ring = f:CreateTexture(nil, "BACKGROUND")      -- borde dorado
        f.ring:SetTexture(mask)
        f.ring:SetAllPoints()
        f.ring:SetVertexColor(0.78, 0.62, 0.25, 1)
        f.bg = f:CreateTexture(nil, "BORDER")            -- fondo negro
        f.bg:SetTexture(mask)
        f.bg:SetPoint("TOPLEFT", 1.5, -1.5)
        f.bg:SetPoint("BOTTOMRIGHT", -1.5, 1.5)
        f.bg:SetVertexColor(0.05, 0.04, 0.03, 0.95)
        f.icon = f:CreateTexture(nil, "OVERLAY")
        f.outline = f:CreateTexture(nil, "ARTWORK")      -- borde de color de la misión
        f.outline:SetAllPoints()
        f:SetScript("OnEnter", pinOnEnter)
        f:SetScript("OnLeave", pinOnLeave)
        f:RegisterForClicks("LeftButtonUp")
        f:SetScript("OnClick", function(self) if ns.Arrow then ns.Arrow:SetTarget(self.data, MP.renderedMap) end end)
        pool[used] = f
    end
    return f
end

local function releaseAll()
    for i = 1, used do
        pool[i]:Hide()
        pool[i].data = nil
    end
    used = 0
end

function MP:Render()
    releaseAll()
    if not canvas or not WorldMapFrame:IsShown() or not ns.settings.enabled then return end

    local mapID = GetCurrentMapAreaID()
    MP.renderedMap = mapID
    local pins = self:Collect(mapID)
    local w, h = canvas:GetWidth(), canvas:GetHeight()
    local scale = ns.settings.pinScale
    local baseLevel = canvas:GetFrameLevel() + 5

    for i, pin in ipairs(pins) do
        local style = self:StyleFor(pin)
        local f = acquirePin()
        f.data = pin
        local size = style.size * scale
        if pin.kind == "area" then size = math.max(12, (pin.radius or 2) / 100 * w * 2) end
        f:SetSize(size, size)
        f:SetFrameLevel(baseLevel + style.layer)
        f.icon:ClearAllPoints()
        if style.circle then
            f.ring:Show(); f.bg:Show()
            f.ring:SetDesaturated(style.desaturate and true or false)
            f.icon:SetPoint("TOPLEFT", f, "TOPLEFT", style.size * scale * 0.18, -style.size * scale * 0.15)
            f.icon:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -style.size * scale * 0.18, style.size * scale * 0.21)
        else
            f.ring:Hide(); f.bg:Hide()
            f.icon:SetAllPoints()
        end
        f.icon:SetTexture(style.texture)
        if style.ring and pin.color then
            f.outline:SetTexture(style.ring)
            f.outline:SetVertexColor(pin.color[1], pin.color[2], pin.color[3], 1)
            f.outline:Show()
        else
            f.outline:Hide()
        end
        if style.crop then f.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92) else f.icon:SetTexCoord(0, 1, 0, 1) end
        f.icon:SetDesaturated(style.desaturate and true or false)
        if style.color then
            f.icon:SetVertexColor(unpack(style.color))
        else
            f.icon:SetVertexColor(1, 1, 1, style.alpha or 1)
        end
        f:ClearAllPoints()
        f:SetPoint("CENTER", canvas, "TOPLEFT", pin.x * w, -pin.y * h)
        f:Show()
    end
    ns:Debug(#pins, "pines en mapa", mapID)
end

--- /senda diag: datos para encontrar por qué no se ven los pines.
function MP:Diagnose()
    local out = {}
    local function add(...) out[#out + 1] = strjoin(" ", tostringall(...)) end
    add("version", ns.version, "enabled", ns.settings.enabled, "canvas", canvas and (canvas:GetName() or "?") or "NIL")
    add("mapa abierto", WorldMapFrame and WorldMapFrame:IsShown(), "mapID", GetCurrentMapAreaID())
    local ok, pins = pcall(self.Collect, self, GetCurrentMapAreaID())
    add("Collect", ok and #pins or ("ERROR " .. tostring(pins)))
    if canvas then
        add("canvas", math.floor(canvas:GetWidth()), "x", math.floor(canvas:GetHeight()), "nivel", canvas:GetFrameLevel(),
            "visible", canvas:IsVisible(), "strata", canvas:GetFrameStrata())
    end
    local AV, DB, QS = ns.Availability, ns.DB, ns.QuestState
    local nDone, nActive = 0, 0
    for _ in pairs(QS.completed) do nDone = nDone + 1 end
    for _ in pairs(QS.active) do nActive = nActive + 1 end
    add("jugador nivel", AV.player.level, "raza", AV.player.raceBit, "clase", AV.player.classBit,
        "completadas", nDone, "en registro", nActive)
    local mapID, reasons, examples = GetCurrentMapAreaID(), {}, {}
    for npcID, qids in pairs(DB.startsAt.npc) do
        local e = DB.npcs[npcID]
        if e and e.spawns and e.spawns[mapID] then
            for _, qid in ipairs(qids) do
                local okA, why = AV:IsAvailable(qid)
                local key = okA and "DISPONIBLE" or tostring(why):gsub(" %d+", "")
                reasons[key] = (reasons[key] or 0) + 1
                if not examples[key] then examples[key] = qid end
            end
        end
    end
    for k, n in pairs(reasons) do add("  ", k, n, "(ej.", examples[k] .. ")") end
    local ok2, err = pcall(self.Render, self)
    add("Render", ok2 and "ok" or ("ERROR " .. tostring(err)), "pines creados", used)
    local f = pool[1]
    if f and used > 0 then
        local p, rel, rp, x, y = f:GetPoint(1)
        add("pin1 visible", f:IsVisible(), "nivel", f:GetFrameLevel(), "alpha", f:GetEffectiveAlpha(),
            "tam", math.floor(f:GetWidth()), "pos", p, rp, x and math.floor(x), y and math.floor(y),
            "padre", f:GetParent() and f:GetParent():GetName())
        add("icono", f.icon:GetTexture(), "visible", f.icon:IsVisible())
    end
    for _, line in ipairs(out) do ns:Print(line) end
end

function MP:OnEnable()
    canvas = WorldMapButton
    if not canvas then
        ns:Print("No se encontró WorldMapButton; ¿cliente distinto de 7.x?")
        return
    end
    ns:RegisterEvent("WORLD_MAP_UPDATE", function() MP:Render() end)
    WorldMapFrame:HookScript("OnShow", function() MP:Render() end)
    ns:On("SENDA_REFRESH", function() MP:Render() end)
end
