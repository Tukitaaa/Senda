-- Senda (c) 2026 Tzors. Todos los derechos reservados. Ver LICENSE.txt.
-- Flecha guía: apunta al objetivo, entrega o "!" más cercano de tu zona (o al
-- pin que elijas con clic en el mapa) y dice a cuántas yardas está.
--
-- Cuentas: posiciones del mapa (0-1) a yardas con el tamaño de la zona. El
-- ángulo hacia el destino se mide como GetPlayerFacing(): 0 = norte y crece
-- hacia el oeste (sentido contrario a las agujas del reloj).

local _, ns = ...
local L = ns.L

local AR = ns:NewModule("Arrow")
ns.Arrow = AR

local UPDATE_EVERY = 0.05
local ARRIVED = 8            -- yardas: ya llegaste
local RECALC_EVERY = 1.0     -- en modo automático, cada cuánto se busca el más cercano

-- Prioridad en modo automático: primero lo que ya puedes entregar, luego los
-- objetivos de tus misiones y por último las misiones nuevas.
AR.priority = { turnin = 1, objective = 2, area = 2, available = 3 }

local frame
local mapID, mapW, mapH
local target          -- { x, y, mapID, pin, manual }
local elapsed, sinceRecalc = 0, 0
local pins, needPins = {}, true   -- pines de la zona: se recalculan solo cuando algo cambia

---------------------------------------------------------------------------
-- Cuentas (funciones puras, se prueban fuera del juego)
---------------------------------------------------------------------------

--- Distancia en yardas y ángulo (0 = norte, hacia el oeste positivo).
function AR.Bearing(px, py, tx, ty, w, h)
    local dx, dy = (tx - px) * w, (ty - py) * h
    local dist = math.sqrt(dx * dx + dy * dy)
    local angle = math.atan2(-dx, -dy)
    return dist, angle
end

--- Rotación de la flecha en pantalla (radianes, sentido antihorario).
function AR.Rotation(angle, facing)
    return ((angle - (facing or 0)) % (2 * math.pi))
end

--- Elige el pin más conveniente: menor prioridad y, a igualdad, el más cercano.
function AR.Pick(pins, px, py, w, h)
    local best, bestP, bestD
    for _, pin in ipairs(pins) do
        local p = AR.priority[pin.kind]
        if p then
            local d = AR.Bearing(px, py, pin.x, pin.y, w, h)
            if not best or p < bestP or (p == bestP and d < bestD) then
                best, bestP, bestD = pin, p, d
            end
        end
    end
    return best, bestD
end

---------------------------------------------------------------------------
-- Ventana
---------------------------------------------------------------------------

local function questTitle(pin)
    local q = pin and pin.quests and ns.DB:GetQuest(pin.quests[1])
    local name = q and q.name or ""
    if pin and #pin.quests > 1 then name = name .. " (+" .. (#pin.quests - 1) .. ")" end
    return name
end

local function kindLabel(pin)
    if not pin then return "" end
    if pin.kind == "turnin" then return L.TURN_IN end
    if pin.kind == "available" then return L.AVAILABLE end
    return L.OBJECTIVE
end

function AR:Build()
    if frame then return end
    frame = CreateFrame("Button", "SendaArrow", UIParent)
    frame:SetSize(56, 56)
    frame:SetPoint("TOP", UIParent, "TOP", 0, -120)
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:RegisterForClicks("RightButtonUp")
    frame:SetClampedToScreen(true)
    frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
    frame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local _, _, _, x, y = self:GetPoint()
        ns.settings.arrowPos = { x, y }
    end)
    -- Clic derecho: dejar de seguir el pin elegido (vuelve al modo automático).
    frame:SetScript("OnClick", function() AR:Clear() end)

    frame.arrow = frame:CreateTexture(nil, "ARTWORK")
    frame.arrow:SetTexture("Interface\\Minimap\\MinimapArrow")
    frame.arrow:SetAllPoints()
    frame.arrow:SetVertexColor(1, 0.82, 0)

    frame.title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    frame.title:SetPoint("TOP", frame, "BOTTOM", 0, -2)
    frame.dist = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    frame.dist:SetPoint("TOP", frame.title, "BOTTOM", 0, -2)

    local pos = ns.settings.arrowPos
    if type(pos) == "table" and pos[1] then
        frame:ClearAllPoints()
        frame:SetPoint("TOP", UIParent, "TOP", pos[1], pos[2])
    end
    frame:Hide()
end

---------------------------------------------------------------------------
-- Destino
---------------------------------------------------------------------------

--- Guiar hacia un pin concreto (clic en el mapa o el minimapa).
function AR:SetTarget(pin, onMapID)
    if not pin then return end
    target = { x = pin.x, y = pin.y, mapID = onMapID, pin = pin, manual = true }
    if not ns.settings.showArrow then
        ns.settings.showArrow = true
        if ns.Options then ns.Options:Refresh() end
    end
    ns:Print(string.format(L.ARROW_TO, questTitle(pin)))
end

function AR:Clear()
    target = nil
    sinceRecalc = RECALC_EVERY
end

function AR:GetTarget() return target end

local function refreshZone()
    if WorldMapFrame:IsShown() then return false end
    SetMapToCurrentZone()
    mapID = GetCurrentMapAreaID()
    local _, left, top, right, bottom = GetCurrentMapZone()
    if left and right and left ~= right and top ~= bottom then
        mapW, mapH = left - right, top - bottom
    else
        mapW, mapH = nil, nil
    end
    return true
end

function AR:Update(dt)
    if not frame then return end
    local S = ns.settings
    if not (S.enabled and S.showArrow) then frame:Hide() return end
    if WorldMapFrame:IsShown() then return end   -- no tocar el mapa mientras lo miras
    if GetCurrentMapAreaID() ~= mapID or not mapW then
        refreshZone()
        needPins = true
    end
    local px, py = GetPlayerMapPosition("player")
    if not mapW or not px or (px == 0 and py == 0) then frame:Hide() return end

    sinceRecalc = sinceRecalc + dt
    if (not target or not target.manual) and sinceRecalc >= RECALC_EVERY then
        sinceRecalc = 0
        if needPins then
            pins = ns.MapPins:Collect(mapID)
            needPins = false
        end
        local pin = AR.Pick(pins, px, py, mapW, mapH)
        target = pin and { x = pin.x, y = pin.y, mapID = mapID, pin = pin } or nil
    end
    if not target then frame:Hide() return end

    frame.title:SetText(questTitle(target.pin))
    if target.mapID and target.mapID ~= mapID then
        -- El pin elegido es de otra zona: sin flecha, solo el aviso.
        frame.arrow:Hide()
        local z = ns.DB.zones[target.mapID]
        frame.dist:SetText(string.format(L.ARROW_OTHER_ZONE, z and z.name or "?"))
        frame:Show()
        return
    end
    frame.arrow:Show()
    local dist, angle = AR.Bearing(px, py, target.x, target.y, mapW, mapH)
    if dist <= ARRIVED then
        frame.dist:SetText(L.ARROW_ARRIVED)
        frame.arrow:SetVertexColor(0.3, 1, 0.3)
        if target.manual then target.manual = false end   -- vuelve al automático
    else
        frame.dist:SetText(string.format("%s - %d %s", kindLabel(target.pin), dist, L.YARDS))
        frame.arrow:SetVertexColor(1, 0.82, 0)
    end
    frame.arrow:SetRotation(AR.Rotation(angle, GetPlayerFacing()))
    frame:Show()
end

function AR:OnEnable()
    self:Build()
    sinceRecalc = RECALC_EVERY
    local driver = CreateFrame("Frame")
    driver:SetScript("OnUpdate", function(_, dt)
        elapsed = elapsed + dt
        if elapsed < UPDATE_EVERY then return end
        AR:Update(elapsed)
        elapsed = 0
    end)
    for _, e in ipairs({ "ZONE_CHANGED", "ZONE_CHANGED_INDOORS", "ZONE_CHANGED_NEW_AREA", "PLAYER_ENTERING_WORLD" }) do
        ns:RegisterEvent(e, function() mapID = nil; needPins = true end)
    end
    ns:On("SENDA_REFRESH", function()
        sinceRecalc = RECALC_EVERY
        needPins = true
        -- Si la misión del pin elegido ya no tiene ese pin (objetivo cumplido), se suelta.
        if target and target.manual and target.pin and target.mapID == mapID and mapW then
            local still = false
            for _, p in ipairs(ns.MapPins:Collect(mapID)) do
                if p.kind == target.pin.kind and p.x == target.x and p.y == target.y then still = true break end
            end
            if not still then AR:Clear() end
        end
    end)
end
