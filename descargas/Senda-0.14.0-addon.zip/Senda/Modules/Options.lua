-- Senda (c) 2026 Tzors. Todos los derechos reservados. Ver LICENSE.txt.
-- Panel de opciones (Interfaz > Accesorios > Senda) y botón en el minimapa.
-- Todo lo que se puede hacer con /senda, con casillas.

local _, ns = ...
local L = ns.L

local OP = ns:NewModule("Options")
ns.Options = OP

-- Casillas del panel: { clave en ns.settings, texto, ayuda }
OP.checks = {
    { "enabled",        "OPT_ENABLED" },
    { "showAvailable",  "OPT_AVAILABLE" },
    { "showLowLevel",   "OPT_LOWLEVEL" },
    { "showTurnIn",     "OPT_TURNIN" },
    { "showTurnInWait", "OPT_TURNIN_WAIT" },
    { "showObjectives", "OPT_OBJECTIVES" },
    { "objectiveIcons", "OPT_ICONS" },
    { "showMinimap",    "OPT_MINIMAP" },
    { "showArrow",      "OPT_ARROW" },
    { "hideGamePOI",    "OPT_HIDE_GAME" },
    { "tooltips",       "OPT_TOOLTIPS" },
    { "share",          "OPT_SHARE" },
    { "shareChannel",   "OPT_SHARE_CHANNEL" },
    { "minimapButton",  "OPT_MINIMAP_BUTTON" },
}

local function text(key) return L[key] or key end

--- Cambia una opción y avisa al resto del addon.
function OP:Set(key, value)
    ns.settings[key] = value and true or false
    if key == "minimapButton" then self:UpdateButton() end
    if key == "hideGamePOI" or key == "enabled" then self:ApplyGamePOI() end
    if key == "shareChannel" and value and ns.Sync and ns.Sync.JoinChannel then ns.Sync:JoinChannel() end
    ns:RequestRefresh()
end

---------------------------------------------------------------------------
-- Panel
---------------------------------------------------------------------------

local panel
local boxes = {}

local function label(parent, name, fallback)
    local fs = (name and _G[name]) or (parent.CreateFontString and parent:CreateFontString(nil, "ARTWORK", "GameFontHighlight"))
    return fs
end

function OP:Refresh()
    for key, cb in pairs(boxes) do
        if cb.SetChecked then cb:SetChecked(ns.settings[key] and true or false) end
    end
    if panel and panel.scale and panel.scale.SetValue then panel.scale:SetValue(ns.settings.pinScale or 1) end
end

function OP:BuildPanel()
    if panel or not InterfaceOptions_AddCategory then return end
    panel = CreateFrame("Frame", "SendaOptionsPanel", UIParent)
    panel.name = "Senda"

    local title = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 16, -16)
    title:SetText("Senda " .. ns.version)
    local sub = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    sub:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -6)
    sub:SetText(text("OPT_SUBTITLE"))

    local prev
    for i, c in ipairs(self.checks) do
        local key = c[1]
        local name = "SendaOptionsCheck" .. i
        local cb = CreateFrame("CheckButton", name, panel, "InterfaceOptionsCheckButtonTemplate")
        if i == 1 then
            cb:SetPoint("TOPLEFT", sub, "BOTTOMLEFT", -2, -14)
        elseif i == 8 then
            cb:SetPoint("TOPLEFT", sub, "BOTTOMLEFT", 300, -14)   -- segunda columna
        else
            cb:SetPoint("TOPLEFT", prev, "BOTTOMLEFT", 0, -4)
        end
        local fs = label(cb, name .. "Text")
        if fs then
            fs:SetText(text(c[2]))
            if fs.SetWidth then fs:SetWidth(250) end
            if fs.SetJustifyH then fs:SetJustifyH("LEFT") end
        end
        cb.tooltipText = text(c[2])
        cb.tooltipRequirement = L[c[2] .. "_TIP"]
        cb:SetScript("OnClick", function(self) OP:Set(key, self:GetChecked()) end)
        boxes[key] = cb
        prev = cb
    end

    -- Tamaño de los iconos del mapa
    local slider = CreateFrame("Slider", "SendaOptionsScale", panel, "OptionsSliderTemplate")
    slider:SetPoint("TOPLEFT", prev, "BOTTOMLEFT", 6, -36)
    slider:SetWidth(220)
    slider:SetMinMaxValues(0.6, 1.6)
    slider:SetValueStep(0.1)
    if slider.SetObeyStepOnDrag then slider:SetObeyStepOnDrag(true) end
    if _G.SendaOptionsScaleText then _G.SendaOptionsScaleText:SetText(text("OPT_SCALE")) end
    if _G.SendaOptionsScaleLow then _G.SendaOptionsScaleLow:SetText("60%") end
    if _G.SendaOptionsScaleHigh then _G.SendaOptionsScaleHigh:SetText("160%") end
    slider:SetScript("OnValueChanged", function(_, v)
        v = math.floor(v * 10 + 0.5) / 10
        if v ~= ns.settings.pinScale then
            ns.settings.pinScale = v
            ns:RequestRefresh()
        end
    end)
    panel.scale = slider

    -- Pie: cómo enviar los datos y estado
    local foot = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    foot:SetPoint("BOTTOMLEFT", 16, 16)
    foot:SetPoint("BOTTOMRIGHT", -16, 16)
    foot:SetJustifyH("LEFT")
    foot:SetText(text("OPT_FOOTER"))

    panel:SetScript("OnShow", function() OP:Refresh() end)
    panel.refresh = function() OP:Refresh() end
    InterfaceOptions_AddCategory(panel)
end

function OP:Open()
    if not panel then self:BuildPanel() end
    if not panel then return end
    -- Abrir dos veces: el juego a veces no baja hasta la categoría la primera vez.
    InterfaceOptionsFrame_OpenToCategory(panel)
    InterfaceOptionsFrame_OpenToCategory(panel)
end

---------------------------------------------------------------------------
-- Botón del minimapa (se arrastra por el borde)
---------------------------------------------------------------------------

local button

--- Posición del botón en el borde del minimapa según el ángulo (grados).
function OP.ButtonOffset(angle, radius)
    local a = math.rad(angle or 200)
    return math.cos(a) * radius, math.sin(a) * radius
end

local function placeButton()
    if not button then return end
    local r = (Minimap:GetWidth() / 2) + 10
    local x, y = OP.ButtonOffset(ns.settings.minimapButtonAngle, r)
    button:ClearAllPoints()
    button:SetPoint("CENTER", Minimap, "CENTER", x, y)
end

function OP:UpdateButton()
    if not button then return end
    if ns.settings.minimapButton then button:Show() else button:Hide() end
    button.icon:SetDesaturated(not ns.settings.enabled)
end

function OP:BuildButton()
    if button or not Minimap then return end
    button = CreateFrame("Button", "SendaMinimapButton", Minimap)
    button:SetSize(31, 31)
    button:SetFrameStrata("MEDIUM")
    button:SetFrameLevel(8)
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    button:RegisterForDrag("LeftButton")
    button:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

    local bg = button:CreateTexture(nil, "BACKGROUND")
    bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
    bg:SetSize(20, 20)
    bg:SetPoint("TOPLEFT", 7, -5)
    local icon = button:CreateTexture(nil, "ARTWORK")
    icon:SetTexture("Interface\\AddOns\\Senda\\Textures\\avail_yellow")
    icon:SetSize(18, 18)
    icon:SetPoint("TOPLEFT", 7, -6)
    button.icon = icon
    local border = button:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    border:SetSize(53, 53)
    border:SetPoint("TOPLEFT")

    button:SetScript("OnClick", function(_, which)
        if which == "RightButton" then
            ns.settings.enabled = not ns.settings.enabled
            ns:Print("Senda", ns.settings.enabled and L.ENABLED or L.DISABLED)
            OP:UpdateButton()
            OP:ApplyGamePOI()
            ns:RequestRefresh()
        else
            OP:Open()
        end
    end)
    button:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            cx, cy = cx / scale, cy / scale
            ns.settings.minimapButtonAngle = math.deg(math.atan2(cy - my, cx - mx)) % 360
            placeButton()
        end)
    end)
    button:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    button:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("Senda " .. ns.version)
        GameTooltip:AddLine(text("OPT_BUTTON_LEFT"), 1, 1, 1)
        GameTooltip:AddLine(text("OPT_BUTTON_RIGHT"), 1, 1, 1)
        GameTooltip:AddLine(text("OPT_BUTTON_DRAG"), 0.7, 0.7, 0.7)
        GameTooltip:Show()
    end)
    button:SetScript("OnLeave", function() GameTooltip:Hide() end)

    placeButton()
    self:UpdateButton()
end

---------------------------------------------------------------------------
-- Iconos de misiones del propio juego
---------------------------------------------------------------------------

--- Oculta (o devuelve) los iconos y zonas de misiones que dibuja el juego en
--- el mapa y el minimapa, para que no se vean repetidos con los de Senda.
--- Se guarda el valor original para devolverlo tal cual al desactivarlo.
function OP:ApplyGamePOI()
    if not GetCVar or not SetCVar or GetCVar("questPOI") == nil then return end
    local S = ns.settings
    if S.hideGamePOI and S.enabled then
        if S.gamePOIBackup == nil then S.gamePOIBackup = GetCVar("questPOI") end
        if GetCVar("questPOI") ~= "0" then SetCVar("questPOI", "0") end
    elseif S.gamePOIBackup ~= nil then
        SetCVar("questPOI", S.gamePOIBackup)
        S.gamePOIBackup = nil
    end
    if WorldMapFrame and WorldMapFrame:IsShown() and WorldMapFrame_Update then WorldMapFrame_Update() end
end

function OP:OnEnable()
    self:ApplyGamePOI()
    self:BuildPanel()
    self:BuildButton()
    ns:On("SENDA_REFRESH", function() OP:UpdateButton() end)
end
