-- Senda (c) 2026 Tzors. Todos los derechos reservados. Ver LICENSE.txt.
-- Textos de la interfaz. Los nombres de misiones y PNJ vienen de la base de
-- datos (el exportador los genera en el idioma configurado).

local _, ns = ...

local L = setmetatable({}, { __index = function(_, k) return k end })
ns.L = L

local locale = GetLocale()

-- Inglés (base)
L.AVAILABLE      = "Available quest"
L.TURN_IN        = "Turn in"
L.TURN_IN_NOT_READY = "Turn in (not completed)"
L.OBJECTIVE      = "Objective"
L.QUEST_AREA     = "Objective area"
L.QUEST_PLACE    = "Quest location (approximate)"
L.STARTS         = "Starts"
L.ENDS           = "Ends"
L.LEVEL          = "Level"
L.ENABLED        = "enabled"
L.DISABLED       = "disabled"
L.HELP = {
    "/senda - toggle map pins",
    "/senda opciones - options panel (also: minimap button)",
    "/senda boton - show/hide the minimap button",
    "/senda disponibles | entregas | objetivos - toggle each pin type",
    "/senda grises - toggle low-level quests",
    "/senda ignorar <questID> - hide a quest",
    "/senda demo - demo pins (to test the map)",
    "/senda info - database status",
    "/senda por <questID> - why a quest is (not) available",
    "/senda iconos - Senda icons or the classic ones",
    "/senda minimapa - show pins on the minimap",
    "/senda flecha - guide arrow (click a pin to follow it)",
    "/senda juego - hide/show the game's own quest icons",
    "/senda pendientes - also show '?' for unfinished quests",
    "/senda compartir - share what you learn (group, guild, friends, other Senda users)",
    "/senda archivo - how to send your data to improve the addon",
    "/senda debug",
}
L.ARROW_TO = "Arrow: guiding you to %s. Right-click the arrow to go back to automatic."
L.ARROW_OTHER_ZONE = "In another zone: %s"
L.ARROW_ARRIVED = "You are here!"
L.ARROW_CLICK = "Click: guide me with the arrow"
L.YARDS = "yd"
L.OPT_ARROW = "Guide arrow to the nearest objective"
L.NO_DATA = "|cffff6060Senda_Datos is missing.|r Install both folders from the zip (Senda and Senda_Datos) and restart the game."
L.OPT_HIDE_GAME = "Hide the game's own quest icons"
L.OPT_SUBTITLE = "Quest helper: quest givers, turn-ins and objectives on your map."
L.OPT_ENABLED = "Show Senda pins"
L.OPT_AVAILABLE = "Available quests (!)"
L.OPT_LOWLEVEL = "Also low-level (gray) quests"
L.OPT_TURNIN = "Turn-ins (?) of finished quests"
L.OPT_TURNIN_WAIT = "Also turn-ins of unfinished quests"
L.OPT_OBJECTIVES = "Objectives of your quests"
L.OPT_ICONS = "Senda icons (off = classic dots)"
L.OPT_MINIMAP = "Pins on the minimap"
L.OPT_TOOLTIPS = "Quest info in tooltips"
L.OPT_SHARE = "Share what I learn (group, guild, friends)"
L.OPT_SHARE_CHANNEL = "...and with any Senda user"
L.OPT_MINIMAP_BUTTON = "Minimap button"
L.OPT_SCALE = "Map icon size"
L.OPT_FOOTER = "Everything you learn is saved in WTF\\Account\\<account>\\SavedVariables\\Senda.lua. Send it to improve Senda: github.com/Tukitaaa/Senda"
L.OPT_BUTTON_LEFT = "Left click: options"
L.OPT_BUTTON_RIGHT = "Right click: show/hide pins"
L.OPT_BUTTON_DRAG = "Drag to move"
L.DB_STATUS = "Database: %d quests, %d NPCs, %d objects, %d zones."
L.LEARN_STATUS = "Learned while playing: %d NPCs, %d objects, %d quest givers, %d turn-ins."
L.NEW_VERSION = "|cffffd100There is a new version of Senda (%s).|r Download it from github.com/Tukitaaa/Senda"
L.SHARE_STATUS = "Sharing with group/guild: %s. Received this session: %d."
L.FILE_HELP = {
    "Everything you learn is saved in this file (after logging out or /reload):",
    "WoW\\WTF\\Account\\<YOUR ACCOUNT>\\SavedVariables\\Senda.lua",
    "Send that file to the addon author: it is merged with everyone else's and comes in the next version.",
}

if locale == "esES" or locale == "esMX" then
    L.AVAILABLE      = "Misión disponible"
    L.TURN_IN        = "Entregar"
    L.TURN_IN_NOT_READY = "Entregar (sin completar)"
    L.OBJECTIVE      = "Objetivo"
    L.QUEST_AREA     = "Zona del objetivo"
    L.QUEST_PLACE    = "Lugar de la misión (aproximado)"
    L.STARTS         = "Empieza"
    L.ENDS           = "Termina"
    L.LEVEL          = "Nivel"
    L.ENABLED        = "activado"
    L.DISABLED       = "desactivado"
    L.HELP = {
        "/senda - activar/desactivar pines del mapa",
        "/senda opciones - panel de opciones (también con el botón del minimapa)",
        "/senda boton - mostrar/ocultar el botón del minimapa",
        "/senda disponibles | entregas | objetivos - activar cada tipo de pin",
        "/senda grises - mostrar misiones de nivel bajo",
        "/senda ignorar <questID> - ocultar una misión",
        "/senda demo - pines de demostración (para probar el mapa)",
        "/senda info - estado de la base de datos",
        "/senda volcar - guardar límites de mapas para el exportador",
        "/senda por <questID> - por qué una misión (no) está disponible",
        "/senda iconos - iconos de Senda o los clásicos",
        "/senda minimapa - mostrar pines en el minimapa",
        "/senda flecha - flecha guía (clic en un pin para seguirlo)",
        "/senda juego - ocultar/mostrar los iconos de misiones del juego",
        "/senda pendientes - mostrar también el '?' de misiones sin terminar",
        "/senda compartir - compartir lo que aprendes (grupo, hermandad, amigos y otros con Senda)",
        "/senda archivo - cómo enviar tus datos para mejorar el addon",
        "/senda debug",
    }
    L.ARROW_TO = "Flecha: te llevo a %s. Clic derecho en la flecha para volver al modo automático."
    L.ARROW_OTHER_ZONE = "En otra zona: %s"
    L.ARROW_ARRIVED = "¡Llegaste!"
    L.ARROW_CLICK = "Clic: guiarme con la flecha"
    L.YARDS = "m"
    L.OPT_ARROW = "Flecha guía al objetivo más cercano"
    L.NO_DATA = "|cffff6060Falta Senda_Datos.|r Copia las dos carpetas del zip (Senda y Senda_Datos) y reinicia el juego."
    L.OPT_HIDE_GAME = "Ocultar los iconos de misiones del juego"
    L.OPT_SUBTITLE = "Ayuda para misiones: dónde empiezan, dónde se entregan y sus objetivos."
    L.OPT_ENABLED = "Mostrar los iconos de Senda"
    L.OPT_AVAILABLE = "Misiones disponibles (!)"
    L.OPT_LOWLEVEL = "También misiones de nivel bajo (grises)"
    L.OPT_TURNIN = "Entregas (?) de misiones terminadas"
    L.OPT_TURNIN_WAIT = "También entregas de misiones sin terminar"
    L.OPT_OBJECTIVES = "Objetivos de tus misiones"
    L.OPT_ICONS = "Iconos de Senda (apagado = puntos clásicos)"
    L.OPT_MINIMAP = "Iconos en el minimapa"
    L.OPT_TOOLTIPS = "Info de misiones al pasar el mouse"
    L.OPT_SHARE = "Compartir lo que aprendo (grupo, hermandad, amigos)"
    L.OPT_SHARE_CHANNEL = "...y con cualquiera que use Senda"
    L.OPT_MINIMAP_BUTTON = "Botón en el minimapa"
    L.OPT_SCALE = "Tamaño de los iconos del mapa"
    L.OPT_FOOTER = "Todo lo que aprendes se guarda en WTF\\Account\\<cuenta>\\SavedVariables\\Senda.lua. Envíalo para mejorar Senda: github.com/Tukitaaa/Senda"
    L.OPT_BUTTON_LEFT = "Clic izquierdo: opciones"
    L.OPT_BUTTON_RIGHT = "Clic derecho: mostrar/ocultar iconos"
    L.OPT_BUTTON_DRAG = "Arrastrar para moverlo"
    L.DB_STATUS = "Base de datos: %d misiones, %d PNJ, %d objetos, %d zonas."
    L.LEARN_STATUS = "Aprendido jugando: %d PNJ, %d objetos, %d misiones con dador, %d con entrega."
    L.NEW_VERSION = "|cffffd100Hay una versión nueva de Senda (%s).|r Bájala de github.com/Tukitaaa/Senda"
    L.SHARE_STATUS = "Compartir con grupo/hermandad: %s. Recibido en esta sesión: %d."
    L.FILE_HELP = {
        "Todo lo que aprendes se guarda en este archivo (al salir del juego o con /reload):",
        "WoW\\WTF\\Account\\<TU CUENTA>\\SavedVariables\\Senda.lua",
        "Envía ese archivo al autor del addon: se junta con el de todos y llega en la próxima versión.",
    }
end
