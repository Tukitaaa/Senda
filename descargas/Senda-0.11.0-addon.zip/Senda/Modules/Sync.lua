-- Senda (c) 2026 Tzors. Todos los derechos reservados. Ver LICENSE.txt.
-- Compartir en vivo: lo que aprende un jugador se manda a su grupo y a su
-- hermandad (mensajes de addon, invisibles en el chat). Los demás jugadores
-- con Senda lo reciben y lo usan en su mapa al momento.
--
-- Lo recibido se guarda aparte (SendaDB.received): no se mezcla con lo que
-- aprendiste tú, así el archivo que envías para la base de datos común
-- contiene solo lo que viste con tus propios ojos.
--
-- Formato de los mensajes (prefijo "SENDA1"):
--   S;n|o;id;mapa;x;y;nombre    aparición de un PNJ (n) u objeto (o)
--   R;s|f;misión;n|o;id         la misión empieza (s) o termina (f) en él
--   O;m|o;misión;id             matar este PNJ (m) / usar este objeto (o) sirve para la misión

local _, ns = ...

local SY = ns:NewModule("Sync")
ns.Sync = SY

SY.PREFIX = "SENDA1"
local SEND_INTERVAL = 0.3   -- segundos entre mensajes (para no saturar)
local MAX_QUEUE = 300
local MAX_ID = 2147483647

local queue = {}
local sending = false

---------------------------------------------------------------------------
-- Codificar / decodificar (funciones puras, se prueban fuera del juego)
---------------------------------------------------------------------------

local KIND = { npc = "n", object = "o" }
local KIND_R = { n = "npc", o = "object" }
local SIDE = { start = "s", finish = "f" }
local SIDE_R = { s = "start", f = "finish" }
local OBJ = { monster = "m", object = "o" }
local OBJ_R = { m = "monster", o = "object" }

function SY.Encode(what, ...)
    if what == "spawn" then
        local kind, id, mapID, x, y, name = ...
        local msg = string.format("S;%s;%d;%d;%.1f;%.1f;%s", KIND[kind], id, mapID, x, y, name or "")
        return msg:sub(1, 250)
    elseif what == "rel" then
        local side, questID, kind, id = ...
        return string.format("R;%s;%d;%s;%d", SIDE[side], questID, KIND[kind], id)
    elseif what == "obj" then
        local objType, questID, id = ...
        return string.format("O;%s;%d;%d", OBJ[objType], questID, id)
    end
end

local function validID(n) return n and n > 0 and n <= MAX_ID and n == math.floor(n) end

--- Devuelve (tipo, ...) o nil si el mensaje no es válido.
function SY.Decode(msg)
    if type(msg) ~= "string" then return nil end
    local t = msg:sub(1, 1)
    if t == "S" then
        local k, id, mapID, x, y, name = strsplit(";", msg:sub(3), 6)
        id, mapID, x, y = tonumber(id), tonumber(mapID), tonumber(x), tonumber(y)
        if not (KIND_R[k] and validID(id) and validID(mapID) and x and y) then return nil end
        if x < 0 or x > 100 or y < 0 or y > 100 then return nil end
        if name == "" then name = nil end
        if name and #name > 80 then name = name:sub(1, 80) end
        return "spawn", KIND_R[k], id, mapID, x, y, name
    elseif t == "R" then
        local s, questID, k, id = strsplit(";", msg:sub(3))
        questID, id = tonumber(questID), tonumber(id)
        if not (SIDE_R[s] and KIND_R[k] and validID(questID) and validID(id)) then return nil end
        return "rel", SIDE_R[s], questID, KIND_R[k], id
    elseif t == "O" then
        local o, questID, id = strsplit(";", msg:sub(3))
        questID, id = tonumber(questID), tonumber(id)
        if not (OBJ_R[o] and validID(questID) and validID(id)) then return nil end
        return "obj", OBJ_R[o], questID, id
    end
    return nil
end

---------------------------------------------------------------------------
-- Envío
---------------------------------------------------------------------------

SY.CHANNEL = "SendaSync"     -- canal oculto donde se encuentran todos los que usan Senda
SY.CHAT_TAG = "~S~"          -- marca de los mensajes cuando el canal va por chat normal
local MAX_FRIENDS = 10
local CHAT_INTERVAL = 3      -- por chat normal, mucho más despacio (anti-spam del servidor)
local SENDER_LIMIT = 120     -- mensajes por minuto aceptados de un mismo jugador

-- "addon": el servidor deja mandar mensajes de addon al canal (invisibles).
-- "chat":  no los deja; se usa chat normal en el canal y se ocultan de la ventana.
SY.channelMode = nil

function SY.ChannelIndex()
    local id = GetChannelName and GetChannelName(SY.CHANNEL)
    if id and id > 0 then return id end
end

--- Destinos a los que mandar ahora mismo: { {tipo, destino}, ... }
function SY.Targets()
    local list = {}
    if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then
        list[#list + 1] = { "INSTANCE_CHAT" }
    elseif IsInRaid() then
        list[#list + 1] = { "RAID" }
    elseif IsInGroup() then
        list[#list + 1] = { "PARTY" }
    end
    if IsInGuild() then list[#list + 1] = { "GUILD" } end
    -- Amigos conectados (susurro invisible de addon)
    local n = 0
    for i = 1, (GetNumFriends and GetNumFriends() or 0) do
        local name, _, _, _, connected = GetFriendInfo(i)
        if name and connected and n < MAX_FRIENDS then
            n = n + 1
            list[#list + 1] = { "WHISPER", name }
        end
    end
    if SY.channelMode == "addon" and SY.ChannelIndex() then
        list[#list + 1] = { "CHANNEL", SY.ChannelIndex() }
    end
    return list
end

local function pump()
    local msg = table.remove(queue, 1)
    if not msg then
        sending = false
        return
    end
    for _, t in ipairs(SY.Targets()) do
        SendAddonMessage(SY.PREFIX, msg, t[1], t[2])
    end
    C_Timer.After(SEND_INTERVAL, pump)
end

-- Cola aparte para el canal por chat normal (solo si el servidor no deja mensajes de addon).
local chatQueue, chatSending = {}, false
local function chatPump()
    local msg = table.remove(chatQueue, 1)
    local idx = SY.ChannelIndex()
    if not msg or not idx or SY.channelMode ~= "chat" then
        chatSending = false
        return
    end
    SendChatMessage(SY.CHAT_TAG .. msg, "CHANNEL", nil, idx)
    C_Timer.After(CHAT_INTERVAL, chatPump)
end

function SY:Send(msg, urgent)
    if not msg or not ns.settings.share then return end
    if #queue >= MAX_QUEUE then table.remove(queue, 1) end
    if urgent then table.insert(queue, 1, msg) else queue[#queue + 1] = msg end
    if not sending then
        sending = true
        C_Timer.After(SEND_INTERVAL, pump)
    end
    if SY.channelMode == "chat" and SY.ChannelIndex() then
        if #chatQueue >= 50 then table.remove(chatQueue, 1) end
        if urgent then table.insert(chatQueue, 1, msg) else chatQueue[#chatQueue + 1] = msg end
        if not chatSending then
            chatSending = true
            C_Timer.After(CHAT_INTERVAL, chatPump)
        end
    end
end

-- Compatibilidad con el nombre anterior
SY.Channels = function()
    local out = {}
    for _, t in ipairs(SY.Targets()) do out[#out + 1] = t[1] end
    return out
end

---------------------------------------------------------------------------
-- Versión nueva
---------------------------------------------------------------------------

--- "0.10.2" -> número comparable (nil si no tiene ese formato).
function SY.VersionNumber(v)
    local a, b, c = tostring(v or ""):match("^(%d+)%.(%d+)%.(%d+)$")
    if not a then return nil end
    return tonumber(a) * 1000000 + tonumber(b) * 1000 + tonumber(c)
end

SY.newerVersion = nil
local repliedTo = {}

function SY:OnVersion(version, channel, sender)
    local theirs, mine = SY.VersionNumber(version), SY.VersionNumber(ns.version)
    if not theirs or not mine then return end
    if theirs > mine then
        if not SY.newerVersion or theirs > SY.VersionNumber(SY.newerVersion) then
            SY.newerVersion = version
            ns:Print(string.format(ns.L.NEW_VERSION, version))
        end
    elseif theirs < mine and sender and not repliedTo[sender] then
        -- Le avisamos a él (una vez por sesión) de que hay una más nueva.
        repliedTo[sender] = true
        SendAddonMessage(SY.PREFIX, "V;" .. ns.version, "WHISPER", sender)
    end
end

---------------------------------------------------------------------------
-- Recepción
---------------------------------------------------------------------------

SY.receivedCount = 0

local function isMe(sender)
    if not sender then return true end
    local short = Ambiguate and Ambiguate(sender, "none") or sender
    return short == UnitName("player") or sender == UnitName("player")
end

-- Límite por jugador: si alguien manda demasiado (spam o datos falsos), se ignora.
local perSender, windowStart = {}, 0
local function allowed(sender)
    local now = GetTime()
    if now - windowStart > 60 then
        wipe(perSender)
        windowStart = now
    end
    perSender[sender] = (perSender[sender] or 0) + 1
    return perSender[sender] <= SENDER_LIMIT
end

function SY:OnMessage(prefix, msg, channel, sender)
    if prefix ~= SY.PREFIX then return end
    if isMe(sender) then
        -- Nuestro propio mensaje de prueba volvió por el canal: el servidor lo permite.
        if msg == "P" and channel == "CHANNEL" then SY.channelMode = "addon" end
        return
    end
    if not ns.settings.share or not allowed(sender) then return end
    if msg:sub(1, 2) == "V;" then return self:OnVersion(msg:sub(3), channel, sender) end
    local LR, DB = ns.Learn, ns.DB
    local store = LR:Received()
    local what, a, b, c, d, e, f = SY.Decode(msg)
    local new
    if what == "spawn" then
        if not DB.zones[c] then return end   -- mapa que no conocemos
        new = LR:AddSpawn(a, b, f, c, d, e, store)
    elseif what == "rel" then
        if not DB.quests[b] then return end  -- misión que no conocemos
        new = LR:AddRelation(a, b, c, d, store)
    elseif what == "obj" then
        if not DB.quests[b] then return end
        new = LR:AddObjective(a, b, c, store)
    end
    if new then
        SY.receivedCount = SY.receivedCount + 1
        ns:RequestRefresh()
    end
end

-- Mensajes del canal oculto cuando van por chat normal.
function SY:OnChannelChat(msg, sender, channelName)
    if not channelName or strlower(channelName) ~= strlower(SY.CHANNEL) then return end
    if type(msg) ~= "string" or msg:sub(1, #SY.CHAT_TAG) ~= SY.CHAT_TAG then return end
    self:OnMessage(SY.PREFIX, msg:sub(#SY.CHAT_TAG + 1), "CHANNEL", sender)
end

--- ¿Este mensaje de chat es del canal oculto? (para no mostrarlo en la ventana)
function SY.IsHiddenChannel(channelName, msg)
    if channelName and strlower(channelName) == strlower(SY.CHANNEL) then return true end
    return type(msg) == "string" and msg:sub(1, #SY.CHAT_TAG) == SY.CHAT_TAG
end

local function hideChannelFromChatFrames()
    if not ChatFrame_RemoveChannel then return end
    for i = 1, (NUM_CHAT_WINDOWS or 10) do
        local frame = _G["ChatFrame" .. i]
        if frame then ChatFrame_RemoveChannel(frame, SY.CHANNEL) end
    end
end

--- Entra al canal oculto y averigua si acepta mensajes de addon.
function SY:JoinChannel()
    if not ns.settings.share or not ns.settings.shareChannel or not JoinTemporaryChannel then return end
    if not SY.ChannelIndex() then JoinTemporaryChannel(SY.CHANNEL) end
    hideChannelFromChatFrames()
    C_Timer.After(2, function()
        local idx = SY.ChannelIndex()
        if not idx then return end
        hideChannelFromChatFrames()
        pcall(SendAddonMessage, SY.PREFIX, "P", "CHANNEL", idx)
        -- Si en 5 segundos no volvió nuestra prueba, se usa chat normal (oculto).
        C_Timer.After(5, function()
            if SY.channelMode ~= "addon" then SY.channelMode = "chat" end
            SY:Send("V;" .. ns.version, true)
        end)
    end)
end

function SY:OnInit()
    if RegisterAddonMessagePrefix then RegisterAddonMessagePrefix(SY.PREFIX) end
end

function SY:OnEnable()
    ns:On("SENDA_LEARNED", function(...) SY:Send(SY.Encode(...)) end)
    ns:RegisterEvent("CHAT_MSG_ADDON", function(_, ...) SY:OnMessage(...) end)
    ns:RegisterEvent("CHAT_MSG_CHANNEL", function(_, msg, sender, _, _, _, _, _, _, channelName)
        SY:OnChannelChat(msg, sender, channelName)
    end)
    if ChatFrame_AddMessageEventFilter then
        local function filter(_, _, msg, _, _, _, _, _, _, _, channelName)
            return SY.IsHiddenChannel(channelName, msg)
        end
        ChatFrame_AddMessageEventFilter("CHAT_MSG_CHANNEL", filter)
        ChatFrame_AddMessageEventFilter("CHAT_MSG_CHANNEL_NOTICE", function(_, _, _, _, _, _, _, _, _, _, channelName)
            return channelName and strlower(channelName) == strlower(SY.CHANNEL)
        end)
        ChatFrame_AddMessageEventFilter("CHAT_MSG_CHANNEL_NOTICE_USER", function(_, _, _, _, _, _, _, _, _, _, channelName)
            return channelName and strlower(channelName) == strlower(SY.CHANNEL)
        end)
    end
    -- Al entrar: avisar la versión a grupo/hermandad/amigos y, un poco después
    -- (cuando el juego ya creó General/Comercio), entrar al canal oculto.
    C_Timer.After(10, function() SY:Send("V;" .. ns.version, true) end)
    C_Timer.After(15, function() SY:JoinChannel() end)
    ns:RegisterEvent("GROUP_JOINED", function() SY:Send("V;" .. ns.version, true) end)
end
