-- Senda (c) 2026 Tzors. Todos los derechos reservados. Ver LICENSE.txt.
-- Datos de DEMOSTRACIÓN para comprobar que los pines se pintan bien en el
-- mapa de Azsuna antes de tener datos reales. IDs en el rango 9000000+ para
-- que nunca choquen con misiones reales. Se activan con "/senda demo".
-- Las coordenadas y nombres son inventados a propósito.

local _, ns = ...

local Demo = ns:NewModule("Demo")
ns.Demo = Demo

local AZSUNA = 1015

local data = {
    mapID = AZSUNA,
    name = "Azsuna",
    quests = {
        [9000001] = {
            name = "[Demo] Misión disponible", level = 0, minLevel = 1,
            start = { npcs = { 9000101 } }, finish = { npcs = { 9000101 } },
            objectives = {},
        },
        [9000002] = {
            name = "[Demo] Otra misión disponible", level = 0, minLevel = 1,
            start = { npcs = { 9000102 } }, finish = { npcs = { 9000101 } },
            objectives = {},
        },
        [9000003] = {
            name = "[Demo] Misión activa", level = 0, minLevel = 1,
            start = { npcs = { 9000101 } }, finish = { npcs = { 9000102 } },
            objectives = { { type = "monster", id = 9000103, count = 8 } },
        },
    },
    npcs = {
        [9000101] = { name = "Guía de demostración", spawns = { { 48.0, 30.0 } } },
        [9000102] = { name = "Explorador de demostración", spawns = { { 60.0, 55.0 } } },
        [9000103] = { name = "Bicho de demostración", spawns = {
            { 40.0, 60.0 }, { 41.5, 61.2 }, { 39.2, 62.8 }, { 42.7, 63.5 }, { 38.5, 59.1 },
        } },
    },
}

-- Misiones que el modo demo finge tener en el registro de misiones.
Demo.fakeActive = { [9000003] = { complete = false } }

function Demo:Enable()
    if self.loaded then return end
    ns.DB:RegisterZone(data)
    ns.DB:Build()
    self.loaded = true
end

function Demo:IsActive()
    return self.loaded and ns.settings.demo
end

function Demo:OnInit()
    if ns.settings.demo then self:Enable() end
end
