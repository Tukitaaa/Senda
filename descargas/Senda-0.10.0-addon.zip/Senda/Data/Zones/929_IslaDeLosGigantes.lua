-- ARCHIVO GENERADO por tools/export_tc.py. No editar a mano: se sobrescribe.
-- Zona: Isla de los Gigantes (mapID 929, continente 870, área 6661)
-- 5 misiones, 0 PNJ, 0 objetos.

local _, ns = ...

ns.DB:RegisterZone({
    mapID = 929,
    name = "Isla de los Gigantes",
    quests = {
        [32613] = { name = "Hueso de dinosaurio gigante", level = 90, minLevel = 89, start = { npcs = { 70022 } }, finish = { npcs = { 70022 } }, objectives = { { type = "item", id = 94288, count = 1 } }, poi = { finish = { 32.9, 54.2 } } },
        [32614] = { name = "Más huesos de dinosaurio gigantes", level = 90, minLevel = 89, start = { npcs = { 70022 } }, finish = { npcs = { 70022 } }, objectives = { { type = "item", id = 94288, count = 9 } }, poi = { finish = { 32.9, 54.2 } } },
        [32615] = { name = "Muchos más huesos de dinosaurio gigantes", level = 90, minLevel = 89, start = { npcs = { 70022 } }, finish = { npcs = { 70022 } }, objectives = { { type = "item", id = 94288, count = 99 } }, poi = { finish = { 32.9, 54.2 } } },
        [32616] = { name = "Un gran montón de huesos de dinosaurio gigantes", level = 90, minLevel = 89, start = { npcs = { 70022 } }, finish = { npcs = { 70022 } }, objectives = { { type = "item", id = 94288, count = 999 } }, poi = { finish = { 32.9, 54.2 } } },
        [32617] = { name = "Una montaña de huesos de dinosaurio gigantes", level = 90, minLevel = 89, start = { npcs = { 70022 } }, finish = { npcs = { 70022 } }, objectives = { { type = "item", id = 94288, count = 9999 } }, poi = { finish = { 32.9, 54.2 } } },
    },
    npcs = {
    },
    objects = {
    },
    items = {
        [94288] = { npcs = {}, objects = {} },
    },
})
