-- ARCHIVO GENERADO por tools/export_tc.py. No editar a mano: se sobrescribe.
-- Zona: El Exodar (mapID 471, continente 1, área 0)
-- 28 misiones, 0 PNJ, 0 objetos.

local _, ns = ...

ns.DB:RegisterZone({
    mapID = 471,
    name = "El Exodar",
    quests = {
        [9595] = { name = "Control", level = 11, minLevel = 10, classes = 128, start = {}, finish = { npcs = { 17514 } }, excl = 1860, objectives = { { type = "monster", id = 17612, count = 1 } }, poi = { finish = { 46.3, 63.5 } } },
        [9600] = { name = "Redemption", level = -1, minLevel = 12, races = 1024, classes = 2, start = {}, finish = { npcs = { 17509 } }, prev = { 9598, 9599 }, objectives = { { type = "monster", id = 17542, count = 1 } }, poi = { finish = { 38.4, 82.6 } } },
        [9604] = { name = "En alas de un hipogrifo", level = 7, minLevel = 5, races = 18875469, start = { npcs = { 17554, 43991 } }, finish = { npcs = { 16768 } }, prev = { 9603 }, objectives = { { type = "item", id = 23902, count = 1 } }, poi = { finish = { 57.0, 50.1 } } },
        [9605] = { name = "El maestro de hipogrifos Stephanos", level = 7, minLevel = 5, races = 18875469, start = { npcs = { 16768 } }, finish = { npcs = { 17555 } }, prev = { 9604 }, objectives = { { type = "item", id = 23903, count = 1 } }, poi = { finish = { 54.5, 36.2 } } },
        [10350] = { name = "Maestro Behomat", level = 10, minLevel = 10, races = 18875469, classes = 1, start = { npcs = { 17480 } }, finish = { npcs = { 17120 } }, prev = { 9582 }, objectives = {}, poi = { finish = { 55.6, 82.2 } } },
        [10956] = { name = "El Trono de los Naaru", level = -1, minLevel = 60, races = 18875469, start = {}, finish = { npcs = { 17538 } }, objectives = {}, poi = { finish = { 58.0, 41.5 }, obj = { { 31, 58.1, 41.2, 1.5 }, { 30, 58.2, 41.2, 1.5 } } } },
        [10968] = { name = "Llamada al clarividente", level = -1, minLevel = 60, races = 18875469, start = {}, finish = { npcs = { 17204 } }, prev = { 10956 }, objectives = {}, poi = { finish = { 29.9, 33.1 }, obj = { { 31, 30.0, 33.3, 1.5 }, { 30, 30.1, 33.3, 1.5 } } } },
        [24611] = { name = "Un regalo para el Profeta", level = -1, minLevel = 0, races = 18875469, start = { npcs = { 38040 } }, finish = { npcs = { 17468 } }, objectives = { { type = "item", id = 49916, count = 1 } }, poi = { finish = { 32.9, 54.5 } } },
        [25563] = { name = "Hammering It Out", level = 15, minLevel = 1, start = {}, finish = { npcs = { 41210 } }, objectives = {}, poi = { finish = { 53.6, 43.9 } } },
        [25567] = { name = "Rómpete el coco", level = 25, minLevel = 1, start = {}, finish = { npcs = { 41210 } }, objectives = {}, poi = { finish = { 53.6, 43.9 } } },
        [25568] = { name = "Rómpete el coco", level = 35, minLevel = 1, start = {}, finish = { npcs = { 41210 } }, objectives = {}, poi = { finish = { 53.6, 43.9 } } },
        [25569] = { name = "Rómpete el coco", level = 45, minLevel = 1, start = {}, finish = { npcs = { 41210 } }, objectives = {}, poi = { finish = { 53.6, 43.9 } } },
        [25570] = { name = "Rómpete el coco", level = 55, minLevel = 1, start = {}, finish = { npcs = { 41210 } }, objectives = {}, poi = { finish = { 53.6, 43.9 } } },
        [25572] = { name = "Rómpete el coco", level = 75, minLevel = 1, start = {}, finish = { npcs = { 41210 } }, objectives = {}, poi = { finish = { 53.6, 43.9 } } },
        [25603] = { name = "Rómpete el coco", level = -1, minLevel = 1, start = {}, finish = { npcs = { 41210 } }, objectives = {}, poi = { finish = { 53.6, 43.9 } } },
        [25604] = { name = "Rómpete el coco", level = -1, minLevel = 1, races = 52430847, start = {}, finish = { npcs = { 41210 } }, objectives = { { type = "item", id = 54883, count = 1 } }, poi = { finish = { 53.6, 43.9 } } },
        [25605] = { name = "Rómpete el coco", level = 30, minLevel = 1, start = {}, finish = { npcs = { 41210 } }, objectives = {}, poi = { finish = { 53.6, 43.9 } } },
        [25606] = { name = "Rómpete el coco", level = 40, minLevel = 1, start = {}, finish = { npcs = { 41210 } }, objectives = {}, poi = { finish = { 53.6, 43.9 } } },
        [25773] = { name = "Un incidente elemental", level = -1, minLevel = 1, races = 52430847, start = {}, finish = { npcs = { 41263 } }, objectives = { { type = "item", id = 56008, count = 1 } }, poi = { finish = { 53.6, 43.9 } } },
        [29067] = { name = "Maestro de pociones", level = -1, minLevel = 1, start = { npcs = { 3347, 5499 } }, finish = { npcs = { 3009, 3347, 4160, 4611, 5177, 5499, 16642, 16723 } }, objectives = { { type = "item", id = 76097, count = 20 }, { type = "item", id = 76098, count = 20 }, { type = "item", id = 93351, count = 2 } }, poi = { finish = { 27.9, 60.6 } } },
        [29092] = { name = "Informa al anciano", level = -1, minLevel = 16, races = 18875469, start = {}, finish = { npcs = { 26221 } }, objectives = {}, poi = { finish = { 43.3, 26.3 } } },
        [29382] = { name = "Gracias, pero no", level = -1, minLevel = 0, races = 52430847, start = {}, finish = { npcs = { 13433, 13435, 23010 } }, objectives = { { type = "item", id = 70923, count = 1 }, { type = "item", id = 70928, count = 1 } }, poi = { finish = { 54.8, 48.6 } } },
        [29477] = { name = "Ingeniería gnómica", level = -1, minLevel = 20, start = { npcs = { 5518, 11017, 52651 } }, finish = { npcs = { 5518, 7944, 11017, 11031, 16667, 16726, 52636, 52651 } }, objectives = { { type = "item", id = 10559, count = 6 }, { type = "item", id = 4407, count = 1 }, { type = "item", id = 4392, count = 2 } }, poi = { finish = { 54.2, 92.9 } } },
        [29481] = { name = "Maestro en elixires", level = -1, minLevel = 1, start = { npcs = { 3347, 5499 } }, finish = { npcs = { 3009, 3347, 4160, 4611, 5177, 5499, 16642, 16723 } }, objectives = { { type = "item", id = 76088, count = 2 }, { type = "item", id = 76087, count = 2 }, { type = "item", id = 76085, count = 2 }, { type = "item", id = 76084, count = 2 } }, poi = { finish = { 27.9, 60.6 } } },
        [29482] = { name = "Maestro de transmutación", level = -1, minLevel = 1, start = { npcs = { 3347, 5499 } }, finish = { npcs = { 3009, 3347, 4160, 4611, 5177, 5499, 16642, 16723 } }, objectives = { { type = "item", id = 72104, count = 4 } }, poi = { finish = { 27.9, 60.6 } } },
        [32661] = { name = "A montar se ha dicho", level = -1, minLevel = 1, races = 18875469, start = {}, finish = { npcs = { 20914 } }, objectives = {}, poi = { finish = { 81.3, 52.7 } } },
        [44991] = { name = "El olor a draenei", level = 110, minLevel = 110, races = 18875469, start = {}, finish = {}, objectives = { { type = "monster", id = 116104, count = 1 } }, poi = { obj = { { 0, 59.5, 18.8, 1.5 } } } },
        [46178] = { name = "Esconderse a simple vista", level = 110, minLevel = 110, races = 33555378, start = {}, finish = {}, objectives = { { type = "monster", id = 98099, count = 1 }, { type = "monster", id = 118892, count = 1 }, { type = "monster", id = 118891, count = 1 }, { type = "monster", id = 118889, count = 1 }, { type = "monster", id = 15659, count = 1 } }, poi = { obj = { { 1, 40.8, 60.0, 51.4 } } } },
    },
    npcs = {
    },
    objects = {
    },
    items = {
        [4392] = { npcs = {}, objects = {} },
        [4407] = { npcs = {}, objects = {} },
        [10559] = { npcs = {}, objects = {} },
        [23902] = { npcs = {}, objects = {} },
        [23903] = { npcs = {}, objects = {} },
        [49916] = { npcs = {}, objects = {} },
        [54883] = { npcs = {}, objects = {} },
        [56008] = { npcs = {}, objects = {} },
        [70923] = { npcs = {}, objects = {} },
        [70928] = { npcs = {}, objects = {} },
        [72104] = { npcs = {}, objects = {} },
        [76084] = { npcs = {}, objects = {} },
        [76085] = { npcs = {}, objects = {} },
        [76087] = { npcs = {}, objects = {} },
        [76088] = { npcs = {}, objects = {} },
        [76097] = { npcs = {}, objects = {} },
        [76098] = { npcs = {}, objects = {} },
        [93351] = { npcs = {}, objects = {} },
    },
})
