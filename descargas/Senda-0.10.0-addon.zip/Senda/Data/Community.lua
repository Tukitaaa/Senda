-- Datos aportados por la comunidad. Generado por tools/merge_learned.py a
-- partir de los archivos Senda.lua que envían los jugadores. No editar a mano.
local _, ns = ...
ns.community = nil
