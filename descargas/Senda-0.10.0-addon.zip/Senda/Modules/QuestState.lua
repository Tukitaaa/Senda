-- Senda (c) 2026 Tzors. Todos los derechos reservados. Ver LICENSE.txt.
-- Estado de misiones del personaje: completadas y en el registro.
-- Fuente de verdad = el cliente (API 7.x). La base de datos solo aporta
-- dónde están las cosas.

local _, ns = ...

local QS = ns:NewModule("QuestState")
ns.QuestState = QS

QS.completed = {}  -- [questID] = true
QS.active = {}     -- [questID] = { logIndex, title, complete, objectives = { {text, type, finished, have, need}, ... } }

function QS:IsCompleted(questID)
    if self.completed[questID] then return true end
    -- Respaldo por si el evento se perdió.
    if IsQuestFlaggedCompleted and IsQuestFlaggedCompleted(questID) then
        self.completed[questID] = true
        return true
    end
    return false
end

function QS:IsActive(questID)
    return self.active[questID] ~= nil
end

function QS:GetActive(questID)
    return self.active[questID]
end

function QS:LoadCompleted()
    wipe(self.completed)
    -- En 7.x GetQuestsCompleted() devuelve { [questID] = true } de forma síncrona.
    local done = GetQuestsCompleted and GetQuestsCompleted() or {}
    for id in pairs(done) do self.completed[id] = true end
end

local function readObjectives(questID, logIndex)
    local list = {}
    local n = GetNumQuestLeaderBoards(logIndex) or 0
    for i = 1, n do
        local text, objType, finished, have, need = GetQuestObjectiveInfo(questID, i, false)
        list[i] = { text = text, type = objType, finished = finished, have = have or 0, need = need or 0 }
    end
    return list
end

function QS:ScanLog()
    wipe(self.active)
    local numEntries = GetNumQuestLogEntries()
    for i = 1, numEntries do
        local title, _, _, isHeader, _, isComplete, _, questID, _, _, _, _, isTask, isBounty, _, isHidden =
            GetQuestLogTitle(i)
        -- isTask = misiones de zona / de mundo; no las gestionamos (aún).
        if not isHeader and questID and questID > 0 and not isTask and not isBounty and not isHidden then
            self.active[questID] = {
                logIndex = i,
                title = title,
                complete = (isComplete == 1 or isComplete == true),
                objectives = readObjectives(questID, i),
            }
        end
    end

    -- Modo demo: inyecta misiones activas falsas.
    if ns.Demo and ns.Demo:IsActive() then
        for id, info in pairs(ns.Demo.fakeActive) do
            if not self.active[id] then
                self.active[id] = { logIndex = 0, title = ns.DB.quests[id] and ns.DB.quests[id].name,
                                    complete = info.complete, objectives = {} }
            end
        end
    end
end

function QS:OnEnable()
    self:LoadCompleted()
    self:ScanLog()

    local function onLogChange()
        QS:ScanLog()
        ns:Fire("SENDA_LOG_SCANNED")
        ns:RequestRefresh()
    end
    ns:RegisterEvent("QUEST_LOG_UPDATE", onLogChange)
    ns:RegisterEvent("QUEST_ACCEPTED", onLogChange)
    ns:RegisterEvent("QUEST_REMOVED", onLogChange)

    ns:RegisterEvent("QUEST_TURNED_IN", function(_, questID)
        if questID then QS.completed[questID] = true end
        onLogChange()
    end)

    ns:RegisterEvent("PLAYER_LEVEL_UP", function() ns:RequestRefresh() end)
end
