-- Senda (c) 2026 Tzors. Todos los derechos reservados. Ver LICENSE.txt.
-- /senda volcar: guarda en SendaDB.mapDump los límites (coordenadas del mundo)
-- de cada mapa de zona que conoce el cliente. El exportador los usa para
-- convertir las posiciones de TrinityCore a coordenadas 0-100 del mapa, sin
-- tener que extraer WorldMapArea.db2 del cliente.
--
-- Formato de cada línea: "mapID;nombre;continente;left;top;right;bottom"

local _, ns = ...

local MD = ns:NewModule("MapDump")

local MAX_ID = 1500

function MD:Run()
    if WorldMapFrame:IsShown() then
        ns:Print("cierra el mapa antes de usar /senda volcar")
        return
    end
    local out = {}
    for id = 1, MAX_ID do
        local ok = pcall(SetMapByID, id)
        if ok and GetCurrentMapAreaID() == id then
            local _, left, top, right, bottom = GetCurrentMapZone()
            if left and right and (left ~= 0 or right ~= 0) and left ~= right then
                local name = GetMapNameByID(id) or ""
                local continent = GetCurrentMapContinent() or 0
                out[#out + 1] = string.format("%d;%s;%d;%.4f;%.4f;%.4f;%.4f",
                    id, name:gsub(";", ","), continent, left, top, right, bottom)
            end
        end
    end
    SetMapToCurrentZone()
    ns.settings.mapDump = out
    ns:Print(#out .. " mapas guardados. Escribe /reload para que se graben en el disco.")
end
