-- Senda (c) 2026 Tzors. Todos los derechos reservados. Ver LICENSE.txt.
-- Compartir en vivo: lo que aprende un jugador se manda a su grupo y a su
-- hermandad (mensajes de addon, invisibles en el chat). Los demás jugadores
-- con Senda lo reciben y lo usan en su mapa al momento.
--
-- Lo recibido se guarda aparte (SendaDB.received): no se mezcla con lo que
-- aprendiste tú, así el archivo que envías para la base de datos común
-- contiene solo lo que viste con tus propios ojos.
--
-- Formato de los mensajes (prefijo "SENDA1"):
--   S;n|o;id;mapa;x;y;nombre    aparición de un PNJ (n) u objeto (o)
--   R;s|f;misión;n|o;id         la misión empieza (s) o termina (f) en él
--   O;m|o;misión;id             matar este PNJ (m) / usar este objeto (o) sirve para la misión

local _, ns = ...

local SY = ns:NewModule("Sync")
ns.Sync = SY

SY.PREFIX = "SENDA1"
local SEND_INTERVAL = 0.3   -- segundos entre mensajes (para no saturar)
local MAX_QUEUE = 300
local MAX_ID = 2147483647

local queue = {}
local sending = false

---------------------------------------------------------------------------
-- Codificar / decodificar (funciones puras, se prueban fuera del juego)
---------------------------------------------------------------------------

local KIND = { npc = "n", object = "o" }
local KIND_R = { n = "npc", o = "object" }
local SIDE = { start = "s", finish = "f" }
local SIDE_R = { s = "start", f = "finish" }
local OBJ = { monster = "m", object = "o" }
local OBJ_R = { m = "monster", o = "object" }

function SY.Encode(what, ...)
    if what == "spawn" then
        local kind, id, mapID, x, y, name = ...
        local msg = string.format("S;%s;%d;%d;%.1f;%.1f;%s", KIND[kind], id, mapID, x, y, name or "")
        return msg:sub(1, 250)
    elseif what == "rel" then
        local side, questID, kind, id = ...
        return string.format("R;%s;%d;%s;%d", SIDE[side], questID, KIND[kind], id)
    elseif what == "obj" then
        local objType, questID, id = ...
        return string.format("O;%s;%d;%d", OBJ[objType], questID, id)
    end
end

local function validID(n) return n and n > 0 and n <= MAX_ID and n == math.floor(n) end

--- Devuelve (tipo, ...) o nil si el mensaje no es válido.
function SY.Decode(msg)
    if type(msg) ~= "string" then return nil end
    local t = msg:sub(1, 1)
    if t == "S" then
        local k, id, mapID, x, y, name = strsplit(";", msg:sub(3), 6)
        id, mapID, x, y = tonumber(id), tonumber(mapID), tonumber(x), tonumber(y)
        if not (KIND_R[k] and validID(id) and validID(mapID) and x and y) then return nil end
        if x < 0 or x > 100 or y < 0 or y > 100 then return nil end
        if name == "" then name = nil end
        if name and #name > 80 then name = name:sub(1, 80) end
        return "spawn", KIND_R[k], id, mapID, x, y, name
    elseif t == "R" then
        local s, questID, k, id = strsplit(";", msg:sub(3))
        questID, id = tonumber(questID), tonumber(id)
        if not (SIDE_R[s] and KIND_R[k] and validID(questID) and validID(id)) then return nil end
        return "rel", SIDE_R[s], questID, KIND_R[k], id
    elseif t == "O" then
        local o, questID, id = strsplit(";", msg:sub(3))
        questID, id = tonumber(questID), tonumber(id)
        if not (OBJ_R[o] and validID(questID) and validID(id)) then return nil end
        return "obj", OBJ_R[o], questID, id
    end
    return nil
end

---------------------------------------------------------------------------
-- Envío
---------------------------------------------------------------------------

--- Canales a los que mandar ahora mismo.
function SY.Channels()
    local list = {}
    if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then
        list[#list + 1] = "INSTANCE_CHAT"
    elseif IsInRaid() then
        list[#list + 1] = "RAID"
    elseif IsInGroup() then
        list[#list + 1] = "PARTY"
    end
    if IsInGuild() then list[#list + 1] = "GUILD" end
    return list
end

local function pump()
    local msg = table.remove(queue, 1)
    if not msg then
        sending = false
        return
    end
    for _, channel in ipairs(SY.Channels()) do
        SendAddonMessage(SY.PREFIX, msg, channel)
    end
    C_Timer.After(SEND_INTERVAL, pump)
end

function SY:Send(msg)
    if not msg or not ns.settings.share then return end
    if #SY.Channels() == 0 then return end
    if #queue >= MAX_QUEUE then table.remove(queue, 1) end
    queue[#queue + 1] = msg
    if not sending then
        sending = true
        C_Timer.After(SEND_INTERVAL, pump)
    end
end

---------------------------------------------------------------------------
-- Recepción
---------------------------------------------------------------------------

SY.receivedCount = 0

local function isMe(sender)
    if not sender then return true end
    local short = Ambiguate and Ambiguate(sender, "none") or sender
    return short == UnitName("player") or sender == UnitName("player")
end

function SY:OnMessage(prefix, msg, channel, sender)
    if prefix ~= SY.PREFIX or not ns.settings.share or isMe(sender) then return end
    local LR, DB = ns.Learn, ns.DB
    local store = LR:Received()
    local what, a, b, c, d, e, f = SY.Decode(msg)
    local new
    if what == "spawn" then
        if not DB.zones[c] then return end   -- mapa que no conocemos
        new = LR:AddSpawn(a, b, f, c, d, e, store)
    elseif what == "rel" then
        if not DB.quests[b] then return end  -- misión que no conocemos
        new = LR:AddRelation(a, b, c, d, store)
    elseif what == "obj" then
        if not DB.quests[b] then return end
        new = LR:AddObjective(a, b, c, store)
    end
    if new then
        SY.receivedCount = SY.receivedCount + 1
        ns:RequestRefresh()
    end
end

function SY:OnInit()
    if RegisterAddonMessagePrefix then RegisterAddonMessagePrefix(SY.PREFIX) end
end

function SY:OnEnable()
    ns:On("SENDA_LEARNED", function(...) SY:Send(SY.Encode(...)) end)
    ns:RegisterEvent("CHAT_MSG_ADDON", function(_, ...) SY:OnMessage(...) end)
end
