-- Senda (c) 2026 Tzors. Todos los derechos reservados. Ver LICENSE.txt.
-- Líneas extra en el tooltip de los PNJ: qué misión activa los necesita
-- (matar / soltar objeto), si dan misiones disponibles o si son entrega.

local _, ns = ...
local L = ns.L

local TT = ns:NewModule("Tooltips")
ns.Tooltips = TT

--- Extrae el ID de PNJ de un GUID de 7.x:
--- "Creature-0-[servidor]-[instancia]-[zona]-[npcID]-[spawn]"
function TT.NpcIDFromGUID(guid)
    if not guid then return nil end
    local unitType, _, _, _, _, npcID = strsplit("-", guid)
    if unitType == "Creature" or unitType == "Vehicle" then
        return tonumber(npcID)
    end
    return nil
end

-- ¿El objetivo i de la misión tiene que ver con este PNJ?
local function objectiveMatchesNpc(obj, npcID)
    if obj.type == "monster" then
        if obj.id == npcID then return true end
        for _, id in ipairs(obj.also or {}) do
            if id == npcID then return true end
        end
        return false
    end
    if obj.type == "item" then
        local item = ns.DB:GetItem(obj.id)
        if item and item.npcs then
            for _, id in ipairs(item.npcs) do
                if id == npcID then return true end
            end
        end
    end
    return false
end

--- Devuelve las líneas a añadir para un PNJ: { {left, r,g,b}, ... }
function TT:LinesForNpc(npcID)
    local lines = {}
    local DB, QS, AV = ns.DB, ns.QuestState, ns.Availability

    for questID, state in pairs(QS.active) do
        local q = DB:GetQuest(questID)
        if q and not state.complete then
            for i, obj in ipairs(q.objectives or {}) do
                if objectiveMatchesNpc(obj, npcID) then
                    local live = state.objectives and state.objectives[i]
                    if not (live and live.finished) then
                        lines[#lines + 1] = { q.name, 1, 0.82, 0 }
                        if live and live.text then
                            lines[#lines + 1] = { "  - " .. live.text, 0.85, 0.85, 0.85 }
                        end
                    end
                end
            end
        end
    end

    for _, questID in ipairs(DB.startsAt.npc[npcID] or {}) do
        if AV:IsAvailable(questID) then
            local q = DB:GetQuest(questID)
            lines[#lines + 1] = { "! " .. q.name, 1, 0.82, 0 }
        end
    end

    for _, questID in ipairs(DB.endsAt.npc[npcID] or {}) do
        local state = QS:GetActive(questID)
        if state then
            local q = DB:GetQuest(questID)
            local label = state.complete and L.TURN_IN or L.TURN_IN_NOT_READY
            lines[#lines + 1] = { "? " .. q.name .. " (" .. label .. ")", 0.6, 0.85, 1 }
        end
    end
    return lines
end

function TT:OnEnable()
    GameTooltip:HookScript("OnTooltipSetUnit", function(tooltip)
        if not ns.settings.tooltips then return end
        local _, unit = tooltip:GetUnit()
        if not unit then return end
        local npcID = TT.NpcIDFromGUID(UnitGUID(unit))
        if not npcID then return end
        local lines = TT:LinesForNpc(npcID)
        for _, l in ipairs(lines) do
            tooltip:AddLine(l[1], l[2], l[3], l[4])
        end
        if #lines > 0 then tooltip:Show() end
    end)
end
