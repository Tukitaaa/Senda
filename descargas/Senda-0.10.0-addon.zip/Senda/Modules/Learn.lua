-- Senda (c) 2026 Tzors. Todos los derechos reservados. Ver LICENSE.txt.
-- Aprendizaje: Senda apunta, mientras juegas, dónde están las cosas.
--
-- La base de datos de TrinityCore 7.3.5 trae las misiones de Legion (nombres,
-- niveles, requisitos, objetivos) pero NO las posiciones de los PNJ de las
-- Islas Abruptas. Este módulo las aprende del propio juego (de Tauri):
--
--   * Al hablar con un PNJ (diálogo, lista de misiones): quién da y quién
--     recibe cada misión, y su posición (tu posición en ese momento: estás
--     a menos de 5 metros).
--   * Al matar algo que hace avanzar un objetivo: dónde está ese bicho.
--   * Al despojar un objeto (cofre, planta...) que da un objeto de misión.
--
-- Todo se guarda en SendaDB.learned (compartido por tus personajes) y se
-- fusiona con la base de datos al iniciar.

local _, ns = ...

local LR = ns:NewModule("Learn")
ns.Learn = LR

local MIN_DIST = 1.0        -- en unidades de mapa (0-100): no repetir puntos tan cercanos
local MAX_SPAWNS = 50       -- por entidad y mapa
local KILL_WINDOW = 1.5     -- segundos entre la muerte y el avance del objetivo

local function emptyLearned()
    return { npcs = {}, objects = {}, starts = {}, ends = {}, objNpcs = {}, objObjects = {} }
end

---------------------------------------------------------------------------
-- Utilidades
---------------------------------------------------------------------------

--- "Creature-0-..-npcID-.." / "GameObject-0-..-goID-.." -> "npc"|"object", id
function LR.ParseGUID(guid)
    if not guid then return nil end
    local unitType, _, _, _, _, id = strsplit("-", guid)
    id = tonumber(id)
    if not id then return nil end
    if unitType == "Creature" or unitType == "Vehicle" then return "npc", id end
    if unitType == "GameObject" then return "object", id end
    return nil
end

--- Posición del jugador en coordenadas 0-100 del mapa de su zona.
function LR.PlayerPosition()
    if WorldMapFrame and WorldMapFrame:IsShown() then return nil end -- no tocar el mapa abierto
    SetMapToCurrentZone()
    local x, y = GetPlayerMapPosition("player")
    if not x or (x == 0 and y == 0) then return nil end -- instancias / sin mapa
    return GetCurrentMapAreaID(), math.floor(x * 1000 + 0.5) / 10, math.floor(y * 1000 + 0.5) / 10
end

function LR:Store()
    return ns.settings.learned
end

--- Lo recibido de otros jugadores (se usa en el mapa pero no se exporta,
--- para que cada archivo compartido contenga solo lo que vio su dueño).
function LR:Received()
    return ns.settings.received
end

--- Avisa a otros módulos (Sync) de algo nuevo aprendido por nosotros.
local function announce(store, ...)
    if store == LR:Store() then ns:Fire("SENDA_LEARNED", ...) end
end

--- Añade una aparición; devuelve true si era nueva.
function LR:AddSpawn(kind, id, name, mapID, x, y, store)
    store = store or self:Store()
    local bucket = store[kind == "npc" and "npcs" or "objects"]
    local e = bucket[id]
    if not e then
        e = { name = name, spawns = {} }
        bucket[id] = e
    end
    if name and name ~= "" then e.name = name end
    local list = e.spawns[mapID]
    if not list then
        list = {}
        e.spawns[mapID] = list
    end
    for i = 1, #list do
        local dx, dy = list[i][1] - x, list[i][2] - y
        if dx * dx + dy * dy < MIN_DIST * MIN_DIST then return false end
    end
    if #list >= MAX_SPAWNS then return false end
    list[#list + 1] = { x, y }
    -- Reflejarlo ya en la base de datos en memoria
    ns.DB:AddLearnedSpawn(kind, id, e.name, mapID, x, y)
    announce(store, "spawn", kind, id, mapID, x, y, e.name)
    return true
end

local function addRelation(map, questID, kind, id)
    local r = map[questID]
    if not r then
        r = { npcs = {}, objects = {} }
        map[questID] = r
    end
    local list = kind == "npc" and r.npcs or r.objects
    for i = 1, #list do
        if list[i] == id then return false end
    end
    list[#list + 1] = id
    return true
end

--- Apunta "questID empieza/termina en esta entidad" (sin posición).
function LR:AddRelation(side, questID, kind, id, store)
    store = store or self:Store()
    if not questID or questID == 0 then return false end
    if not addRelation(side == "start" and store.starts or store.ends, questID, kind, id) then return false end
    ns.DB:AddLearnedRelation(side, questID, kind, id)
    announce(store, "rel", side, questID, kind, id)
    ns:Debug("aprendido", side, questID, kind, id)
    ns:RequestRefresh()
    return true
end

--- Apunta "matar a este PNJ / usar este objeto sirve para la misión".
function LR:AddObjective(objType, questID, id, store)
    store = store or self:Store()
    local m = objType == "monster" and store.objNpcs or store.objObjects
    m[questID] = m[questID] or {}
    if m[questID][id] then return false end
    m[questID][id] = true
    ns.DB:AddLearnedObjective(questID, objType, id)
    announce(store, "obj", objType, questID, id)
    ns:RequestRefresh()
    return true
end

--- Apunta "questID empieza/termina en esta entidad" y su posición.
function LR:LearnRelation(side, questID, kind, id, name)
    if not questID or questID == 0 then return end
    local mapID, x, y = LR.PlayerPosition()
    if mapID then self:AddSpawn(kind, id, name, mapID, x, y) end
    self:AddRelation(side, questID, kind, id)
end

--- PNJ con el que estamos hablando.
local function currentNpc()
    local kind, id = LR.ParseGUID(UnitGUID("npc"))
    return kind, id, UnitName("npc")
end

---------------------------------------------------------------------------
-- Diálogos con PNJ
---------------------------------------------------------------------------

-- Lista de misiones en el diálogo (GOSSIP_SHOW / QUEST_GREETING). En 7.x estas
-- listas dan el título pero no el ID, así que buscamos el título en la base
-- de datos (por eso el exportador genera los nombres en el idioma del cliente).
local function learnTitles(side, titles)
    local kind, id, name = currentNpc()
    if not kind then return end
    for _, title in ipairs(titles) do
        for _, questID in ipairs(ns.DB:FindQuestsByName(title)) do
            LR:LearnRelation(side, questID, kind, id, name)
        end
    end
end

local function gossipTitles(...)
    -- GetGossipAvailableQuests/ActiveQuests devuelven grupos de valores por misión;
    -- el tamaño del grupo cambia entre parches, así que nos quedamos con las
    -- cadenas que coinciden con algún nombre conocido.
    local titles = {}
    for i = 1, select("#", ...) do
        local v = select(i, ...)
        if type(v) == "string" and #ns.DB:FindQuestsByName(v) > 0 then titles[#titles + 1] = v end
    end
    return titles
end

function LR:OnGossipShow()
    learnTitles("start", gossipTitles(GetGossipAvailableQuests()))
    learnTitles("finish", gossipTitles(GetGossipActiveQuests()))
end

function LR:OnQuestGreeting()
    local av, ac = {}, {}
    for i = 1, GetNumAvailableQuests() do av[#av + 1] = GetAvailableTitle(i) end
    for i = 1, GetNumActiveQuests() do ac[#ac + 1] = GetActiveTitle(i) end
    learnTitles("start", av)
    -- Activas: solo sabemos que se entregan aquí si son nuestras
    learnTitles("finish", ac)
end

-- Ventana de detalle de una misión (aquí sí tenemos el ID).
function LR:OnQuestDetail()
    local kind, id, name = currentNpc()
    if kind then self:LearnRelation("start", GetQuestID(), kind, id, name) end
end

-- Ventana de entrega (progreso o recompensa).
function LR:OnQuestTurnInWindow()
    local kind, id, name = currentNpc()
    if kind then self:LearnRelation("finish", GetQuestID(), kind, id, name) end
end

---------------------------------------------------------------------------
-- Muertes que avanzan objetivos
---------------------------------------------------------------------------

local pendingKill -- { kind, id, name, time, mapID, x, y }

local function objectiveSnapshot()
    local snap = {}
    for questID, state in pairs(ns.QuestState.active) do
        local total = 0
        for _, o in ipairs(state.objectives or {}) do total = total + (o.have or 0) end
        snap[questID] = total
    end
    return snap
end

local lastSnapshot = {}

function LR:OnCombatLog(...)
    local _, subevent, _, srcGUID, _, _, _, dstGUID, dstName = ...
    if subevent ~= "PARTY_KILL" or srcGUID ~= UnitGUID("player") then return end
    local kind, id = LR.ParseGUID(dstGUID)
    if kind ~= "npc" then return end
    local mapID, x, y = LR.PlayerPosition()
    if not mapID then return end
    pendingKill = { kind = kind, id = id, name = dstName, time = GetTime(), mapID = mapID, x = x, y = y }
end

-- Tras cada cambio del registro: ¿algún objetivo subió justo después de una muerte?
function LR:OnQuestLogScanned()
    local snap = objectiveSnapshot()
    if pendingKill and GetTime() - pendingKill.time <= KILL_WINDOW then
        for questID, total in pairs(snap) do
            if lastSnapshot[questID] and total > lastSnapshot[questID] then
                local k = pendingKill
                self:AddSpawn("npc", k.id, k.name, k.mapID, k.x, k.y)
                self:AddObjective("monster", questID, k.id)
                pendingKill = nil
                ns:RequestRefresh()
                break
            end
        end
    end
    lastSnapshot = snap
end

---------------------------------------------------------------------------
-- Objetos despojados con objetos de misión (plantas, cofres, cajas...)
---------------------------------------------------------------------------

function LR:OnLootOpened()
    for slot = 1, GetNumLootItems() do
        local _, _, _, _, _, _, isQuestItem, questID = GetLootSlotInfo(slot)
        if isQuestItem then
            local guid = GetLootSourceInfo(slot)
            local kind, id = LR.ParseGUID(guid)
            if kind == "object" then
                local mapID, x, y = LR.PlayerPosition()
                if mapID then self:AddSpawn("object", id, nil, mapID, x, y) end
                if questID and questID > 0 then self:AddObjective("object", questID, id) end
            end
        end
    end
end

---------------------------------------------------------------------------

local function ensure(key)
    if type(ns.settings[key]) ~= "table" then ns.settings[key] = emptyLearned() end
    local l = ns.settings[key]
    for k, v in pairs(emptyLearned()) do
        if type(l[k]) ~= "table" then l[k] = v end
    end
    return l
end

--- Rellena las tablas que falten en datos que vienen de fuera.
function LR.Normalize(l)
    for k in pairs(emptyLearned()) do
        if type(l[k]) ~= "table" then l[k] = {} end
    end
    return l
end

function LR:OnInit()
    -- Orden: datos de la comunidad (vienen con el addon), lo recibido de otros
    -- jugadores y lo aprendido por ti.
    if type(ns.community) == "table" then ns.DB:RegisterLearned(LR.Normalize(ns.community), true) end
    ns.DB:RegisterLearned(ensure("received"), true)
    ns.DB:RegisterLearned(ensure("learned"))
end

function LR:OnEnable()
    ns:RegisterEvent("GOSSIP_SHOW", function() LR:OnGossipShow() end)
    ns:RegisterEvent("QUEST_GREETING", function() LR:OnQuestGreeting() end)
    ns:RegisterEvent("QUEST_DETAIL", function() LR:OnQuestDetail() end)
    ns:RegisterEvent("QUEST_PROGRESS", function() LR:OnQuestTurnInWindow() end)
    ns:RegisterEvent("QUEST_COMPLETE", function() LR:OnQuestTurnInWindow() end)
    ns:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED", function(_, ...) LR:OnCombatLog(...) end)
    ns:RegisterEvent("LOOT_OPENED", function() LR:OnLootOpened() end)
    ns:On("SENDA_LOG_SCANNED", function() LR:OnQuestLogScanned() end)
    lastSnapshot = objectiveSnapshot()
end

--- Cuánto se ha aprendido (para /senda info).
function LR:Counts()
    local function count(t) local n = 0 for _ in pairs(t) do n = n + 1 end return n end
    local l = self:Store()
    return count(l.npcs), count(l.objects), count(l.starts), count(l.ends)
end
