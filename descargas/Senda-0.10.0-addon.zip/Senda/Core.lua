-- Senda (c) 2026 Tzors. Todos los derechos reservados. Ver LICENSE.txt.
-- Senda: núcleo.
-- Espacio de nombres compartido, despachador de eventos, mensajes internos
-- y configuración guardada. Todos los módulos cuelgan de `ns`.

local ADDON, ns = ...

ns.name = ADDON
ns.version = "0.10.0"

---------------------------------------------------------------------------
-- Configuración por defecto
---------------------------------------------------------------------------
ns.defaults = {
    global = {
        enabled = true,
        showAvailable = true,   -- "!" de misiones disponibles
        showTurnIn = true,      -- "?" de entregas
        showObjectives = true,  -- puntos de objetivos de misiones activas
        showLowLevel = false,   -- misiones grises (muy por debajo de tu nivel)
        lowLevelDiff = 8,       -- a partir de cuántos niveles por debajo es "gris"
        maxSpawnsPerNpc = 40,   -- límite de puntos por PNJ objetivo
        pinScale = 1.0,
        tooltips = true,
        objectiveIcons = true,  -- iconos (espada, bolsa...) en vez de puntos
        showMinimap = true,     -- pines también en el minimapa
        share = true,           -- compartir lo aprendido con grupo y hermandad
        demo = false,
        debug = false,
    },
    char = {
        ignored = {},           -- [questID] = true, misiones ocultadas a mano
    },
}

local function applyDefaults(dst, src)
    for k, v in pairs(src) do
        if type(v) == "table" then
            if type(dst[k]) ~= "table" then dst[k] = {} end
            applyDefaults(dst[k], v)
        elseif dst[k] == nil then
            dst[k] = v
        end
    end
end

---------------------------------------------------------------------------
-- Utilidades
---------------------------------------------------------------------------
function ns:Print(...)
    local msg = strjoin(" ", tostringall(...))
    DEFAULT_CHAT_FRAME:AddMessage("|cff33ccffSenda|r: " .. msg)
end

function ns:Debug(...)
    if self.settings and self.settings.debug then
        self:Print("|cff999999[debug]|r", ...)
    end
end

---------------------------------------------------------------------------
-- Mensajes internos (pub/sub entre módulos, sin depender de librerías)
---------------------------------------------------------------------------
local listeners = {}

function ns:On(message, fn)
    listeners[message] = listeners[message] or {}
    table.insert(listeners[message], fn)
end

function ns:Fire(message, ...)
    local list = listeners[message]
    if not list then return end
    for i = 1, #list do
        local ok, err = pcall(list[i], ...)
        if not ok then geterrorhandler()(err) end
    end
end

---------------------------------------------------------------------------
-- Eventos del juego
---------------------------------------------------------------------------
local eventFrame = CreateFrame("Frame")
local eventHandlers = {}
ns.eventFrame = eventFrame

function ns:RegisterEvent(event, fn)
    if not eventHandlers[event] then
        eventHandlers[event] = {}
        eventFrame:RegisterEvent(event)
    end
    table.insert(eventHandlers[event], fn)
end

eventFrame:SetScript("OnEvent", function(_, event, ...)
    local list = eventHandlers[event]
    if not list then return end
    for i = 1, #list do
        local ok, err = pcall(list[i], event, ...)
        if not ok then geterrorhandler()(err) end
    end
end)

---------------------------------------------------------------------------
-- Módulos: cada archivo hace `local M = ns:NewModule("Nombre")` y puede
-- definir M:OnInit() (al cargar variables) y M:OnEnable() (al entrar al mundo).
---------------------------------------------------------------------------
ns.modules = {}
local moduleOrder = {}

function ns:NewModule(name)
    local m = { name = name }
    self.modules[name] = m
    table.insert(moduleOrder, m)
    return m
end

function ns:GetModule(name)
    return self.modules[name]
end

local function callAll(method)
    for i = 1, #moduleOrder do
        local m = moduleOrder[i]
        if m[method] then
            local ok, err = pcall(m[method], m)
            if not ok then geterrorhandler()(err) end
        end
    end
end

-- Programar un refresco agrupado: varios eventos seguidos -> un único "Refresh".
local refreshPending = false
function ns:RequestRefresh()
    if refreshPending then return end
    refreshPending = true
    C_Timer.After(0.2, function()
        refreshPending = false
        ns:Fire("SENDA_REFRESH")
    end)
end

ns:RegisterEvent("ADDON_LOADED", function(_, name)
    if name ~= ADDON then return end
    SendaDB = SendaDB or {}
    SendaCharDB = SendaCharDB or {}
    applyDefaults(SendaDB, ns.defaults.global)
    applyDefaults(SendaCharDB, ns.defaults.char)
    ns.settings = SendaDB
    ns.charSettings = SendaCharDB
    callAll("OnInit")
end)

ns:RegisterEvent("PLAYER_LOGIN", function()
    callAll("OnEnable")
    ns:RequestRefresh()
end)
