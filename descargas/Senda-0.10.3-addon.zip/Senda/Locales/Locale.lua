-- Senda (c) 2026 Tzors. Todos los derechos reservados. Ver LICENSE.txt.
-- Textos de la interfaz. Los nombres de misiones y PNJ vienen de la base de
-- datos (el exportador los genera en el idioma configurado).

local _, ns = ...

local L = setmetatable({}, { __index = function(_, k) return k end })
ns.L = L

local locale = GetLocale()

-- Inglés (base)
L.AVAILABLE      = "Available quest"
L.TURN_IN        = "Turn in"
L.TURN_IN_NOT_READY = "Turn in (not completed)"
L.OBJECTIVE      = "Objective"
L.QUEST_AREA     = "Objective area"
L.QUEST_PLACE    = "Quest location (approximate)"
L.STARTS         = "Starts"
L.ENDS           = "Ends"
L.LEVEL          = "Level"
L.ENABLED        = "enabled"
L.DISABLED       = "disabled"
L.HELP = {
    "/senda - toggle map pins",
    "/senda disponibles | entregas | objetivos - toggle each pin type",
    "/senda grises - toggle low-level quests",
    "/senda ignorar <questID> - hide a quest",
    "/senda demo - demo pins (to test the map)",
    "/senda info - database status",
    "/senda por <questID> - why a quest is (not) available",
    "/senda iconos - Senda icons or the classic ones",
    "/senda minimapa - show pins on the minimap",
    "/senda pendientes - also show '?' for unfinished quests",
    "/senda compartir - share what you learn (group, guild, friends, other Senda users)",
    "/senda archivo - how to send your data to improve the addon",
    "/senda debug",
}
L.DB_STATUS = "Database: %d quests, %d NPCs, %d objects, %d zones."
L.LEARN_STATUS = "Learned while playing: %d NPCs, %d objects, %d quest givers, %d turn-ins."
L.NEW_VERSION = "|cffffd100There is a new version of Senda (%s).|r Download it from github.com/Tukitaaa/Senda"
L.SHARE_STATUS = "Sharing with group/guild: %s. Received this session: %d."
L.FILE_HELP = {
    "Everything you learn is saved in this file (after logging out or /reload):",
    "WoW\\WTF\\Account\\<YOUR ACCOUNT>\\SavedVariables\\Senda.lua",
    "Send that file to the addon author: it is merged with everyone else's and comes in the next version.",
}

if locale == "esES" or locale == "esMX" then
    L.AVAILABLE      = "Misión disponible"
    L.TURN_IN        = "Entregar"
    L.TURN_IN_NOT_READY = "Entregar (sin completar)"
    L.OBJECTIVE      = "Objetivo"
    L.QUEST_AREA     = "Zona del objetivo"
    L.QUEST_PLACE    = "Lugar de la misión (aproximado)"
    L.STARTS         = "Empieza"
    L.ENDS           = "Termina"
    L.LEVEL          = "Nivel"
    L.ENABLED        = "activado"
    L.DISABLED       = "desactivado"
    L.HELP = {
        "/senda - activar/desactivar pines del mapa",
        "/senda disponibles | entregas | objetivos - activar cada tipo de pin",
        "/senda grises - mostrar misiones de nivel bajo",
        "/senda ignorar <questID> - ocultar una misión",
        "/senda demo - pines de demostración (para probar el mapa)",
        "/senda info - estado de la base de datos",
        "/senda volcar - guardar límites de mapas para el exportador",
        "/senda por <questID> - por qué una misión (no) está disponible",
        "/senda iconos - iconos de Senda o los clásicos",
        "/senda minimapa - mostrar pines en el minimapa",
        "/senda pendientes - mostrar también el '?' de misiones sin terminar",
        "/senda compartir - compartir lo que aprendes (grupo, hermandad, amigos y otros con Senda)",
        "/senda archivo - cómo enviar tus datos para mejorar el addon",
        "/senda debug",
    }
    L.DB_STATUS = "Base de datos: %d misiones, %d PNJ, %d objetos, %d zonas."
    L.LEARN_STATUS = "Aprendido jugando: %d PNJ, %d objetos, %d misiones con dador, %d con entrega."
    L.NEW_VERSION = "|cffffd100Hay una versión nueva de Senda (%s).|r Bájala de github.com/Tukitaaa/Senda"
    L.SHARE_STATUS = "Compartir con grupo/hermandad: %s. Recibido en esta sesión: %d."
    L.FILE_HELP = {
        "Todo lo que aprendes se guarda en este archivo (al salir del juego o con /reload):",
        "WoW\\WTF\\Account\\<TU CUENTA>\\SavedVariables\\Senda.lua",
        "Envía ese archivo al autor del addon: se junta con el de todos y llega en la próxima versión.",
    }
end
