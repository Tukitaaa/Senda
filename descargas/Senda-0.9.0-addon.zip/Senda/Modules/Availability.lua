-- Senda (c) 2026 Tzors. Todos los derechos reservados. Ver LICENSE.txt.
-- Reglas de disponibilidad: ¿puede este personaje coger esta misión ahora?
-- Se basa en los campos que exporta TrinityCore (quest_template +
-- quest_template_addon). Ver docs/FORMATO_DATOS.md.

local _, ns = ...

local AV = ns:NewModule("Availability")
ns.Availability = AV

local band = bit.band

AV.player = { level = 1, raceBit = 0, classBit = 0 }

function AV:UpdatePlayer()
    local p = self.player
    p.level = UnitLevel("player")
    local raceID = select(3, UnitRace("player"))
    local classID = select(3, UnitClass("player"))
    -- Máscaras de TrinityCore: bit (id - 1). Las razas aliadas de 7.3.5
    -- (ids 27-30) caben en 32 bits.
    p.raceBit = raceID and 2 ^ (raceID - 1) or 0
    p.classBit = classID and 2 ^ (classID - 1) or 0
end

local function maskAllows(mask, bitValue)
    if not mask or mask == 0 or mask == -1 or mask == 4294967295 then return true end
    -- La librería bit de WoW trabaja con enteros de 32 bits con signo.
    if mask >= 2147483648 then mask = mask - 4294967296 end
    return band(mask, bitValue) ~= 0
end

--- Devuelve true si la misión aparecería como "!" para este personaje.
--- El segundo valor explica el motivo cuando no está disponible (para /senda debug).
function AV:IsAvailable(questID)
    local q = ns.DB.quests[questID]
    if not q then return false, "sin datos" end
    local QS = ns.QuestState

    if ns.charSettings.ignored[questID] then return false, "ignorada" end
    if QS:IsCompleted(questID) then return false, "completada" end
    if QS:IsActive(questID) then return false, "en el registro" end

    local p = self.player
    if q.minLevel and p.level < q.minLevel then return false, "nivel" end
    if q.maxLevel and q.maxLevel > 0 and p.level > q.maxLevel then return false, "nivel máximo" end
    if not maskAllows(q.races, p.raceBit) then return false, "raza/facción" end
    if not maskAllows(q.classes, p.classBit) then return false, "clase" end

    -- Prerrequisitos (PrevQuestID de TC):
    --   positivo -> debe estar completada; negativo -> debe estar activa.
    if q.prev then
        for _, pre in ipairs(q.prev) do
            if pre > 0 and not QS:IsCompleted(pre) then return false, "prerrequisito " .. pre end
            if pre < 0 and not QS:IsActive(-pre) then return false, "requiere activa " .. -pre end
        end
    end
    -- Requiere CUALQUIERA de estas completada (cadenas con ramas).
    if q.prevAny and #q.prevAny > 0 then
        local ok = false
        for _, pre in ipairs(q.prevAny) do
            if QS:IsCompleted(pre) then ok = true break end
        end
        if not ok then return false, "prerrequisito (alguna)" end
    end

    -- Grupo exclusivo (ExclusiveGroup > 0): si ya hiciste/tienes una del
    -- grupo, las demás desaparecen.
    if q.excl and q.excl > 0 then
        for _, other in ipairs(ns.DB.exclGroups[q.excl] or {}) do
            if other ~= questID and (QS:IsCompleted(other) or QS:IsActive(other)) then
                return false, "grupo exclusivo"
            end
        end
    end

    -- Misma misión con otro número: el servidor a veces usa un ID distinto al
    -- de la base de datos (variantes por clase/raza con el mismo nombre). Si
    -- tienes en el registro una con el mismo nombre, o ya hiciste una con el
    -- mismo nombre que da el mismo PNJ, esta no se muestra.
    if q.name then
        local lname = strlower(q.name)
        for _, state in pairs(QS.active) do
            if state.title and strlower(state.title) == lname then return false, "en el registro (mismo nombre)" end
        end
        for _, other in ipairs(ns.DB.byName[lname] or {}) do
            if other ~= questID and QS:IsCompleted(other) and AV.SameStarter(q, ns.DB.quests[other]) then
                return false, "completada (mismo nombre)"
            end
        end
    end

    return true
end

local function shares(a, b)
    if not a or not b then return false end
    for _, x in ipairs(a) do
        for _, y in ipairs(b) do
            if x == y then return true end
        end
    end
    return false
end

--- ¿Las dos misiones las da el mismo PNJ u objeto?
function AV.SameStarter(a, b)
    local sa, sb = a and a.start, b and b.start
    if not sa or not sb then return false end
    return shares(sa.npcs, sb.npcs) or shares(sa.objects, sb.objects)
end

--- ¿Es "gris" (demasiado baja para dar experiencia)?
function AV:IsLowLevel(questID)
    local q = ns.DB.quests[questID]
    if not q or not q.level or q.level <= 0 then return false end -- nivel escalable
    return (self.player.level - q.level) >= ns.settings.lowLevelDiff
end

function AV:OnEnable()
    self:UpdatePlayer()
    ns:RegisterEvent("PLAYER_LEVEL_UP", function(_, newLevel)
        AV:UpdatePlayer()
        if newLevel then AV.player.level = newLevel end
    end)
end
