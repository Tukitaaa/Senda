-- Senda (c) 2026 Tzors. Todos los derechos reservados. Ver LICENSE.txt.
-- Pines en el minimapa: los mismos que en el mapa de tu zona actual, pero
-- colocados alrededor de tu posición según el zoom del minimapa.
--
-- Cuentas: la posición en el mapa (0-1) se pasa a metros del juego (yardas)
-- con el tamaño de la zona, y las yardas a píxeles con el diámetro que cubre
-- el minimapa en cada nivel de zoom (distinto en interiores y exteriores).

local _, ns = ...

local MM = ns:NewModule("Minimap")
ns.MinimapPins = MM

-- Diámetro en yardas que muestra el minimapa en cada zoom (0 = el más lejano).
MM.diameters = {
    indoor  = { [0] = 300, 240, 180, 120, 80, 50 },
    outdoor = { [0] = 466 + 2 / 3, 400, 333 + 1 / 3, 266 + 2 / 3, 200, 133 + 1 / 3 },
}

-- Tamaño en píxeles de cada tipo de pin en el minimapa.
local SIZE = { available = 14, lowlevel = 12, turnin = 14, turnin_wait = 12, objective = 6, icon = 13 }
local UPDATE_EVERY = 0.05

local pool, used = {}, 0
local pins = {}
local mapID, mapW, mapH
local indoors = false
local elapsed = 0
local needRefresh = true

local function acquire()
    used = used + 1
    local f = pool[used]
    if not f then
        f = CreateFrame("Button", nil, Minimap)
        f:SetFrameLevel(Minimap:GetFrameLevel() + 5)
        f.ring = f:CreateTexture(nil, "BACKGROUND")
        f.ring:SetTexture("Interface\\CHARACTERFRAME\\TempPortraitAlphaMask")
        f.ring:SetAllPoints()
        f.ring:SetVertexColor(0.78, 0.62, 0.25, 1)
        f.bg = f:CreateTexture(nil, "BORDER")
        f.bg:SetTexture("Interface\\CHARACTERFRAME\\TempPortraitAlphaMask")
        f.bg:SetPoint("TOPLEFT", 1, -1)
        f.bg:SetPoint("BOTTOMRIGHT", -1, 1)
        f.bg:SetVertexColor(0.05, 0.04, 0.03, 0.95)
        f.outline = f:CreateTexture(nil, "ARTWORK")
        f.outline:SetAllPoints()
        f.icon = f:CreateTexture(nil, "OVERLAY")
        f:SetScript("OnEnter", function(self) ns.MapPins.PinOnEnter(self) end)
        f:SetScript("OnLeave", function(self) ns.MapPins.PinOnLeave(self) end)
        pool[used] = f
    end
    return f
end

local function hideAll()
    for i = 1, used do
        pool[i]:Hide()
        pool[i].data = nil
    end
    used = 0
end

--- ¿Estamos en interiores? Truco conocido: las variables de zoom de interior
--- y exterior solo coinciden con el zoom actual en el modo en que estás.
function MM:UpdateIndoors()
    local zoom = Minimap:GetZoom()
    if GetCVar("minimapZoom") == GetCVar("minimapInsideZoom") then
        Minimap:SetZoom(zoom < 2 and zoom + 1 or zoom - 1)
    end
    indoors = tonumber(GetCVar("minimapZoom")) ~= Minimap:GetZoom()
    Minimap:SetZoom(zoom)
end

--- Recalcula qué pines hay en la zona actual (no cada fotograma).
function MM:Refresh()
    if WorldMapFrame:IsShown() then
        needRefresh = true
        return
    end
    needRefresh = false
    SetMapToCurrentZone()
    mapID = GetCurrentMapAreaID()
    local _, left, top, right, bottom = GetCurrentMapZone()
    if left and right and left ~= right and top ~= bottom then
        mapW, mapH = left - right, top - bottom
    else
        mapW, mapH = nil, nil
    end
    pins = (mapW and ns.settings.enabled and ns.settings.showMinimap) and ns.MapPins:Collect(mapID) or {}
end

--- Posición de un pin respecto al centro del minimapa, en píxeles (nil si queda fuera).
function MM.Offset(pin, px, py, facing, pixelsPerYard, radius)
    local dx, dy = (pin.x - px) * mapW, (pin.y - py) * mapH
    if facing then
        local s, c = math.sin(facing), math.cos(facing)
        dx, dy = dx * c - dy * s, dx * s + dy * c
    end
    dx, dy = dx * pixelsPerYard, dy * pixelsPerYard
    if dx * dx + dy * dy > radius * radius then return nil end
    return dx, dy
end

function MM:Update()
    hideAll()
    if not mapW or #pins == 0 or WorldMapFrame:IsShown() then return end
    if GetCurrentMapAreaID() ~= mapID then needRefresh = true return end
    local px, py = GetPlayerMapPosition("player")
    if not px or (px == 0 and py == 0) then return end

    local w = Minimap:GetWidth()
    local diameter = self.diameters[indoors and "indoor" or "outdoor"][Minimap:GetZoom()] or 466
    local ppy = w / diameter
    local radius = w / 2 - 3
    local facing = GetCVar("rotateMinimap") == "1" and GetPlayerFacing() or nil
    local MP = ns.MapPins

    for _, pin in ipairs(pins) do
        local x, y = MM.Offset(pin, px, py, facing, ppy, radius)
        if x then
            local style = MP:StyleFor(pin)
            local size
            if pin.kind == "area" then
                size = math.max(10, (pin.radius or 2) / 100 * mapW * ppy * 2)
            elseif style.ring then
                size = SIZE.icon
            else
                size = SIZE[pin.kind] or 10
            end
            local f = acquire()
            f.data = pin
            f:SetSize(size, size)
            f:SetFrameLevel(Minimap:GetFrameLevel() + 2 + math.floor(style.layer / 5))
            f.icon:ClearAllPoints()
            if style.circle then
                f.ring:Show(); f.bg:Show()
                f.ring:SetDesaturated(style.desaturate and true or false)
                f.icon:SetPoint("TOPLEFT", f, "TOPLEFT", size * 0.18, -size * 0.15)
                f.icon:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -size * 0.18, size * 0.21)
            else
                f.ring:Hide(); f.bg:Hide()
                f.icon:SetAllPoints()
            end
            f.icon:SetTexture(style.texture)
            f.icon:SetDesaturated(style.desaturate and true or false)
            if style.color then f.icon:SetVertexColor(unpack(style.color)) else f.icon:SetVertexColor(1, 1, 1, 1) end
            if style.ring and pin.color then
                f.outline:SetTexture(style.ring)
                f.outline:SetVertexColor(pin.color[1], pin.color[2], pin.color[3], 1)
                f.outline:Show()
            else
                f.outline:Hide()
            end
            f:ClearAllPoints()
            f:SetPoint("CENTER", Minimap, "CENTER", x, -y)
            f:Show()
        end
    end
end

function MM:OnEnable()
    if not Minimap then return end
    self:UpdateIndoors()
    local driver = CreateFrame("Frame")
    driver:SetScript("OnUpdate", function(_, dt)
        elapsed = elapsed + dt
        if elapsed < UPDATE_EVERY then return end
        elapsed = 0
        if needRefresh then MM:Refresh() end
        MM:Update()
    end)
    local function refresh() needRefresh = true end
    ns:On("SENDA_REFRESH", refresh)
    for _, e in ipairs({ "ZONE_CHANGED", "ZONE_CHANGED_INDOORS", "ZONE_CHANGED_NEW_AREA", "PLAYER_ENTERING_WORLD" }) do
        ns:RegisterEvent(e, function() refresh(); MM:UpdateIndoors() end)
    end
    ns:RegisterEvent("MINIMAP_UPDATE_ZOOM", function() MM:UpdateIndoors() end)
    WorldMapFrame:HookScript("OnHide", refresh)
end
