-- Senda (c) 2026 Tzors. Todos los derechos reservados. Ver LICENSE.txt.
-- Comandos /senda

local _, ns = ...
local L = ns.L

local CMD = ns:NewModule("Commands")

local toggles = {
    disponibles = "showAvailable",
    entregas = "showTurnIn",
    objetivos = "showObjectives",
    grises = "showLowLevel",
    tooltips = "tooltips",
    compartir = "share",
    iconos = "objectiveIcons",
    minimapa = "showMinimap",
    flecha = "showArrow",
    pendientes = "showTurnInWait",
    debug = "debug",
}

local function toggle(key, label)
    ns.settings[key] = not ns.settings[key]
    ns:Print(label, ns.settings[key] and L.ENABLED or L.DISABLED)
    ns:RequestRefresh()
end

function CMD.Handle(msg)
    local cmd, arg = strsplit(" ", strlower(strtrim(msg or "")), 2)

    if cmd == "" then
        toggle("enabled", "Senda")
    elseif toggles[cmd] then
        toggle(toggles[cmd], cmd)
    elseif cmd == "opciones" or cmd == "config" or cmd == "options" then
        ns.Options:Open()
    elseif cmd == "boton" or cmd == "botón" then
        ns.Options:Set("minimapButton", not ns.settings.minimapButton)
        ns:Print(cmd, ns.settings.minimapButton and L.ENABLED or L.DISABLED)
    elseif cmd == "demo" then
        ns.settings.demo = not ns.settings.demo
        if ns.settings.demo then ns.Demo:Enable() end
        ns.QuestState:ScanLog()
        ns:Print("demo", ns.settings.demo and L.ENABLED or L.DISABLED,
            ns.settings.demo and "(abre el mapa de Azsuna)" or "")
        ns:RequestRefresh()
    elseif cmd == "ignorar" then
        if arg == "limpiar" then
            wipe(ns.charSettings.ignored)
            ns:Print("lista de ocultas vaciada")
        elseif tonumber(arg) then
            local id = tonumber(arg)
            ns.charSettings.ignored[id] = not ns.charSettings.ignored[id] or nil
            ns:Print("misión", id, ns.charSettings.ignored[id] and "oculta" or "visible")
        end
        ns:RequestRefresh()
    elseif cmd == "volcar" then
        ns:GetModule("MapDump"):Run()
    elseif cmd == "info" then
        ns:Print(string.format(L.DB_STATUS, ns.DB:Counts()))
        ns:Print(string.format(L.LEARN_STATUS, ns.Learn:Counts()))
        ns:Print(string.format(L.SHARE_STATUS, ns.settings.share and L.ENABLED or L.DISABLED, ns.Sync.receivedCount))
    elseif cmd == "diag" then
        ns:GetModule("MapPins"):Diagnose()
    elseif cmd == "archivo" then
        for _, line in ipairs(L.FILE_HELP) do ns:Print(line) end
    elseif cmd == "por" and tonumber(arg) then
        -- /senda por <questID>: explica por qué una misión (no) está disponible
        local ok, why = ns.Availability:IsAvailable(tonumber(arg))
        ns:Print(arg, ok and "disponible" or ("no disponible: " .. tostring(why)))
    else
        for _, line in ipairs(L.HELP) do ns:Print(line) end
    end
end

SLASH_SENDA1 = "/senda"
SlashCmdList.SENDA = CMD.Handle
