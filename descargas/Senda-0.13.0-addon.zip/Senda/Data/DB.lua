-- Senda (c) 2026 Tzors. Todos los derechos reservados. Ver LICENSE.txt.
-- Base de datos en memoria + índices.
--
-- Cada archivo de zona (Data/Zones/*.lua, generado por tools/export_tc.py)
-- llama a ns.DB:RegisterZone{...}. Aquí se fusiona todo en tablas globales
-- (una misión o PNJ puede aparecer en varias zonas) y se construyen índices
-- inversos para responder rápido "¿qué misiones da este PNJ?" o
-- "¿qué misiones activas necesitan matar a este PNJ?".
--
-- Formato completo documentado en docs/FORMATO_DATOS.md.

local _, ns = ...

local DB = {
    quests  = {},  -- [questID] = { name, level, minLevel, races, classes, start, finish, prev, excl, objectives }
    npcs    = {},  -- [npcID]   = { name, spawns = { [mapID] = { {x,y}, ... } } }
    objects = {},  -- [goID]    = { name, spawns = { [mapID] = { {x,y}, ... } } }
    items   = {},  -- [itemID]  = { name, npcs = {npcID...}, objects = {goID...} }
    zones   = {},  -- [mapID]   = { name }

    -- índices (se construyen en Build)
    startsAt   = { npc = {}, object = {} },  -- [id] = { questID, ... }
    endsAt     = { npc = {}, object = {} },
    exclGroups = {},                          -- [grupo] = { questID, ... }
    byName     = {},                          -- [nombre en minúsculas] = { questID, ... }
    startPois  = {},                          -- [mapID] = { questID, ... } (dador deducido por cadena)
}
ns.DB = DB

local dirty = false

local function mergeSpawns(dstEntity, mapID, spawns)
    dstEntity.spawns = dstEntity.spawns or {}
    local list = dstEntity.spawns[mapID]
    if not list then
        list = {}
        dstEntity.spawns[mapID] = list
    end
    for i = 1, #spawns do
        list[#list + 1] = spawns[i]
    end
end

local function mergeEntities(dst, src, mapID)
    if not src then return end
    for id, e in pairs(src) do
        local cur = dst[id]
        if not cur then
            cur = { name = e.name }
            dst[id] = cur
        end
        if e.spawns then mergeSpawns(cur, mapID, e.spawns) end
    end
end

--- Registra los datos de una zona. Puede llamarse varias veces por zona.
function DB:RegisterZone(zone)
    local mapID = assert(zone.mapID, "RegisterZone: falta mapID")
    self.zones[mapID] = self.zones[mapID] or { name = zone.name }

    for id, q in pairs(zone.quests or {}) do
        -- La misión puede venir en varios archivos de zona: se conserva la
        -- primera definición y se suman sus áreas del mapa (poi) de cada zona.
        local cur = self.quests[id]
        if not cur then
            cur = q
            self.quests[id] = q
        end
        if q.poi then
            cur.pois = cur.pois or {}
            cur.pois[mapID] = q.poi
            q.poi = nil
        end
    end
    mergeEntities(self.npcs, zone.npcs, mapID)
    mergeEntities(self.objects, zone.objects, mapID)
    for id, it in pairs(zone.items or {}) do
        self.items[id] = it
    end
    dirty = true
end

local function addIndex(index, id, questID)
    local list = index[id]
    if not list then
        list = {}
        index[id] = list
    end
    list[#list + 1] = questID
end

--- Construye los índices inversos. Se llama una vez al iniciar (o tras
--- registrar datos nuevos).
--- Nombres en el idioma del cliente (Data/Names_*.lua). Se aplican sobre los
--- nombres de los archivos de zona, que vienen en español.
function DB:RegisterNames(names)
    for id, name in pairs(names.quests or {}) do
        local q = self.quests[id]
        if q then q.name = name end
    end
    for id, name in pairs(names.npcs or {}) do
        local e = self.npcs[id]
        if e then e.name = name end
    end
    for id, name in pairs(names.objects or {}) do
        local e = self.objects[id]
        if e then e.name = name end
    end
    dirty = true
end

function DB:Build()
    if not dirty then return end
    wipe(self.startsAt.npc); wipe(self.startsAt.object)
    wipe(self.endsAt.npc);   wipe(self.endsAt.object)
    wipe(self.exclGroups)
    wipe(self.byName)
    wipe(self.startPois)

    for questID, q in pairs(self.quests) do
        local s, f = q.start, q.finish
        if s then
            for _, id in ipairs(s.npcs or {}) do addIndex(self.startsAt.npc, id, questID) end
            for _, id in ipairs(s.objects or {}) do addIndex(self.startsAt.object, id, questID) end
        end
        if f then
            for _, id in ipairs(f.npcs or {}) do addIndex(self.endsAt.npc, id, questID) end
            for _, id in ipairs(f.objects or {}) do addIndex(self.endsAt.object, id, questID) end
        end
        if q.excl and q.excl > 0 then addIndex(self.exclGroups, q.excl, questID) end
        if q.name then addIndex(self.byName, strlower(q.name), questID) end
    end
    self:DeriveChainStarts()
    dirty = false
end

local function hasSpawns(store, ids)
    for _, id in ipairs(ids or {}) do
        local e = store[id]
        if e and e.spawns and next(e.spawns) then return true end
    end
    return false
end

--- Misiones sin dador ubicado: en una cadena, quien te da la siguiente suele
--- ser quien te recibió la anterior. Usamos la entrega de la misión previa
--- (su PNJ, o su área de entrega del mapa) como dador probable.
function DB:DeriveChainStarts()
    for questID, q in pairs(self.quests) do
        local s = q.start
        if q.prev and #q.prev > 0 and not (s and (hasSpawns(self.npcs, s.npcs) or hasSpawns(self.objects, s.objects))) then
            for _, pre in ipairs(q.prev) do
                local p = pre > 0 and self.quests[pre]
                if p then
                    local f = p.finish or {}
                    if hasSpawns(self.npcs, f.npcs) or hasSpawns(self.objects, f.objects) then
                        for _, id in ipairs(f.npcs or {}) do addIndex(self.startsAt.npc, id, questID) end
                        for _, id in ipairs(f.objects or {}) do addIndex(self.startsAt.object, id, questID) end
                        q.derivedStart = true
                        break
                    elseif p.pois then
                        for mapID, poi in pairs(p.pois) do
                            if poi.finish then
                                q.startPoi = q.startPoi or {}
                                q.startPoi[mapID] = poi.finish
                                addIndex(self.startPois, mapID, questID)
                            end
                        end
                        if q.startPoi then break end
                    end
                end
            end
        end
    end
end

function DB:FindQuestsByName(name)
    if not name then return {} end
    return self.byName[strlower(strtrim(name))] or {}
end

---------------------------------------------------------------------------
-- Datos aprendidos en el juego (Modules/Learn.lua)
---------------------------------------------------------------------------

local function contains(list, v)
    for i = 1, #list do
        if list[i] == v then return true end
    end
    return false
end

function DB:AddLearnedSpawn(kind, id, name, mapID, x, y)
    local store = kind == "npc" and self.npcs or self.objects
    local e = store[id]
    if not e then
        e = { name = name }
        store[id] = e
    end
    if not e.name and name then e.name = name end
    mergeSpawns(e, mapID, { { x, y } })
end

function DB:AddLearnedRelation(side, questID, kind, id)
    local q = self.quests[questID]
    if not q then
        -- Misión que la base de datos no conoce: la creamos con lo mínimo.
        q = { name = "#" .. questID, level = 0, minLevel = 0, objectives = {} }
        self.quests[questID] = q
    end
    local key = side == "start" and "start" or "finish"
    q[key] = q[key] or {}
    local field = kind == "npc" and "npcs" or "objects"
    q[key][field] = q[key][field] or {}
    if contains(q[key][field], id) then return end
    table.insert(q[key][field], id)
    if not dirty then
        local index = (side == "start" and self.startsAt or self.endsAt)[kind == "npc" and "npc" or "object"]
        addIndex(index, id, questID)
    end
end

--- Objetivo aprendido (sin saber a qué línea del registro corresponde):
--- se muestra mientras la misión no esté completa.
function DB:AddLearnedObjective(questID, objType, id)
    local q = self.quests[questID]
    if not q then return end
    q.objectives = q.objectives or {}
    for _, o in ipairs(q.objectives) do
        if o.type == objType and (o.id == id or (o.also and contains(o.also, id))) then return end
    end
    table.insert(q.objectives, { type = objType, id = id, learned = true })
end

function DB:RegisterLearned(l, noBuild)
    for kind, store in pairs({ npc = l.npcs, object = l.objects }) do
        for id, e in pairs(store) do
            for mapID, spawns in pairs(e.spawns or {}) do
                for _, s in ipairs(spawns) do self:AddLearnedSpawn(kind, id, e.name, mapID, s[1], s[2]) end
            end
        end
    end
    for side, map in pairs({ start = l.starts, finish = l.ends }) do
        for questID, r in pairs(map) do
            for _, id in ipairs(r.npcs or {}) do self:AddLearnedRelation(side, questID, "npc", id) end
            for _, id in ipairs(r.objects or {}) do self:AddLearnedRelation(side, questID, "object", id) end
        end
    end
    for questID, ids in pairs(l.objNpcs) do
        for id in pairs(ids) do self:AddLearnedObjective(questID, "monster", id) end
    end
    for questID, ids in pairs(l.objObjects) do
        for id in pairs(ids) do self:AddLearnedObjective(questID, "object", id) end
    end
    dirty = true
    if not noBuild then self:Build() end
end

function DB:GetQuest(id) return self.quests[id] end
function DB:GetNpc(id) return self.npcs[id] end
function DB:GetObject(id) return self.objects[id] end
function DB:GetItem(id) return self.items[id] end

--- Devuelve la entidad (PNJ u objeto) según su tipo.
function DB:GetEntity(kind, id)
    if kind == "npc" then return self.npcs[id] end
    return self.objects[id]
end

function DB:Counts()
    local function count(t) local n = 0 for _ in pairs(t) do n = n + 1 end return n end
    return count(self.quests), count(self.npcs), count(self.objects), count(self.zones)
end

local M = ns:NewModule("DB")
function M:OnInit()
    DB:Build()
end
