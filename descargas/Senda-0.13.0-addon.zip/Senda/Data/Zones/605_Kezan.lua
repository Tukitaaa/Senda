-- ARCHIVO GENERADO por tools/export_tc.py. No editar a mano: se sobrescribe.
-- Datos derivados de TrinityCore (C) 2008+ TrinityCore, licencia GNU GPL v2.
-- Ver LEEME-DATOS.txt y LICENSE-GPL2.txt en esta carpeta.
-- Zona: Kezan (mapID 605, continente 646, área 0)
-- 29 misiones, 0 PNJ, 0 objetos.

local _, ns = ...

ns.DB:RegisterZone({
    mapID = 605,
    name = "Kezan",
    quests = {
        [14069] = { name = "El buen servicio es difícil de encontrar", level = 1, minLevel = 1, races = 256, start = { npcs = { 34872 } }, finish = { npcs = { 34872 } }, prev = { 14138 }, excl = 14069, objectives = { { type = "monster", id = 34830, count = 8 } }, poi = { finish = { 60.5, 74.4 }, obj = { { 0, 70.4, 82.6, 5.1 } } } },
        [14070] = { name = "Encárgate personalmente", level = 3, minLevel = 1, races = 256, start = { npcs = { 34668, 34835, 34876, 34877, 34878 } }, finish = { npcs = { 34668 } }, prev = { 14071 }, objectives = { { type = "monster", id = 34835, count = 1 }, { type = "monster", id = 34876, count = 1 }, { type = "monster", id = 34877, count = 1 }, { type = "monster", id = 34878, count = 1 } }, poi = { finish = { 56.9, 76.4 }, obj = { { 0, 41.7, 81.9, 1.5 }, { 0, 35.1, 77.9, 1.5 }, { 0, 36.8, 70.0, 1.5 }, { 0, 45.3, 74.8, 1.5 } } } },
        [14071] = { name = "Voy en un coche...", level = 3, minLevel = 1, races = 256, start = { npcs = { 34874, 34957, 34958, 34959 } }, finish = { npcs = { 34874 } }, prev = { 28349 }, objectives = { { type = "monster", id = 48323, count = 1 }, { type = "monster", id = 34959, count = 1 }, { type = "monster", id = 34957, count = 1 }, { type = "monster", id = 34958, count = 1 } }, poi = { finish = { 58.6, 75.0 }, obj = { { 0, 60.4, 49.3, 1.5 }, { 0, 47.8, 38.1, 1.5 }, { 0, 58.0, 85.9, 1.5 }, { 0, 58.6, 75.1, 1.5 } } } },
        [14075] = { name = "Problemas en las minas", level = 1, minLevel = 1, races = 256, start = { npcs = { 34872 } }, finish = { npcs = { 34872 } }, excl = 14069, objectives = { { type = "monster", id = 34865, count = 6 } }, poi = { finish = { 21.6, 13.5 }, obj = { { 0, 63.5, 96.0, 5.6 }, { 0, 78.2, 86.7, 3.4 }, { 0, 73.6, 71.2, 3.4 } } } },
        [14109] = { name = "Tu nuevo yo", level = 3, minLevel = 1, races = 256, start = { npcs = { 35120 } }, finish = { npcs = { 35053 } }, prev = { 26712 }, objectives = { { type = "item", id = 47045, count = 1 }, { type = "item", id = 47046, count = 1 }, { type = "item", id = 47047, count = 1 } }, poi = { finish = { 56.3, 77.1 }, obj = { { 0, 40.3, 45.8, 1.5 }, { 0, 37.7, 55.5, 1.5 }, { 0, 34.8, 45.8, 1.5 } } } },
        [14110] = { name = "Tu nuevo yo", level = 3, minLevel = 1, races = 256, start = { npcs = { 35120 } }, finish = { npcs = { 35054 } }, prev = { 26711 }, objectives = { { type = "item", id = 47045, count = 1 }, { type = "item", id = 47046, count = 1 }, { type = "item", id = 47047, count = 1 } }, poi = { finish = { 56.3, 76.8 }, obj = { { 0, 40.3, 45.8, 1.5 }, { 0, 37.7, 55.5, 1.5 }, { 0, 34.8, 45.8, 1.5 } } } },
        [14113] = { name = "El alma de la fiesta", level = 3, minLevel = 1, races = 256, start = { npcs = { 35053, 35175 } }, finish = { npcs = { 34668 } }, excl = 14113, objectives = { { type = "monster", id = 35175, count = 10, also = { 35186, 40071 } } }, poi = { finish = { 56.5, 76.0 }, obj = { { 0, 58.2, 83.3, 5.5 } } } },
        [14115] = { name = "Aguafiestas piratas", level = 4, minLevel = 1, races = 256, start = { npcs = { 34668, 35200 } }, finish = { npcs = { 34668 } }, prev = { 14113, 14153 }, prevAny = { 14113, 14153 }, objectives = { { type = "monster", id = 35200, count = 12 } }, poi = { finish = { 56.5, 75.5 }, obj = { { 0, 58.6, 84.3, 6.0 }, { 0, 58.4, 68.3, 1.5 } } } },
        [14116] = { name = "El invitado no deseado", level = 4, minLevel = 1, races = 256, start = { npcs = { 34668 } }, finish = { npcs = { 35222 } }, prev = { 14115 }, objectives = {}, poi = { finish = { 57.8, 76.9 } } },
        [14120] = { name = "¡¿Un bazillón de macarrones?!", level = 4, minLevel = 1, races = 256, start = { npcs = { 35222 } }, finish = { npcs = { 34668 } }, prev = { 14116 }, objectives = {}, poi = { finish = { 59.8, 76.5 } } },
        [14121] = { name = "Atracadores", level = 4, minLevel = 1, races = 256, start = { npcs = { 34874 } }, finish = { npcs = { 34874 } }, prev = { 14120 }, excl = -14124, objectives = { { type = "item", id = 47530, count = 12 } }, poi = { finish = { 58.8, 76.3 }, obj = { { 0, 46.9, 61.6, 7.3 }, { 0, 38.3, 48.8, 6.7 }, { 0, 39.2, 76.1, 7.0 }, { 0, 31.2, 61.8, 5.5 } } } },
        [14122] = { name = "El gran atraco al banco", level = 4, minLevel = 1, races = 256, start = { npcs = { 34668, 35486 } }, finish = { npcs = { 34668 } }, prev = { 14120 }, excl = -14124, objectives = { { type = "monster", id = 35486, count = 1 }, { type = "item", id = 46858, count = 1 } }, poi = { finish = { 59.5, 76.2 }, obj = { { 0, 30.0, 68.8, 1.5 }, { 0, 30.0, 68.5, 1.5 } } } },
        [14123] = { name = "Entrar como si nada", level = 4, minLevel = 1, races = 256, start = { npcs = { 34693 } }, finish = { npcs = { 34693 } }, prev = { 14120 }, excl = -14124, objectives = { { type = "item", id = 48937, count = 1 }, { type = "item", id = 48939, count = 1 }, { type = "item", id = 48941, count = 1 } }, poi = { finish = { 59.5, 76.5 }, obj = { { 0, 20.0, 30.8, 1.5 }, { 0, 12.8, 35.2, 1.5 }, { 0, 16.1, 46.0, 1.5 } } } },
        [14124] = { name = "Libera la kaja'mita", level = 4, minLevel = 1, races = 256, start = { npcs = { 34872 } }, finish = { npcs = { 34872 } }, prev = { 14120 }, excl = -14124, objectives = { { type = "item", id = 48766, count = 12 } }, poi = { finish = { 63.0, 77.9 }, obj = { { 0, 68.5, 86.0, 17.5 } } } },
        [14125] = { name = "447", level = 5, minLevel = 1, races = 256, start = { npcs = { 34668, 37598 } }, finish = { npcs = { 37602 } }, prev = { 14121, 14122, 14123, 14124 }, objectives = { { type = "object", id = 201735, count = 1 }, { type = "object", id = 201733, count = 1 }, { type = "object", id = 201734, count = 1 }, { type = "monster", id = 37598, count = 1 } }, poi = { finish = { 59.6, 76.5 }, obj = { { 0, 59.5, 76.5, 1.5 }, { 0, 56.6, 74.8, 1.5 }, { 0, 56.1, 74.5, 1.5 }, { 0, 55.9, 76.6, 1.5 } } } },
        [14126] = { name = "Ahorros de toda una vida", level = 5, minLevel = 1, races = 256, start = { npcs = { 34668 } }, finish = { npcs = { 35222 } }, prev = { 14125 }, objectives = { { type = "item", id = 49866, count = 1 } }, poi = { finish = { 20.4, 15.1 } } },
        [14138] = { name = "Cuidando del negocio", level = 1, minLevel = 1, races = 256, start = { npcs = { 34668 } }, finish = { npcs = { 34872 } }, objectives = { { type = "item", id = 60203, count = 1 } }, poi = { finish = { 60.3, 74.3 } } },
        [14153] = { name = "El alma de la fiesta", level = 3, minLevel = 1, races = 256, start = { npcs = { 35054, 35175 } }, finish = { npcs = { 34668 } }, excl = 14113, objectives = { { type = "monster", id = 35175, count = 10, also = { 35186, 40071 } } }, poi = { finish = { 56.4, 75.4 }, obj = { { 0, 58.2, 83.3, 5.5 } } } },
        [24488] = { name = "Los repuestos", level = 3, minLevel = 1, races = 256, start = { npcs = { 37106 } }, finish = { npcs = { 37106 } }, prev = { 24521, 24567 }, objectives = { { type = "item", id = 49752, count = 6 } }, poi = { finish = { 48.8, 57.6 }, obj = { { 0, 41.7, 47.3, 3.8 }, { 0, 36.2, 47.5, 3.2 }, { 0, 29.6, 62.6, 3.0 }, { 0, 43.4, 61.9, 3.4 }, { 0, 48.1, 68.4, 2.6 }, { 0, 51.6, 58.9, 2.9 }, { 0, 37.3, 70.0, 2.3 }, { 0, 33.7, 76.7, 2.8 }, { 0, 46.4, 54.0, 2.7 }, { 0, 39.5, 82.3, 2.7 }, { 0, 43.9, 75.2, 3.3 } } } },
        [24502] = { name = "Dureza necesaria", level = 3, minLevel = 1, races = 256, start = { npcs = { 37106, 37114 } }, finish = {}, prev = { 24488 }, objectives = { { type = "monster", id = 48271, count = 1 }, { type = "monster", id = 37114, count = 8 } }, poi = { finish = { 48.8, 57.6 }, obj = { { 0, 47.7, 60.7, 1.5 }, { 0, 47.6, 58.0, 1.5 } } } },
        [24503] = { name = "El tanto de la victoria", level = 3, minLevel = 1, races = 256, start = {}, finish = { npcs = { 37106 } }, prev = { 24502 }, excl = 24503, objectives = { { type = "monster", id = 37203, count = 1 } }, poi = { finish = { 48.8, 57.6 }, obj = { { 0, 47.9, 72.6, 1.5 } } } },
        [24520] = { name = "Cuéntale a Sassy las nuevas", level = 3, minLevel = 1, races = 256, start = { npcs = { 37106 } }, finish = { npcs = { 34668 } }, prev = { 24503, 28414 }, prevAny = { 24503, 28414 }, objectives = {}, poi = { finish = { 56.7, 75.8 } } },
        [24521] = { name = "¡A por ellos!", level = 3, minLevel = 1, races = 256, start = {}, finish = { npcs = { 37106 } }, objectives = {}, poi = { finish = { 48.8, 57.6 } } },
        [24567] = { name = "¡A por ellos!", level = 3, minLevel = 1, races = 256, start = { npcs = { 34874 } }, finish = { npcs = { 37106 } }, prev = { 14071 }, objectives = {}, poi = { finish = { 48.8, 57.6 } } },
        [25473] = { name = "Kaja'Cola", level = 2, minLevel = 1, races = 256, start = { npcs = { 34872 } }, finish = { npcs = { 34668 } }, prev = { 14069, 14075 }, prevAny = { 14069, 14075 }, objectives = { { type = "item", id = 54453, count = 1 } }, poi = { finish = { 57.3, 76.5 } } },
        [26711] = { name = "Al banco", level = 3, minLevel = 1, races = 256, start = { npcs = { 35054 } }, finish = { npcs = { 35120 } }, objectives = {}, poi = { finish = { 30.0, 69.5 } } },
        [26712] = { name = "Al banco", level = 3, minLevel = 1, races = 256, start = { npcs = { 35053 } }, finish = { npcs = { 35120 } }, objectives = {}, poi = { finish = { 29.9, 69.6 } } },
        [28349] = { name = "Megs de marketing", level = 3, minLevel = 1, races = 256, start = { npcs = { 34668 } }, finish = { npcs = { 34874 } }, prev = { 25473 }, objectives = {}, poi = { finish = { 58.4, 75.9 } } },
        [28414] = { name = "El tanto de la victoria", level = 3, minLevel = 1, races = 256, start = { npcs = { 37106, 37203 } }, finish = { npcs = { 37106 } }, prev = { 24502 }, excl = 24503, objectives = { { type = "monster", id = 37203, count = 1 } }, poi = { finish = { 48.8, 57.6 }, obj = { { 0, 47.9, 72.6, 1.5 } } } },
    },
    npcs = {
    },
    objects = {
    },
    items = {
        [46858] = { npcs = {}, objects = {} },
        [47045] = { npcs = {}, objects = {} },
        [47046] = { npcs = {}, objects = {} },
        [47047] = { npcs = {}, objects = {} },
        [47530] = { npcs = {}, objects = {} },
        [48766] = { npcs = {}, objects = {} },
        [48937] = { npcs = {}, objects = {} },
        [48939] = { npcs = {}, objects = {} },
        [48941] = { npcs = {}, objects = {} },
        [49752] = { npcs = {}, objects = {} },
        [49866] = { npcs = {}, objects = {} },
        [54453] = { npcs = {}, objects = {} },
        [60203] = { npcs = {}, objects = {} },
    },
})
