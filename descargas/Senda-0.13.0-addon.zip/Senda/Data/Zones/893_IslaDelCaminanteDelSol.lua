-- ARCHIVO GENERADO por tools/export_tc.py. No editar a mano: se sobrescribe.
-- Datos derivados de TrinityCore (C) 2008+ TrinityCore, licencia GNU GPL v2.
-- Ver LEEME-DATOS.txt y LICENSE-GPL2.txt en esta carpeta.
-- Zona: Isla del Caminante del Sol (mapID 893, continente 0, área 0)
-- 8 misiones, 0 PNJ, 0 objetos.

local _, ns = ...

ns.DB:RegisterZone({
    mapID = 893,
    name = "Isla del Caminante del Sol",
    quests = {
        [8326] = { name = "Medidas extremas", level = 3, minLevel = 1, races = 512, start = { npcs = { 15278 } }, finish = { npcs = { 15278 } }, prev = { 8325 }, objectives = { { type = "item", id = 20797, count = 8 } }, poi = { finish = { 61.7, 44.6 }, obj = { { 0, 66.9, 37.9, 11.0 } } } },
        [8327] = { name = "Informar a Lanthan Perilon", level = 3, minLevel = 1, races = 512, start = { npcs = { 15278 } }, finish = { npcs = { 15281 } }, prev = { 8326 }, objectives = {}, poi = { finish = { 52.9, 49.8 } } },
        [8334] = { name = "Agresividad", level = 4, minLevel = 1, races = 512, start = { npcs = { 15281, 15294 } }, finish = { npcs = { 15281 } }, prev = { 8327 }, objectives = { { type = "monster", id = 15271, count = 7 }, { type = "monster", id = 15294, count = 7 } }, poi = { finish = { 52.9, 49.8 }, obj = { { 0, 45.0, 54.4, 20.6 }, { 0, 47.4, 61.0, 24.5 } } } },
        [8335] = { name = "Felendren el Desterrado", level = 5, minLevel = 1, races = 512, start = { npcs = { 15273, 15281, 15298 } }, finish = { npcs = { 15281 } }, prev = { 8334 }, objectives = { { type = "monster", id = 15273, count = 8 }, { type = "monster", id = 15298, count = 2 }, { type = "item", id = 20799, count = 1 } }, poi = { finish = { 52.9, 49.8 }, obj = { { 0, 38.9, 64.0, 1.5 }, { 0, 39.2, 64.1, 1.6 }, { 0, 38.8, 64.3, 8.7 } } } },
        [37439] = { name = "Sed insaciable", level = 3, minLevel = 2, races = 512, start = { npcs = { 15297 } }, finish = { npcs = { 15297 } }, objectives = { { type = "monster", id = 15468, count = 1 } }, poi = { finish = { 58.5, 38.7 }, obj = { { 0, 56.9, 49.1, 14.4 } } } },
        [37440] = { name = "Por un puñado de esquirlas", level = 4, minLevel = 2, races = 512, start = { npcs = { 15296 } }, finish = { npcs = { 15296 } }, objectives = { { type = "item", id = 20482, count = 6 } }, poi = { finish = { 61.8, 39.3 }, obj = { { 0, 49.5, 54.7, 20.2 } } } },
        [37442] = { name = "Santuario de Dath'Remar", level = 4, minLevel = 2, races = 512, start = { npcs = { 15295 } }, finish = { npcs = { 15295 } }, objectives = { { type = "object", id = 180516, count = 1 } }, poi = { finish = { 63.3, 40.1 }, obj = { { 0, 35.2, 40.1, 1.5 } } } },
        [37443] = { name = "Las posesiones de Solanian", level = 4, minLevel = 2, races = 512, start = { npcs = { 15295 } }, finish = { npcs = { 15295 } }, objectives = { { type = "item", id = 20470, count = 1 }, { type = "item", id = 20471, count = 1 }, { type = "item", id = 20472, count = 1 } }, poi = { finish = { 64.0, 42.9 }, obj = { { 2, 60.0, 57.1, 1.5 }, { 1, 40.4, 50.5, 1.5 }, { 0, 52.2, 69.4, 1.5 } } } },
    },
    npcs = {
    },
    objects = {
    },
    items = {
        [20470] = { npcs = {}, objects = {} },
        [20471] = { npcs = {}, objects = {} },
        [20472] = { npcs = {}, objects = {} },
        [20482] = { npcs = {}, objects = {} },
        [20797] = { npcs = {}, objects = {} },
        [20799] = { npcs = {}, objects = {} },
    },
})
