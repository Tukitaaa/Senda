-- ARCHIVO GENERADO por tools/export_tc.py. No editar a mano: se sobrescribe.
-- Datos derivados de TrinityCore (C) 2008+ TrinityCore, licencia GNU GPL v2.
-- Ver LEEME-DATOS.txt y LICENSE-GPL2.txt en esta carpeta.
-- Zona: Valle Ammen (mapID 894, continente 1, área 0)
-- 18 misiones, 0 PNJ, 0 objetos.

local _, ns = ...

ns.DB:RegisterZone({
    mapID = 894,
    name = "Valle Ammen",
    quests = {
        [9279] = { name = "¡Has sobrevivido!", level = 1, minLevel = 1, races = 1024, start = { npcs = { 16475 } }, finish = { npcs = { 16477 } }, objectives = {}, poi = { finish = { 52.8, 35.9 } } },
        [9280] = { name = "Recargar los cristales de sanación", level = 1, minLevel = 1, races = 1024, start = { npcs = { 16477 } }, finish = { npcs = { 16477 } }, prev = { 9279 }, excl = 9280, objectives = { { type = "item", id = 22889, count = 6 } }, poi = { finish = { 52.8, 35.9 }, obj = { { 0, 46.5, 26.2, 7.5 } } } },
        [9283] = { name = "¡Rescata a los supervivientes!", level = 2, minLevel = 1, races = 1024, start = { npcs = { 16483, 16502 } }, finish = { npcs = { 16502 } }, prev = { 9409 }, objectives = { { type = "monster", id = 16483, count = 1 } }, poi = { finish = { 52.1, 42.4 }, obj = { { 0, 41.6, 41.2, 27.0 } } } },
        [9293] = { name = "Hacer lo correcto...", level = 2, minLevel = 1, races = 18875469, start = { npcs = { 16514 } }, finish = { npcs = { 16514 } }, prev = { 9293, 10302 }, objectives = { { type = "item", id = 22934, count = 10 } }, poi = { finish = { 49.9, 37.3 }, obj = { { 0, 37.2, 45.7, 8.9 } } } },
        [9294] = { name = "Sanar el lago", level = 3, minLevel = 1, races = 18875469, start = { npcs = { 16514 } }, finish = { npcs = { 16514 } }, prev = { 9293 }, objectives = { { type = "monster", id = 88791, count = 1 } }, poi = { finish = { 49.9, 37.3 }, obj = { { 0, 44.9, 64.6, 1.5 } } } },
        [9305] = { name = "Piezas de repuesto", level = 4, minLevel = 2, races = 18875469, start = { npcs = { 17071 } }, finish = { npcs = { 17071 } }, objectives = { { type = "item", id = 22978, count = 4 } }, poi = { finish = { 50.5, 47.9 }, obj = { { 0, 60.9, 70.3, 17.7 } } } },
        [9309] = { name = "El explorador desaparecido", level = 5, minLevel = 2, races = 18875469, start = { npcs = { 16535 } }, finish = { npcs = { 16546 } }, objectives = {}, poi = { finish = { 33.9, 69.4 } } },
        [9311] = { name = "Espía elfo de sangre", level = 5, minLevel = 2, races = 18875469, start = { npcs = { 16546 } }, finish = { npcs = { 16535 } }, prev = { 10303 }, objectives = { { type = "monster", id = 16522, count = 1 } }, poi = { finish = { 50.7, 48.7 }, obj = { { 0, 27.8, 80.4, 1.5 } } } },
        [9312] = { name = "El emisor", level = 5, minLevel = 3, races = 18875469, start = { npcs = { 16535 } }, finish = { npcs = { 17071 } }, prev = { 9311 }, objectives = {}, poi = { finish = { 50.5, 47.9 } } },
        [9369] = { name = "Recargar los cristales de sanación", level = 1, minLevel = 1, races = 16777293, start = { npcs = { 16477 } }, finish = { npcs = { 16477 } }, excl = 9280, objectives = { { type = "item", id = 22889, count = 6 } }, poi = { finish = { 52.8, 35.9 }, obj = { { 0, 48.3, 25.7, 8.9 } } } },
        [9371] = { name = "La botánica Taerix", level = 2, minLevel = 1, races = 18875469, start = { npcs = { 16477 } }, finish = { npcs = { 16514 } }, prev = { 9409 }, objectives = {}, poi = { finish = { 49.9, 37.3 } } },
        [9409] = { name = "Entrega urgente", level = 2, minLevel = 1, races = 18875469, start = { npcs = { 16477 } }, finish = { npcs = { 16502 } }, prev = { 9280, 9369 }, objectives = { { type = "item", id = 23568, count = 1 } }, poi = { finish = { 52.1, 42.4 } } },
        [9798] = { name = "Planes de los elfos de sangre", level = 5, minLevel = 2, races = 18875469, start = {}, finish = { npcs = { 16535 } }, objectives = { { type = "item", id = 24414, count = 1 } }, poi = { finish = { 50.7, 48.7 } } },
        [9799] = { name = "Trabajo de campo", level = 3, minLevel = 1, races = 18875469, start = { npcs = { 20233 } }, finish = { npcs = { 20233 } }, prev = { 10302 }, objectives = { { type = "item", id = 24416, count = 3 } }, poi = { finish = { 49.7, 37.5 }, obj = { { 0, 37.6, 47.4, 9.2 } } } },
        [10302] = { name = "Mutaciones volátiles", level = 2, minLevel = 1, start = { npcs = { 16514 } }, finish = { npcs = { 16514 } }, prev = { 9371 }, objectives = { { type = "monster", id = 16516, count = 8 } }, poi = { finish = { 49.9, 37.3 }, obj = { { 0, 43.0, 39.2, 20.2 } } } },
        [10303] = { name = "Los elfos de sangre", level = 4, minLevel = 1, start = { npcs = { 16546 } }, finish = { npcs = { 16546 } }, prev = { 9309 }, objectives = { { type = "monster", id = 16521, count = 10 } }, poi = { finish = { 33.9, 69.4 }, obj = { { 0, 29.4, 74.5, 6.1 } } } },
        [37444] = { name = "Inoculación", level = 4, minLevel = 2, races = 18875469, start = {}, finish = { npcs = { 16535 } }, objectives = { { type = "monster", id = 16534, count = 6 }, { type = "item", id = 22962, count = 1 } }, poi = { finish = { 50.7, 48.7 }, obj = { { 0, 66.1, 80.0, 10.0 }, { 0, 51.4, 66.2, 8.4 } } } },
        [37445] = { name = "Piezas de repuesto", level = 4, minLevel = 2, races = 18875469, start = {}, finish = { npcs = { 17071 } }, objectives = { { type = "item", id = 22978, count = 4 } }, poi = { finish = { 50.5, 47.9 }, obj = { { 0, 60.9, 70.3, 17.7 } } } },
    },
    npcs = {
    },
    objects = {
    },
    items = {
        [22889] = { npcs = {}, objects = {} },
        [22934] = { npcs = {}, objects = {} },
        [22962] = { npcs = {}, objects = {} },
        [22978] = { npcs = {}, objects = {} },
        [23568] = { npcs = {}, objects = {} },
        [24414] = { npcs = {}, objects = {} },
        [24416] = { npcs = {}, objects = {} },
    },
})
