-- ARCHIVO GENERADO por tools/export_tc.py. No editar a mano: se sobrescribe.
-- Datos derivados de TrinityCore (C) 2008+ TrinityCore, licencia GNU GPL v2.
-- Ver LEEME-DATOS.txt y LICENSE-GPL2.txt en esta carpeta.
-- Zona: Isla Intemporal (mapID 951, continente 870, área 6757)
-- 46 misiones, 0 PNJ, 0 objetos.

local _, ns = ...

ns.DB:RegisterZone({
    mapID = 951,
    name = "Isla Intemporal",
    quests = {
        [32952] = { name = "TEST", level = 0, minLevel = 0, start = {}, finish = {}, objectives = {} },
        [32974] = { name = "El enigma de Rolo", level = 90, minLevel = 90, start = {}, finish = { npcs = { 72751 } }, objectives = { { type = "monster", id = 72751, count = 1 } }, poi = { finish = { 49.4, 69.4 }, obj = { { 0, 62.3, 56.4, 31.2 } } } },
        [32975] = { name = "El enigma de Rolo", level = 90, minLevel = 90, start = { npcs = { 72751 } }, finish = { npcs = { 72754 } }, prev = { 32974, 38552 }, objectives = { { type = "monster", id = 72754, count = 1 } }, poi = { finish = { 34.6, 26.6 }, obj = { { 0, 38.2, 37.3, 23.9 } } } },
        [32976] = { name = "El enigma de Rolo", level = 90, minLevel = 90, start = { npcs = { 72754 } }, finish = { npcs = { 72755 } }, prev = { 32975 }, objectives = { { type = "monster", id = 72755, count = 1 } }, poi = { finish = { 66.1, 23.3 }, obj = { { 0, 59.2, 34.3, 21.5 } } } },
        [33018] = { name = "Secretos de los fideos olvidados hace tiempo", level = 90, minLevel = 90, start = { objects = { 221376 } }, finish = { npcs = { 72426 } }, objectives = {}, poi = { finish = { 41.0, 73.6 } } },
        [33026] = { name = "Estos no son tus cabritos grasos", level = 90, minLevel = 90, start = { npcs = { 64231 } }, finish = { npcs = { 64231 } }, prev = { 33024 }, objectives = { { type = "item", id = 101776, count = 50 }, { type = "monster", id = 73390, count = 1 } }, poi = { obj = { { 0, 18.4, 55.1, 25.0 }, { 0, 24.2, 59.5, 17.3 } } } },
        [33035] = { name = "Vignette: Pale Capture", level = 0, minLevel = 0, start = {}, finish = {}, objectives = {} },
        [33051] = { name = "Vignette: Prophecy of Jerrikar", level = 0, minLevel = 0, start = {}, finish = {}, objectives = {} },
        [33052] = { name = "Vignette: Prophecy of Kraator", level = 0, minLevel = 0, start = {}, finish = {}, objectives = {} },
        [33053] = { name = "Vignette: Prophecy of the Warp-Watcher", level = 0, minLevel = 0, start = {}, finish = {}, objectives = {} },
        [33056] = { name = "Vignette: Hygrocybe", level = 0, minLevel = 0, start = {}, finish = {}, objectives = {} },
        [33065] = { name = "Vignette: Mooncrush", level = 0, minLevel = 0, start = {}, finish = {}, objectives = {} },
        [33069] = { name = "REUSEME", level = 0, minLevel = 0, start = {}, finish = {}, objectives = {} },
        [33088] = { name = "Un descubrimiento intemporal", level = 90, minLevel = 90, start = {}, finish = { npcs = { 72695 } }, prev = { 32870, 33087 }, objectives = {}, poi = { finish = { 34.5, 53.8 } } },
        [33098] = { name = "Los secretos de la Isla Intemporal", level = 90, minLevel = 90, start = {}, finish = { npcs = { 72695 } }, prev = { 33088 }, objectives = {}, poi = { finish = { 34.5, 53.8 } } },
        [33100] = { name = "El camino del Emperador", level = 90, minLevel = 90, start = {}, finish = { npcs = { 72695 } }, objectives = { { type = "monster", id = 71955, count = 1 }, { type = "monster", id = 71952, count = 1 }, { type = "monster", id = 71953, count = 1 }, { type = "monster", id = 71954, count = 1 } }, poi = { finish = { 34.5, 53.8 }, obj = { { 0, 41.5, 49.0, 1.5 }, { 0, 36.3, 60.9, 1.5 }, { 0, 36.1, 49.1, 1.5 }, { 0, 41.6, 61.0, 1.5 } } } },
        [33137] = { name = "El Torneo Celestial", level = -1, minLevel = 90, start = { npcs = { 73082 } }, finish = { npcs = { 73082 } }, objectives = { { type = "monster", id = 73159, count = 1 } }, poi = { finish = { 34.7, 59.6 }, obj = { { 0, 34.5, 59.6, 1.5 } } } },
        [33156] = { name = "Vigilante del tiempo Kairoz", level = 90, minLevel = 90, races = 33555378, start = { npcs = { 73353 } }, finish = { npcs = { 72870 } }, prev = { 33161, 33232 }, objectives = {}, poi = { finish = { 34.5, 53.6 } } },
        [33160] = { name = "Vigilante del tiempo Kairoz", level = 90, minLevel = 90, races = 18875469, start = { npcs = { 73348 } }, finish = { npcs = { 72870 } }, prev = { 33231 }, objectives = {}, poi = { finish = { 34.5, 53.6 } } },
        [33161] = { name = "Un recorrido intemporal", level = 90, minLevel = 90, start = { npcs = { 72870 } }, finish = { npcs = { 72870 } }, objectives = { { type = "monster", id = 73577, count = 1 }, { type = "monster", id = 73576, count = 1 }, { type = "monster", id = 73579, count = 1 }, { type = "monster", id = 73578, count = 1 }, { type = "monster", id = 73574, count = 1 }, { type = "monster", id = 73575, count = 1 } }, poi = { finish = { 34.5, 53.6 }, obj = { { 0, 59.9, 53.4, 15.4 }, { 0, 38.2, 75.8, 6.2 }, { 0, 25.5, 30.6, 4.9 }, { 0, 55.2, 78.4, 7.6 }, { 0, 64.3, 70.5, 7.5 }, { 0, 43.5, 38.3, 2.1 } } } },
        [33211] = { name = "Una pregunta intemporal", level = 90, minLevel = 90, races = 52430847, start = { npcs = { 73570 } }, finish = { npcs = { 73570 } }, objectives = { { type = "monster", id = 73570, count = 1 } }, poi = { finish = { 65.0, 50.6 }, obj = { { 0, 65.0, 50.6, 1.5 } } } },
        [33228] = { name = "El tiempo en tus manos", level = 90, minLevel = 90, start = { npcs = { 72870 } }, finish = { npcs = { 72870 } }, objectives = { { type = "monster", id = 73305, count = 1 }, { type = "monster", id = 73306, count = 1 } }, poi = { finish = { 34.5, 53.6 }, obj = { { 0, 42.7, 54.7, 1.5 }, { 0, 42.7, 55.7, 1.5 } } } },
        [33231] = { name = "Viaje a la Isla Intemporal", level = 90, minLevel = 90, races = 18875469, start = { npcs = { 73691 } }, finish = { npcs = { 73348 } }, prev = { 33229 }, objectives = {}, poi = { finish = { 23.1, 71.6 } } },
        [33232] = { name = "Viaje a la Isla Intemporal", level = 90, minLevel = 90, races = 33555378, start = { npcs = { 73691 } }, finish = { npcs = { 73353 } }, prev = { 33230 }, objectives = {}, poi = { finish = { 22.0, 41.0 } } },
        [33234] = { name = "Pata de grulla carnosa", level = 90, minLevel = 90, start = { npcs = { 73657 } }, finish = { npcs = { 73657 } }, objectives = { { type = "item", id = 104264, count = 1 } }, poi = { finish = { 41.8, 63.7 } } },
        [33235] = { name = "Carne de gran tortuga", level = 90, minLevel = 90, start = { npcs = { 73657 } }, finish = { npcs = { 73657 } }, objectives = { { type = "item", id = 104265, count = 1 } }, poi = { finish = { 41.8, 63.7 } } },
        [33236] = { name = "Costillar de yak pesado", level = 90, minLevel = 90, start = { npcs = { 73657 } }, finish = { npcs = { 73657 } }, objectives = { { type = "item", id = 104266, count = 1 } }, poi = { finish = { 41.8, 63.7 } } },
        [33238] = { name = "Anca de tigre gruesa", level = 90, minLevel = 90, start = { npcs = { 73657 } }, finish = { npcs = { 73657 } }, objectives = { { type = "item", id = 104267, count = 1 } }, poi = { finish = { 41.8, 63.7 } } },
        [33239] = { name = "Huevo de tormenta de Fuego prístino", level = 90, minLevel = 90, start = { npcs = { 73657 } }, finish = { npcs = { 73657 } }, objectives = { { type = "item", id = 104257, count = 1 } }, poi = { finish = { 41.8, 63.7 } } },
        [33332] = { name = "Pistas del pasado", level = 90, minLevel = 90, start = { npcs = { 72870 } }, finish = { npcs = { 72870 } }, objectives = { { type = "item", id = 103977, count = 1 } }, poi = { finish = { 34.5, 53.6 }, obj = { { 0, 42.7, 55.7, 1.5 } } } },
        [33334] = { name = "Con la fuerza para sobrevivir", level = 90, minLevel = 90, start = { npcs = { 72870 } }, finish = { npcs = { 72870 } }, objectives = { { type = "monster", id = 73983, count = 5, also = { 71864, 71919, 72045, 72048, 72049, 72193, 72245, 72769, 72775, 72808, 72909, 72970, 73157, 73158, 73160, 73161, 73163, 73166, 73167, 73169, 73170, 73171, 73172, 73173, 73174, 73175, 73277, 73279, 73281, 73282, 73666, 73704, 73854 } } }, poi = { finish = { 34.5, 53.6 } } },
        [33335] = { name = "El último emperador", level = 90, minLevel = 90, start = { npcs = { 72870 } }, finish = { npcs = { 73303 } }, objectives = { { type = "monster", id = 73303, count = 1 } }, poi = { finish = { 42.7, 55.2 }, obj = { { 0, 42.7, 55.2, 1.5 } } } },
        [33336] = { name = "La esencia del tiempo", level = 90, minLevel = 90, start = { npcs = { 72870 } }, finish = { npcs = { 72870 } }, objectives = { { type = "item", id = 105715, count = 1 } }, poi = { finish = { 34.5, 53.6 } } },
        [33337] = { name = "Una visión en el tiempo", level = 90, minLevel = 90, start = { npcs = { 72870 } }, finish = { npcs = { 72870 } }, objectives = { { type = "monster", id = 74094, count = 1 } }, poi = { finish = { 34.5, 53.6 } } },
        [33338] = { name = "Potenciando el reloj de arena", level = 90, minLevel = 90, start = { npcs = { 72870 } }, finish = { npcs = { 72870 } }, objectives = { { type = "item", id = 105715, count = 50 } }, poi = { finish = { 34.5, 53.6 } } },
        [33340] = { name = "Nutrición intemporal", level = 90, minLevel = 90, start = { npcs = { 73303 } }, finish = { npcs = { 73303 } }, objectives = { { type = "monster", id = 73991, count = 1 } }, poi = { finish = { 42.7, 55.2 } } },
        [33341] = { name = "Santuarios de los Celestiales", level = 90, minLevel = 90, start = { npcs = { 73303 } }, finish = { npcs = { 73303 } }, objectives = { { type = "object", id = 222776, count = 1 } }, poi = { finish = { 42.7, 55.2 } } },
        [33342] = { name = "El retorno del fuego", level = 90, minLevel = 90, start = { npcs = { 73303 } }, finish = { npcs = { 73303 } }, objectives = {}, poi = { finish = { 42.7, 55.2 }, obj = { { 31, 54.5, 78.8, 8.9 } } } },
        [33343] = { name = "El sacerdote ilustre de las llamas", level = 90, minLevel = 90, start = { npcs = { 73303 } }, finish = { npcs = { 73303 } }, objectives = { { type = "monster", id = 73666, count = 1 } }, poi = { finish = { 42.7, 55.2 }, obj = { { 0, 34.4, 32.5, 1.5 }, { 0, 42.7, 54.7, 1.5 }, { 0, 34.6, 29.6, 1.5 } } } },
        [33374] = { name = "La senda del Tejedor de niebla", level = 90, minLevel = 90, start = { npcs = { 73303 } }, finish = { npcs = { 73303 } }, objectives = { { type = "monster", id = 74093, count = 20, also = { 71826, 71908, 71920, 72762, 72764, 72765, 72766, 72767, 72771, 72777, 72805, 72809, 72841, 72844, 72876, 72888, 72892, 72894, 72895, 72896, 72897, 72898, 73162, 73703, 73718 } } }, poi = { finish = { 42.7, 55.2 } } },
        [33375] = { name = "Perfeccionando la visión", level = 90, minLevel = 90, start = { npcs = { 72870 } }, finish = { npcs = { 72870 } }, objectives = { { type = "monster", id = 74094, count = 1 } }, poi = { finish = { 34.5, 53.6 } } },
        [33376] = { name = "En busca del destino", level = 90, minLevel = 90, start = { npcs = { 72870 } }, finish = { npcs = { 72870 } }, objectives = { { type = "monster", id = 74094, count = 1 } }, poi = { finish = { 34.5, 53.6 } } },
        [33377] = { name = "Hilos ocultos", level = 90, minLevel = 90, start = { npcs = { 72870 } }, finish = { npcs = { 72870 } }, objectives = { { type = "monster", id = 74094, count = 1 } }, poi = { finish = { 34.5, 53.6 } } },
        [33378] = { name = "Cortejando al destino", level = 90, minLevel = 90, start = { npcs = { 72870 } }, finish = { npcs = { 72870 } }, objectives = { { type = "monster", id = 74094, count = 1 } }, poi = { finish = { 34.5, 53.6 } } },
        [33379] = { name = "Una última vuelta", level = 90, minLevel = 90, start = { npcs = { 72870 } }, finish = { npcs = { 72870 } }, objectives = { { type = "monster", id = 74094, count = 1 } }, poi = { finish = { 34.5, 53.6 } } },
        [45563] = { name = "La moneda velada", level = -1, minLevel = 91, start = {}, finish = {}, objectives = {}, poi = { finish = { 43.5, 55.1 } } },
    },
    npcs = {
    },
    objects = {
    },
    items = {
        [101776] = { npcs = {}, objects = {} },
        [103977] = { npcs = {}, objects = {} },
        [104257] = { npcs = {}, objects = {} },
        [104264] = { npcs = {}, objects = {} },
        [104265] = { npcs = {}, objects = {} },
        [104266] = { npcs = {}, objects = {} },
        [104267] = { npcs = {}, objects = {} },
        [105715] = { npcs = {}, objects = {} },
    },
})
